-- ============================================================
-- STOCK MASTER - World-Class Shopping Mall Inventory System
-- Database Schema for phpMyAdmin / MariaDB
-- ============================================================

CREATE DATABASE IF NOT EXISTS `stock_master`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `stock_master`;

-- ------------------------------------------------------------
-- TABLE: users
-- ------------------------------------------------------------
CREATE TABLE `users` (
  `id`           INT UNSIGNED     NOT NULL AUTO_INCREMENT,
  `full_name`    VARCHAR(120)     NOT NULL,
  `email`        VARCHAR(180)     NOT NULL,
  `password`     VARCHAR(255)     NOT NULL,
  `role`         ENUM('admin','manager','staff') NOT NULL DEFAULT 'staff',
  `avatar_color` VARCHAR(7)       NOT NULL DEFAULT '#6366f1',
  `last_login`   DATETIME         NULL,
  `created_at`   TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- TABLE: categories
-- ------------------------------------------------------------
CREATE TABLE `categories` (
  `id`          SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`        VARCHAR(80)       NOT NULL,
  `slug`        VARCHAR(80)       NOT NULL,
  `icon`        VARCHAR(60)       NOT NULL DEFAULT 'bi-box',
  `color_hex`   VARCHAR(7)        NOT NULL DEFAULT '#6366f1',
  `description` VARCHAR(255)      NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `categories` (`name`, `slug`, `icon`, `color_hex`, `description`) VALUES
('Furniture',        'furniture',     'bi-house-door',      '#f59e0b', 'Luxury sofas, office desks, premium seating'),
('Tech & Electronics','tech-electronics','bi-cpu',           '#6366f1', 'Laptops, smartphones, servers, networking gear'),
('Appliances',       'appliances',    'bi-lightning-charge', '#10b981', 'Home & industrial machinery, white goods'),
('Food & Beverage',  'food-beverage', 'bi-cup-hot',          '#ef4444', 'Fruits, sweets, premium drinks, gourmet items');

-- ------------------------------------------------------------
-- TABLE: suppliers
-- ------------------------------------------------------------
CREATE TABLE `suppliers` (
  `id`           INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `name`         VARCHAR(120)  NOT NULL,
  `contact_name` VARCHAR(100)  NULL,
  `email`        VARCHAR(180)  NULL,
  `phone`        VARCHAR(30)   NULL,
  `address`      TEXT          NULL,
  `created_at`   TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `suppliers` (`name`, `contact_name`, `email`, `phone`) VALUES
('LuxeHome Imports',   'James Harrington', 'james@luxehome.com',  '+1-800-555-0101'),
('TechVault Global',   'Aisha Patel',      'aisha@techvault.io',  '+1-800-555-0202'),
('ProAppliance Corp',  'Carlos Mendez',    'carlos@proappl.com',  '+1-800-555-0303'),
('GourmetWorld Ltd',   'Sophie Laurent',   'sophie@gourmet.eu',   '+44-20-5550-0404');

-- ------------------------------------------------------------
-- TABLE: products  (core inventory)
-- ------------------------------------------------------------
CREATE TABLE `products` (
  `id`              INT UNSIGNED      NOT NULL AUTO_INCREMENT,
  `sku`             VARCHAR(60)       NOT NULL,
  `name`            VARCHAR(180)      NOT NULL,
  `description`     TEXT              NULL,
  `category_id`     SMALLINT UNSIGNED NOT NULL,
  `supplier_id`     INT UNSIGNED      NULL,
  `unit`            VARCHAR(30)       NOT NULL DEFAULT 'pcs',
  `unit_price`      DECIMAL(12,2)     NOT NULL DEFAULT 0.00,
  `quantity`        INT               NOT NULL DEFAULT 0,
  `low_stock_threshold` INT           NOT NULL DEFAULT 10,
  `requires_serial` TINYINT(1)        NOT NULL DEFAULT 0,
  `batch_number`    VARCHAR(80)       NULL,
  `location`        VARCHAR(80)       NULL  COMMENT 'Warehouse bin / shelf location',
  `image_url`       VARCHAR(255)      NULL,
  `status`          ENUM('active','inactive','discontinued') NOT NULL DEFAULT 'active',
  `created_by`      INT UNSIGNED      NOT NULL,
  `created_at`      TIMESTAMP         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`      TIMESTAMP         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sku` (`sku`),
  KEY `idx_category` (`category_id`),
  KEY `idx_status`   (`status`),
  CONSTRAINT `fk_product_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  CONSTRAINT `fk_product_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_product_creator`  FOREIGN KEY (`created_by`)  REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- TABLE: serial_numbers  (tech & machinery serials)
-- ------------------------------------------------------------
CREATE TABLE `serial_numbers` (
  `id`          INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `product_id`  INT UNSIGNED  NOT NULL,
  `serial`      VARCHAR(120)  NOT NULL,
  `status`      ENUM('available','sold','reserved','faulty') NOT NULL DEFAULT 'available',
  `notes`       VARCHAR(255)  NULL,
  `created_at`  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_serial` (`serial`),
  KEY `idx_product_serial` (`product_id`),
  CONSTRAINT `fk_serial_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- TABLE: stock_transactions  (every in/out movement)
-- ------------------------------------------------------------
CREATE TABLE `stock_transactions` (
  `id`            INT UNSIGNED   NOT NULL AUTO_INCREMENT,
  `product_id`    INT UNSIGNED   NOT NULL,
  `user_id`       INT UNSIGNED   NOT NULL,
  `type`          ENUM('purchase','sale','adjustment','return','transfer','loss') NOT NULL,
  `quantity`      INT            NOT NULL  COMMENT 'Positive = in, Negative = out',
  `quantity_before` INT          NOT NULL,
  `quantity_after`  INT          NOT NULL,
  `unit_price`    DECIMAL(12,2)  NULL,
  `reference`     VARCHAR(100)   NULL  COMMENT 'PO / Invoice / Order number',
  `notes`         TEXT           NULL,
  `created_at`    TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_txn_product` (`product_id`),
  KEY `idx_txn_user`    (`user_id`),
  KEY `idx_txn_type`    (`type`),
  KEY `idx_txn_date`    (`created_at`),
  CONSTRAINT `fk_txn_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `fk_txn_user`    FOREIGN KEY (`user_id`)    REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- TABLE: alerts  (low-stock / system notifications)
-- ------------------------------------------------------------
CREATE TABLE `alerts` (
  `id`          INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `product_id`  INT UNSIGNED  NOT NULL,
  `type`        ENUM('low_stock','out_of_stock','expiry','reorder') NOT NULL DEFAULT 'low_stock',
  `message`     VARCHAR(255)  NOT NULL,
  `is_read`     TINYINT(1)    NOT NULL DEFAULT 0,
  `created_at`  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_alert_product` (`product_id`),
  KEY `idx_alert_read`    (`is_read`),
  CONSTRAINT `fk_alert_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- SEED: Default admin user  (password = Admin@1234)
-- ------------------------------------------------------------
INSERT INTO `users` (`full_name`, `email`, `password`, `role`) VALUES
('Mall Administrator', 'admin@stockmaster.com',
 '$2y$12$Dx613dEYuC9Cz1sEqYrtM.TqVNvzxII2cfssGND25hCj5cekNHTsC', -- Admin@1234 (bcrypt)
 'admin');

-- ------------------------------------------------------------
-- SEED: Sample products
-- ------------------------------------------------------------
INSERT INTO `products`
  (`sku`,`name`,`category_id`,`supplier_id`,`unit`,`unit_price`,`quantity`,`low_stock_threshold`,`requires_serial`,`batch_number`,`location`,`created_by`)
VALUES
-- Furniture
('FRN-001','Velvet Chesterfield Sofa 3-Seater',  1,1,'pcs',  2499.00, 12, 3, 0, 'BATCH-FRN-2024A', 'W1-A1-S1', 1),
('FRN-002','Executive Walnut Writing Desk',       1,1,'pcs',  1199.00,  8, 3, 0, 'BATCH-FRN-2024A', 'W1-A1-S2', 1),
('FRN-003','Ergonomic Mesh Office Chair',         1,1,'pcs',   549.00, 24, 5, 0, 'BATCH-FRN-2024B', 'W1-A2-S1', 1),
('FRN-004','Marble-Top Dining Table 6-Seater',   1,1,'pcs',  3200.00,  4, 2, 0, 'BATCH-FRN-2024B', 'W1-A2-S2', 1),
-- Tech & Electronics
('TEC-001','MacBook Pro 16" M3 Max',              2,2,'pcs',  3999.00, 15, 5, 1, NULL,              'W2-A1-S1', 1),
('TEC-002','Samsung Galaxy S25 Ultra',            2,2,'pcs',  1299.00, 30, 8, 1, NULL,              'W2-A1-S2', 1),
('TEC-003','Dell PowerEdge R750 Server',          2,2,'pcs',  8499.00,  2, 2, 1, NULL,              'W2-A2-S1', 1),
('TEC-004','Sony 85" BRAVIA XR OLED TV',         2,2,'pcs',  5499.00,  6, 3, 1, NULL,              'W2-A2-S2', 1),
-- Appliances
('APL-001','Miele Induction Range 5-Burner',      3,3,'pcs',  4200.00,  7, 3, 1, 'BATCH-APL-24A',  'W3-A1-S1', 1),
('APL-002','LG InstaView French Door Fridge',     3,3,'pcs',  3100.00,  9, 3, 1, 'BATCH-APL-24A',  'W3-A1-S2', 1),
('APL-003','Dyson V15 Detect Vacuum',             3,3,'pcs',   699.00, 18, 5, 0, 'BATCH-APL-24B',  'W3-A2-S1', 1),
('APL-004','Bosch Industrial Washer 20kg',        3,3,'pcs',  2800.00,  3, 2, 1, 'BATCH-APL-24B',  'W3-A2-S2', 1),
-- Food & Beverage
('FNB-001','Imported Alphonso Mango Box 5kg',     4,4,'box',   145.00, 40,10, 0, 'BATCH-FNB-24A',  'W4-A1-S1', 1),
('FNB-002','Godiva Prestige Chocolate 1kg',       4,4,'box',   299.00, 25, 8, 0, 'BATCH-FNB-24A',  'W4-A1-S2', 1),
('FNB-003','Dom Pérignon Vintage 2015 Case 6',    4,4,'case', 1800.00,  5, 3, 0, 'BATCH-FNB-24B',  'W4-A2-S1', 1),
('FNB-004','Organic Cold-Press Juice Pack 12x1L', 4,4,'pack',  89.00,  6, 5, 0, 'BATCH-FNB-24B',  'W4-A2-S2', 1);

-- ============================================================
-- STORED PROCEDURE: log_stock_transaction
-- Atomically updates product qty and logs the transaction
-- ============================================================
DELIMITER $$
CREATE PROCEDURE `log_stock_transaction`(
  IN  p_product_id  INT,
  IN  p_user_id     INT,
  IN  p_type        VARCHAR(20),
  IN  p_qty_delta   INT,
  IN  p_unit_price  DECIMAL(12,2),
  IN  p_reference   VARCHAR(100),
  IN  p_notes       TEXT,
  OUT p_new_qty     INT,
  OUT p_alert_triggered TINYINT
)
BEGIN
  DECLARE v_qty_before    INT;
  DECLARE v_qty_after     INT;
  DECLARE v_threshold     INT;

  START TRANSACTION;

  SELECT `quantity`, `low_stock_threshold`
    INTO v_qty_before, v_threshold
    FROM `products`
   WHERE `id` = p_product_id
     FOR UPDATE;

  SET v_qty_after = v_qty_before + p_qty_delta;

  IF v_qty_after < 0 THEN
    ROLLBACK;
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Insufficient stock for this operation.';
  END IF;

  UPDATE `products` SET `quantity` = v_qty_after WHERE `id` = p_product_id;

  INSERT INTO `stock_transactions`
    (`product_id`,`user_id`,`type`,`quantity`,`quantity_before`,`quantity_after`,`unit_price`,`reference`,`notes`)
  VALUES
    (p_product_id, p_user_id, p_type, p_qty_delta, v_qty_before, v_qty_after, p_unit_price, p_reference, p_notes);

  SET p_alert_triggered = 0;
  IF v_qty_after <= v_threshold THEN
    INSERT INTO `alerts` (`product_id`,`type`,`message`)
    SELECT p_product_id,
           IF(v_qty_after = 0, 'out_of_stock', 'low_stock'),
           CONCAT(IF(v_qty_after = 0,'⚠ OUT OF STOCK: ','🔔 Low stock alert: '), `name`,
                  ' — only ', v_qty_after, ' ', `unit`, ' remaining.')
      FROM `products` WHERE `id` = p_product_id;
    SET p_alert_triggered = 1;
  END IF;

  COMMIT;

  SET p_new_qty = v_qty_after;
END$$
DELIMITER ;

-- ============================================================
-- VIEW: vw_inventory_summary  (used by dashboard)
-- ============================================================
CREATE VIEW `vw_inventory_summary` AS
SELECT
  c.name                                            AS category,
  c.color_hex,
  COUNT(p.id)                                       AS total_skus,
  SUM(p.quantity)                                   AS total_units,
  SUM(p.quantity * p.unit_price)                    AS total_value,
  SUM(CASE WHEN p.quantity <= p.low_stock_threshold THEN 1 ELSE 0 END) AS low_stock_count
FROM `products` p
JOIN `categories` c ON c.id = p.category_id
WHERE p.status = 'active'
GROUP BY c.id;

-- ============================================================
-- VIEW: vw_recent_transactions
-- ============================================================
CREATE VIEW `vw_recent_transactions` AS
SELECT
  t.id,
  p.name     AS product_name,
  p.sku,
  c.name     AS category,
  c.color_hex,
  t.type,
  t.quantity,
  t.quantity_after,
  t.reference,
  u.full_name AS actor,
  t.created_at
FROM `stock_transactions` t
JOIN `products`    p ON p.id = t.product_id
JOIN `categories`  c ON c.id = p.category_id
JOIN `users`       u ON u.id = t.user_id
ORDER BY t.created_at DESC
LIMIT 50;
