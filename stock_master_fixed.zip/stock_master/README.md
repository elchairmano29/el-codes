# 🏬 Stock Master — World-Class Mall Inventory System

A premium glassmorphism inventory management system built for a luxury shopping mall.
Stack: **PHP 8.x + MariaDB + Apache (XAMPP)**

---

## 📁 File Structure

```
stock_master/
├── index.php                    ← Entry point (redirects to login/dashboard)
├── login.php                    ← Deep Space glassmorphism login
├── signup.php                   ← Sunset Aurora glassmorphism signup
├── dashboard.php                ← Main app: dashboard / inventory / alerts views
├── logout.php                   ← Session destroyer
│
├── includes/
│   ├── config.php               ← App constants, DB credentials, session setup
│   ├── db.php                   ← PDO singleton + query helpers
│   └── auth.php                 ← Login, register, CSRF, session helpers
│
├── modules/
│   └── inventory/
│       ├── inventory.php        ← All inventory CRUD + dashboard stats logic
│       └── ajax.php             ← JSON API endpoint (AJAX stock updates, alerts)
│
├── assets/
│   ├── css/
│   │   └── glass.css            ← Full glassmorphism design system (3 themes)
│   └── js/
│       └── app.js               ← AJAX stock updates, modals, toasts, live polling
│
└── database/
    └── schema.sql               ← Complete DB schema + seed data
```

---

## ⚙️ Installation

### 1. Place files
Copy the `stock_master/` folder into your XAMPP `htdocs` directory:
```
C:\xampp\htdocs\stock_master\   (Windows)
/Applications/XAMPP/htdocs/stock_master/   (macOS)
```

### 2. Start XAMPP services
Start **Apache** and **MySQL** from the XAMPP Control Panel.

### 3. Create the database
1. Open **phpMyAdmin**: http://localhost/phpmyadmin
2. Click **Import** tab
3. Choose file: `stock_master/database/schema.sql`
4. Click **Go**

### 4. Configure credentials (if needed)
Edit `includes/config.php`:
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'stock_master');
define('DB_USER', 'root');
define('DB_PASS', '');          // Set your XAMPP MySQL password if any
define('BASE_URL', 'http://localhost/stock_master');
```

### 5. Launch
Open: **http://localhost/stock_master**

---

## 🔑 Demo Login

| Field    | Value                     |
|----------|---------------------------|
| Email    | admin@stockmaster.com     |
| Password | Admin@1234                |

---

## 🎨 UI Themes

| Page       | Theme           | Colors                          |
|------------|-----------------|----------------------------------|
| Login      | Deep Space      | Midnight navy → violet → magenta |
| Signup     | Sunset Aurora   | Coral → amber → teal             |
| Dashboard  | Arctic Crystal  | Deep slate → sapphire → cyan     |

---

## ✨ Features

### Authentication
- bcrypt password hashing (cost 12)
- CSRF token protection on all forms
- Session expiry (8 hours, refreshed on activity)
- Role-based: admin / manager / staff

### Inventory Management
- **4 categories**: Furniture, Tech & Electronics, Appliances, Food & Beverage
- Full CRUD with SKU validation
- Supplier management
- Bin/shelf location tracking
- Batch number support

### Stock Tracking
- Atomic stock transactions (MySQL stored procedure)
- Transaction types: purchase, sale, adjustment, return, transfer, loss
- Full audit trail with `quantity_before` / `quantity_after`
- Automated low-stock and out-of-stock alerts
- Serial number tracking for tech & machinery (unique per unit)

### Dashboard
- Animated stat cards (total SKUs, units, portfolio value, alerts)
- Category value breakdown with progress bars
- Recent activity feed
- Low-stock warning cards
- Alerts panel with live polling (every 30s)

### AJAX / Dynamic
- ± quick-adjust buttons update qty without page reload
- Stock adjustment modal (type, quantity, reference, notes)
- Serial number management modal
- Toast notifications
- Alert badge live updates

---

## 🔒 Security Notes
- All DB queries use **PDO prepared statements** (no SQL injection possible)
- All output uses `htmlspecialchars()` (XSS prevention)
- CSRF tokens on every state-changing form and AJAX call
- Passwords are **never** stored in plain text
- Sessions use `httponly` cookies and strict mode

---

## 🗄️ Key Database Objects

| Object                    | Type      | Purpose                              |
|---------------------------|-----------|--------------------------------------|
| `users`                   | Table     | Auth + role management               |
| `categories`              | Table     | 4 product categories                 |
| `suppliers`               | Table     | Supplier master data                 |
| `products`                | Table     | Core inventory (SKUs)                |
| `serial_numbers`          | Table     | Per-unit serial tracking             |
| `stock_transactions`      | Table     | Full audit log of every stock move   |
| `alerts`                  | Table     | Auto-generated low/out-of-stock alerts|
| `log_stock_transaction`   | Procedure | Atomic qty update + transaction log  |
| `vw_inventory_summary`    | View      | Category rollup for dashboard        |
| `vw_recent_transactions`  | View      | Latest 50 transactions, enriched     |
