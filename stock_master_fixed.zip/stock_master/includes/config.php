<?php
// ============================================================
// includes/config.php  —  Stock Master Core Configuration
// ============================================================
define('APP_NAME',    'Stock Master');
define('APP_VERSION', '1.0.0');
define('BASE_URL',    'http://localhost/stock_master');

// ── Database ────────────────────────────────────────────────
define('DB_HOST', 'localhost');
define('DB_NAME', 'stock_master');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// ── Session lifetime (seconds) ───────────────────────────────
define('SESSION_LIFETIME', 3600 * 8);   // 8 hours

// ── Low-stock colour thresholds ─────────────────────────────
define('ALERT_CRITICAL', 3);
define('ALERT_WARNING',  10);

// ── Start session securely ──────────────────────────────────
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_strict_mode', 1);
    session_start();
}
