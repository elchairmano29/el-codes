<?php
// ============================================================
// includes/auth.php  —  Authentication helpers
// ============================================================
require_once __DIR__ . '/db.php';

function isLoggedIn(): bool {
    return isset($_SESSION['user_id'])
        && isset($_SESSION['expires'])
        && $_SESSION['expires'] > time();
}

function requireAuth(): void {
    if (!isLoggedIn()) {
        header('Location: ' . BASE_URL . '/login.php');
        exit;
    }
    // Refresh expiry on activity
    $_SESSION['expires'] = time() + SESSION_LIFETIME;
}

function loginUser(string $email, string $password): array {
    $user = DB::fetchOne('SELECT * FROM users WHERE email = ?', [$email]);
    if (!$user || !password_verify($password, $user['password'])) {
        return ['ok' => false, 'msg' => 'Invalid email or password.'];
    }
    // Persist session
    session_regenerate_id(true);
    $_SESSION['user_id']   = $user['id'];
    $_SESSION['user_name'] = $user['full_name'];
    $_SESSION['user_role'] = $user['role'];
    $_SESSION['avatar_color'] = $user['avatar_color'];
    $_SESSION['expires']   = time() + SESSION_LIFETIME;

    DB::query('UPDATE users SET last_login = NOW() WHERE id = ?', [$user['id']]);
    return ['ok' => true];
}

function registerUser(string $name, string $email, string $password): array {
    if (DB::fetchOne('SELECT id FROM users WHERE email = ?', [$email])) {
        return ['ok' => false, 'msg' => 'This email is already registered.'];
    }
    $hash   = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    $colors = ['#6366f1','#f59e0b','#10b981','#ef4444','#8b5cf6','#06b6d4'];
    $color  = $colors[array_rand($colors)];
    DB::query(
        'INSERT INTO users (full_name, email, password, avatar_color) VALUES (?,?,?,?)',
        [$name, $email, $hash, $color]
    );
    return ['ok' => true];
}

function logoutUser(): void {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

function currentUser(): array {
    return [
        'id'     => $_SESSION['user_id']   ?? 0,
        'name'   => $_SESSION['user_name'] ?? 'Guest',
        'role'   => $_SESSION['user_role'] ?? 'staff',
        'color'  => $_SESSION['avatar_color'] ?? '#6366f1',
    ];
}

function csrfToken(): string {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function verifyCsrf(string $token): bool {
    return hash_equals($_SESSION['csrf'] ?? '', $token);
}
