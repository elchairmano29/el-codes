<?php
// ============================================================
// login.php  —  Deep Space Glassmorphism Theme
// ============================================================
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';

// Already logged in
if (isLoggedIn()) {
    header('Location: ' . BASE_URL . '/dashboard.php'); exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrf($_POST['csrf'] ?? '')) {
        $error = 'Security token mismatch. Please refresh.';
    } else {
        $result = loginUser(
            trim($_POST['email']    ?? ''),
            trim($_POST['password'] ?? '')
        );
        if ($result['ok']) {
            header('Location: ' . BASE_URL . '/dashboard.php'); exit;
        }
        $error = $result['msg'];
    }
}
$csrf = csrfToken();
?>
<!DOCTYPE html>
<html lang="en" data-theme="deep-space">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign In — Stock Master</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
<link rel="stylesheet" href="assets/css/glass.css">
<style>
    /* ── Deep Space particle extras ──────────────────────── */
    .nebula-1 { background: radial-gradient(ellipse, #7303c0, #ec38bc); width:350px; height:350px; top:-80px; right:-100px; animation-duration:18s; }
    .nebula-2 { background: radial-gradient(ellipse, #03001e, #7303c0); width:280px; height:280px; bottom:0; left:-80px; animation-duration:24s; animation-delay:-6s; }
    .nebula-3 { background: radial-gradient(ellipse, #ec38bc, #fdeff9); width:200px; height:200px; bottom:30%; right:10%; animation-duration:14s; animation-delay:-3s; }

    /* ── Right info panel ─────────────────────────────────── */
    .split-right {
        display:none;
    }
    @media(min-width:900px){
        .auth-wrapper { flex-direction: row; padding: 0; }
        .auth-left  { flex:1; display:flex; align-items:center; justify-content:center; padding:3rem; }
        .split-right {
            display:flex; flex-direction:column; justify-content:center;
            width:42%; padding:4rem 3.5rem;
            background: rgba(255,255,255,0.03);
            border-left:1px solid rgba(255,255,255,0.08);
        }
    }
    .feature-row {
        display:flex; align-items:flex-start; gap:1rem;
        margin-bottom:1.75rem;
    }
    .feature-icon {
        width:44px; height:44px; flex-shrink:0;
        border-radius:12px;
        display:flex; align-items:center; justify-content:center;
        font-size:1.1rem;
    }
    .feature-title { font-family:'Syne',sans-serif; font-weight:600; font-size:.95rem; margin-bottom:.2rem; }
    .feature-desc  { font-size:.8rem; color:var(--text-secondary); line-height:1.5; }

    .tagline {
        font-family:'Syne',sans-serif; font-weight:800; font-size:2.2rem;
        line-height:1.2; letter-spacing:-.03em;
        background:linear-gradient(135deg,#fff,#ec38bc,#7303c0);
        -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text;
        margin-bottom:2.5rem;
    }
    .version-badge {
        display:inline-flex; align-items:center; gap:.4rem;
        padding:.25rem .75rem;
        background:rgba(236,56,188,.12);
        border:1px solid rgba(236,56,188,.25);
        border-radius:20px;
        font-size:.72rem; font-weight:600; color:#ec38bc;
        letter-spacing:.05em; text-transform:uppercase;
        margin-bottom:1.5rem;
    }

    /* ── Password toggle ──────────────────────────────────── */
    .input-suffix {
        position:absolute; right:.9rem; top:50%;
        transform:translateY(-50%);
        color:var(--text-secondary); cursor:pointer;
        font-size:1rem;
        transition:color .2s;
        background:none; border:none;
        padding:0;
    }
    .input-suffix:hover { color:var(--text-primary); }
    .input-group-glass input[type=password],
    .input-group-glass input[type=text] { padding-right:2.5rem; }
</style>
</head>
<body>

<!-- ── Animated background ──────────────────────────────── -->
<div class="bg-canvas">
    <div class="orb nebula-1"></div>
    <div class="orb nebula-2"></div>
    <div class="orb nebula-3"></div>
</div>
<div class="stars-layer"></div>

<!-- ── Layout ────────────────────────────────────────────── -->
<div class="auth-wrapper" style="position:relative;z-index:1;min-height:100vh">

    <div class="auth-left">
        <div class="auth-card glass">

            <!-- Brand -->
            <div class="brand-mark"><i class="bi bi-boxes"></i></div>
            <div class="brand-title">Stock Master</div>
            <div class="brand-sub">World-class mall inventory intelligence</div>

            <!-- Error flash -->
            <?php if ($error): ?>
            <div class="flash flash-error">
                <i class="bi bi-exclamation-circle-fill"></i>
                <?= htmlspecialchars($error) ?>
            </div>
            <?php endif; ?>

            <!-- Login form -->
            <form method="POST" autocomplete="on" novalidate>
                <input type="hidden" name="csrf" value="<?= $csrf ?>">

                <div class="input-group-glass">
                    <label class="form-label-glass">Email address</label>
                    <i class="bi bi-envelope input-icon"></i>
                    <input class="glass-input" type="email" name="email"
                           placeholder="admin@stockmaster.com"
                           value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                           required autocomplete="username">
                </div>

                <div class="input-group-glass">
                    <label class="form-label-glass">Password</label>
                    <i class="bi bi-lock input-icon"></i>
                    <input class="glass-input" type="password" name="password"
                           id="pwd-input" placeholder="••••••••"
                           required autocomplete="current-password">
                    <button type="button" class="input-suffix" id="pwd-toggle"
                            aria-label="Toggle password visibility">
                        <i class="bi bi-eye" id="pwd-icon"></i>
                    </button>
                </div>

                <div style="display:flex;justify-content:flex-end;margin-top:-.5rem;margin-bottom:.5rem">
                    <a href="#" style="font-size:.8rem;color:var(--accent-1);text-decoration:none">Forgot password?</a>
                </div>

                <button type="submit" class="btn-glass-primary">
                    <i class="bi bi-arrow-right-circle"></i>
                    Sign In to Dashboard
                </button>
            </form>

            <div class="glass-divider">New to Stock Master?</div>

            <a href="signup.php" class="btn-glass-secondary w-100"
               style="display:block;text-align:center;text-decoration:none;padding:.7rem">
                Create an account
            </a>

            <!-- Demo credentials -->
            <div style="margin-top:1.5rem;padding:.9rem;background:rgba(115,3,192,.12);border:1px solid rgba(115,3,192,.25);border-radius:12px">
                <div style="font-size:.72rem;font-weight:600;text-transform:uppercase;letter-spacing:.07em;color:var(--accent-1);margin-bottom:.4rem">Demo credentials</div>
                <div style="font-size:.8rem;color:var(--text-secondary)">
                    <strong style="color:var(--text-primary)">Email:</strong> admin@stockmaster.com<br>
                    <strong style="color:var(--text-primary)">Password:</strong> Admin@1234
                </div>
            </div>
        </div>
    </div>

    <!-- ── Right info panel ──────────────────────────────── -->
    <div class="split-right">
        <div class="version-badge"><i class="bi bi-stars"></i> Premium Edition</div>
        <div class="tagline">Inventory<br>redefined<br>for retail.</div>

        <div class="feature-row">
            <div class="feature-icon" style="background:rgba(115,3,192,.2)">
                <i class="bi bi-graph-up-arrow" style="color:#ec38bc"></i>
            </div>
            <div>
                <div class="feature-title">Real-time Tracking</div>
                <div class="feature-desc">Live stock levels with instant low-stock alerts and automated reorder triggers.</div>
            </div>
        </div>
        <div class="feature-row">
            <div class="feature-icon" style="background:rgba(236,56,188,.15)">
                <i class="bi bi-cpu" style="color:#7303c0"></i>
            </div>
            <div>
                <div class="feature-title">Serial & Batch Control</div>
                <div class="feature-desc">Full traceability for tech, appliances and luxury goods with serial number management.</div>
            </div>
        </div>
        <div class="feature-row">
            <div class="feature-icon" style="background:rgba(253,239,249,.1)">
                <i class="bi bi-shield-check" style="color:#fdeff9"></i>
            </div>
            <div>
                <div class="feature-title">Enterprise Security</div>
                <div class="feature-desc">Role-based access, bcrypt passwords, CSRF protection and SQL injection prevention.</div>
            </div>
        </div>
        <div class="feature-row">
            <div class="feature-icon" style="background:rgba(115,3,192,.2)">
                <i class="bi bi-grid-3x3-gap" style="color:#ec38bc"></i>
            </div>
            <div>
                <div class="feature-title">4 Core Categories</div>
                <div class="feature-desc">Furniture, Tech &amp; Electronics, Appliances, Food &amp; Beverage — all in one hub.</div>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('pwd-toggle').addEventListener('click', function() {
    const inp  = document.getElementById('pwd-input');
    const icon = document.getElementById('pwd-icon');
    const show = inp.type === 'password';
    inp.type    = show ? 'text' : 'password';
    icon.className = show ? 'bi bi-eye-slash' : 'bi bi-eye';
});
</script>
</body>
</html>
