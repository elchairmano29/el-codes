<?php
// ============================================================
// signup.php  —  Sunset Aurora Glassmorphism Theme
// ============================================================
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';

if (isLoggedIn()) {
    header('Location: ' . BASE_URL . '/dashboard.php'); exit;
}

$error   = '';
$success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrf($_POST['csrf'] ?? '')) {
        $error = 'Security token mismatch. Please refresh.';
    } else {
        $name  = trim($_POST['full_name'] ?? '');
        $email = trim($_POST['email']     ?? '');
        $pass  = $_POST['password']       ?? '';
        $conf  = $_POST['confirm']        ?? '';

        if (!$name || !$email || !$pass) {
            $error = 'All fields are required.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Please enter a valid email address.';
        } elseif (strlen($pass) < 8) {
            $error = 'Password must be at least 8 characters.';
        } elseif (!preg_match('/[A-Z]/', $pass) || !preg_match('/[0-9]/', $pass)) {
            $error = 'Password must contain at least one uppercase letter and one number.';
        } elseif ($pass !== $conf) {
            $error = 'Passwords do not match.';
        } else {
            $result = registerUser($name, $email, $pass);
            if ($result['ok']) {
                $success = 'Account created! Redirecting to login…';
                header('Refresh: 2; url=' . BASE_URL . '/login.php');
            } else {
                $error = $result['msg'];
            }
        }
    }
}
$csrf = csrfToken();
?>
<!DOCTYPE html>
<html lang="en" data-theme="sunset-aurora">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Create Account — Stock Master</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
<link rel="stylesheet" href="assets/css/glass.css">
<style>
    /* ── Sunset Aurora specific orbs ─────────────────────── */
    .orb-coral   { background:radial-gradient(ellipse,#ff6b35,#f7c948); width:400px; height:400px; top:-120px; left:-100px; animation-duration:20s; }
    .orb-teal    { background:radial-gradient(ellipse,#1de9b6,#00bcd4); width:300px; height:300px; bottom:-60px; right:-80px; animation-duration:16s; animation-delay:-8s; }
    .orb-amber   { background:radial-gradient(ellipse,#f7c948,#ff8c00); width:220px; height:220px; top:40%; right:5%;  animation-duration:22s; animation-delay:-4s; }

    /* ── Aurora sweep effect ──────────────────────────────── */
    .aurora-sweep {
        position:fixed; top:0; left:0; right:0; height:3px;
        background: linear-gradient(90deg, #ff6b35, #f7c948, #1de9b6, #ff6b35);
        background-size:200% 100%;
        animation:auroraMove 4s linear infinite;
        z-index:10;
    }
    @keyframes auroraMove { to { background-position:200% 0; } }

    /* ── Progress indicator ───────────────────────────────── */
    .pwd-strength { margin-top:.4rem; }
    .strength-bar {
        height:4px; border-radius:2px;
        background:rgba(255,255,255,.1);
        overflow:hidden; margin-bottom:.3rem;
    }
    .strength-fill { height:100%; border-radius:2px; transition:width .3s, background .3s; width:0; }
    .strength-label { font-size:.72rem; color:var(--text-secondary); }

    .auth-card { max-width: 500px; }

    /* ── Stepper dots ─────────────────────────────────────── */
    .steps {
        display:flex; gap:.5rem; align-items:center;
        justify-content:center; margin-bottom:1.75rem;
    }
    .step-dot {
        width:8px; height:8px; border-radius:50%;
        background:rgba(255,255,255,.2);
        transition:background .3s, transform .3s;
    }
    .step-dot.active { background:var(--accent-1); transform:scale(1.3); }
    .step-dot.done   { background:var(--accent-2); }

    .input-suffix {
        position:absolute; right:.9rem; top:50%;
        transform:translateY(-50%);
        color:var(--text-secondary); cursor:pointer;
        font-size:1rem; transition:color .2s;
        background:none; border:none; padding:0;
    }
    .input-suffix:hover { color:var(--text-primary); }
</style>
</head>
<body>

<div class="aurora-sweep"></div>

<!-- Background -->
<div class="bg-canvas">
    <div class="orb orb-coral"></div>
    <div class="orb orb-teal"></div>
    <div class="orb orb-amber"></div>
</div>
<div class="stars-layer" style="--star-color:rgba(255,240,180,.4)"></div>

<div class="auth-wrapper" style="position:relative;z-index:1">
    <div class="auth-card glass">

        <!-- Brand -->
        <div style="text-align:center;margin-bottom:1.75rem">
            <div class="brand-mark" style="margin:0 auto 1rem">
                <i class="bi bi-person-plus-fill"></i>
            </div>
            <div class="brand-title">Create Account</div>
            <div class="brand-sub">Join Stock Master — free forever</div>

            <!-- Step dots -->
            <div class="steps" id="step-dots">
                <div class="step-dot active" id="dot-1"></div>
                <div class="step-dot" id="dot-2"></div>
                <div class="step-dot" id="dot-3"></div>
            </div>
        </div>

        <?php if ($error): ?>
        <div class="flash flash-error">
            <i class="bi bi-exclamation-circle-fill"></i>
            <?= htmlspecialchars($error) ?>
        </div>
        <?php endif; ?>
        <?php if ($success): ?>
        <div class="flash flash-success">
            <i class="bi bi-check-circle-fill"></i>
            <?= htmlspecialchars($success) ?>
        </div>
        <?php endif; ?>

        <form method="POST" autocomplete="on" novalidate id="signup-form">
            <input type="hidden" name="csrf" value="<?= $csrf ?>">

            <div class="input-group-glass">
                <label class="form-label-glass">Full name</label>
                <i class="bi bi-person input-icon"></i>
                <input class="glass-input" type="text" name="full_name" id="inp-name"
                       placeholder="Alexandra Chen"
                       value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>"
                       required autocomplete="name">
            </div>

            <div class="input-group-glass">
                <label class="form-label-glass">Work email</label>
                <i class="bi bi-envelope input-icon"></i>
                <input class="glass-input" type="email" name="email" id="inp-email"
                       placeholder="you@company.com"
                       value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                       required autocomplete="email">
            </div>

            <div class="input-group-glass">
                <label class="form-label-glass">Password</label>
                <i class="bi bi-lock input-icon"></i>
                <input class="glass-input" type="password" name="password" id="inp-pwd"
                       placeholder="Min. 8 chars, 1 uppercase, 1 number"
                       required autocomplete="new-password">
                <button type="button" class="input-suffix" id="pwd-toggle">
                    <i class="bi bi-eye" id="pwd-icon"></i>
                </button>
                <!-- Strength meter -->
                <div class="pwd-strength">
                    <div class="strength-bar">
                        <div class="strength-fill" id="strength-fill"></div>
                    </div>
                    <span class="strength-label" id="strength-label"></span>
                </div>
            </div>

            <div class="input-group-glass">
                <label class="form-label-glass">Confirm password</label>
                <i class="bi bi-lock-fill input-icon"></i>
                <input class="glass-input" type="password" name="confirm" id="inp-conf"
                       placeholder="••••••••"
                       required autocomplete="new-password">
                <span id="match-indicator" style="font-size:.75rem;margin-top:.3rem;display:block"></span>
            </div>

            <!-- Terms checkbox -->
            <label style="display:flex;align-items:flex-start;gap:.75rem;margin-bottom:1rem;cursor:pointer">
                <input type="checkbox" required id="terms-chk"
                       style="margin-top:3px;accent-color:var(--accent-1)">
                <span style="font-size:.8rem;color:var(--text-secondary);line-height:1.5">
                    I agree to the <a href="#" style="color:var(--accent-1)">Terms of Service</a>
                    and <a href="#" style="color:var(--accent-1)">Privacy Policy</a>
                </span>
            </label>

            <button type="submit" class="btn-glass-primary" id="submit-btn">
                <i class="bi bi-rocket-takeoff-fill"></i>
                Create my account
            </button>
        </form>

        <div class="glass-divider">Already have an account?</div>

        <a href="login.php" class="btn-glass-secondary w-100"
           style="display:block;text-align:center;text-decoration:none;padding:.7rem">
            <i class="bi bi-arrow-left-circle"></i> Back to Sign In
        </a>
    </div>
</div>

<script>
/* ── Password strength meter ─────────────────────────────── */
const pwdInput = document.getElementById('inp-pwd');
const fill     = document.getElementById('strength-fill');
const label    = document.getElementById('strength-label');
const conf     = document.getElementById('inp-conf');
const matchEl  = document.getElementById('match-indicator');

const levels = [
    { min:0,  pct:0,   bg:'',         txt:'' },
    { min:1,  pct:25,  bg:'#ef4444',  txt:'Weak' },
    { min:2,  pct:50,  bg:'#f59e0b',  txt:'Fair' },
    { min:3,  pct:75,  bg:'#3b82f6',  txt:'Good' },
    { min:4,  pct:100, bg:'#10b981',  txt:'Strong ✓' },
];
const score = p => [
    p.length >= 8,
    /[A-Z]/.test(p),
    /[0-9]/.test(p),
    /[^A-Za-z0-9]/.test(p),
].filter(Boolean).length;

pwdInput.addEventListener('input', () => {
    const s = score(pwdInput.value);
    const l = levels[s] ?? levels[4];
    fill.style.width = l.pct + '%';
    fill.style.background = l.bg;
    label.textContent = l.txt;
    label.style.color = l.bg;
    checkMatch();
    updateDots(s);
});

conf.addEventListener('input', checkMatch);
function checkMatch() {
    if (!conf.value) { matchEl.textContent=''; return; }
    if (conf.value === pwdInput.value) {
        matchEl.innerHTML='<span style="color:#6ee7b7"><i class="bi bi-check-circle"></i> Passwords match</span>';
    } else {
        matchEl.innerHTML='<span style="color:#fca5a5"><i class="bi bi-x-circle"></i> Passwords do not match</span>';
    }
}

function updateDots(s) {
    for(let i=1;i<=3;i++){
        const d = document.getElementById('dot-'+i);
        if(i<=s)         d.className='step-dot done';
        else if(i===s+1) d.className='step-dot active';
        else             d.className='step-dot';
    }
}

/* ── Toggle show/hide password ─────────────────────────── */
document.getElementById('pwd-toggle').addEventListener('click', function(){
    const show = pwdInput.type==='password';
    pwdInput.type = show ? 'text' : 'password';
    document.getElementById('pwd-icon').className = show ? 'bi bi-eye-slash' : 'bi bi-eye';
});
</script>
</body>
</html>
