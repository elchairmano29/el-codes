<?php
// ============================================================
// modules/inventory/inventory.php  —  Inventory logic
// ============================================================
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/auth.php';

// ── Fetch all products with enriched data ────────────────────
function getProducts(array $filters = []): array {
    $where  = ['p.status != "discontinued"'];
    $params = [];

    if (!empty($filters['category_id'])) {
        $where[]  = 'p.category_id = ?';
        $params[] = (int)$filters['category_id'];
    }
    if (!empty($filters['search'])) {
        $where[]  = '(p.name LIKE ? OR p.sku LIKE ?)';
        $params[] = '%' . $filters['search'] . '%';
        $params[] = '%' . $filters['search'] . '%';
    }
    if (isset($filters['low_stock']) && $filters['low_stock']) {
        $where[] = 'p.quantity <= p.low_stock_threshold';
    }

    $sql = 'SELECT p.*, c.name AS category_name, c.color_hex, c.icon,
                   s.name AS supplier_name
            FROM products p
            JOIN categories c ON c.id = p.category_id
            LEFT JOIN suppliers s ON s.id = p.supplier_id
            WHERE ' . implode(' AND ', $where) . '
            ORDER BY p.updated_at DESC';

    return DB::fetchAll($sql, $params);
}

// ── Single product ────────────────────────────────────────────
function getProduct(int $id): array|false {
    return DB::fetchOne(
        'SELECT p.*, c.name AS category_name, c.color_hex, c.icon,
                s.name AS supplier_name
         FROM products p
         JOIN categories c ON c.id = p.category_id
         LEFT JOIN suppliers s ON s.id = p.supplier_id
         WHERE p.id = ?',
        [$id]
    );
}

// ── Create product ────────────────────────────────────────────
function createProduct(array $d): array {
    // Validate required
    foreach (['sku','name','category_id','unit_price','quantity'] as $f) {
        if (!isset($d[$f]) || $d[$f] === '') {
            return ['ok' => false, 'msg' => "Field '$f' is required."];
        }
    }
    // SKU uniqueness
    if (DB::fetchOne('SELECT id FROM products WHERE sku = ?', [$d['sku']])) {
        return ['ok' => false, 'msg' => 'SKU already exists.'];
    }
    $uid = currentUser()['id'];
    DB::query(
        'INSERT INTO products
           (sku,name,description,category_id,supplier_id,unit,unit_price,
            quantity,low_stock_threshold,requires_serial,batch_number,location,created_by)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',
        [
            $d['sku'], $d['name'], $d['description'] ?? null,
            (int)$d['category_id'], $d['supplier_id'] ?: null,
            $d['unit'] ?? 'pcs', (float)$d['unit_price'],
            (int)$d['quantity'], (int)($d['low_stock_threshold'] ?? 10),
            (int)($d['requires_serial'] ?? 0),
            $d['batch_number'] ?? null, $d['location'] ?? null, $uid,
        ]
    );
    $pid = (int)DB::lastId();
    // Log initial stock as a purchase
    if ((int)$d['quantity'] > 0) {
        adjustStock($pid, (int)$d['quantity'], 'purchase',
                    (float)$d['unit_price'], 'INITIAL', 'Initial stock entry');
    }
    return ['ok' => true, 'id' => $pid];
}

// ── Update product ────────────────────────────────────────────
function updateProduct(int $id, array $d): array {
    DB::query(
        'UPDATE products SET
            name=?, description=?, category_id=?, supplier_id=?,
            unit=?, unit_price=?, low_stock_threshold=?,
            requires_serial=?, batch_number=?, location=?, status=?
         WHERE id=?',
        [
            $d['name'], $d['description'] ?? null,
            (int)$d['category_id'], $d['supplier_id'] ?: null,
            $d['unit'] ?? 'pcs', (float)$d['unit_price'],
            (int)($d['low_stock_threshold'] ?? 10),
            (int)($d['requires_serial'] ?? 0),
            $d['batch_number'] ?? null, $d['location'] ?? null,
            $d['status'] ?? 'active', $id,
        ]
    );
    return ['ok' => true];
}

// ── Adjust stock (calls stored procedure) ────────────────────
function adjustStock(int $pid, int $delta, string $type = 'adjustment',
                     float $price = 0, string $ref = '', string $notes = ''): array {
    $uid = currentUser()['id'];
    try {
        $pdo = DB::conn();
        $stmt = $pdo->prepare(
            'CALL log_stock_transaction(?,?,?,?,?,?,?,@new_qty,@alert)'
        );
        $stmt->execute([$pid, $uid, $type, $delta, $price ?: null, $ref ?: null, $notes ?: null]);
        $stmt->closeCursor();
        $row = DB::fetchOne('SELECT @new_qty AS qty, @alert AS alert');
        return ['ok' => true, 'new_qty' => (int)$row['qty'], 'alert' => (bool)$row['alert']];
    } catch (PDOException $e) {
        return ['ok' => false, 'msg' => $e->getMessage()];
    }
}

// ── Serial number helpers ─────────────────────────────────────
function addSerial(int $pid, string $serial, string $notes = ''): array {
    try {
        DB::query('INSERT INTO serial_numbers (product_id,serial,notes) VALUES (?,?,?)',
                  [$pid, $serial, $notes]);
        return ['ok' => true];
    } catch (PDOException $e) {
        return ['ok' => false, 'msg' => 'Serial already exists.'];
    }
}

function getSerials(int $pid): array {
    return DB::fetchAll(
        'SELECT * FROM serial_numbers WHERE product_id = ? ORDER BY created_at DESC', [$pid]
    );
}

// ── Dashboard summary ─────────────────────────────────────────
function getDashboardStats(): array {
    $summary = DB::fetchAll('SELECT * FROM vw_inventory_summary');
    $totals  = DB::fetchOne(
        'SELECT COUNT(*) AS total_skus,
                SUM(quantity) AS total_units,
                SUM(quantity * unit_price) AS total_value
         FROM products WHERE status="active"'
    );
    $lowStock   = DB::fetchAll(
        'SELECT p.*, c.name AS category_name, c.color_hex
         FROM products p JOIN categories c ON c.id=p.category_id
         WHERE p.quantity <= p.low_stock_threshold AND p.status="active"
         ORDER BY p.quantity ASC LIMIT 8'
    );
    $unreadAlerts = (int)DB::fetchOne(
        'SELECT COUNT(*) AS n FROM alerts WHERE is_read=0'
    )['n'];
    $recentTxns = DB::fetchAll('SELECT * FROM vw_recent_transactions LIMIT 10');
    return compact('summary','totals','lowStock','unreadAlerts','recentTxns');
}

function getAlerts(bool $unreadOnly = false): array {
    $sql = 'SELECT a.*, p.name AS product_name, p.sku
            FROM alerts a JOIN products p ON p.id=a.product_id'
         . ($unreadOnly ? ' WHERE a.is_read=0' : '')
         . ' ORDER BY a.created_at DESC LIMIT 30';
    return DB::fetchAll($sql);
}

function markAlertRead(int $id): void {
    DB::query('UPDATE alerts SET is_read=1 WHERE id=?', [$id]);
}

function markAllAlertsRead(): void {
    DB::query('UPDATE alerts SET is_read=1');
}

function getCategories(): array {
    return DB::fetchAll('SELECT * FROM categories ORDER BY name');
}

function getSuppliers(): array {
    return DB::fetchAll('SELECT id, name FROM suppliers ORDER BY name');
}
