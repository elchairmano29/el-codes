<?php
// ============================================================
// modules/inventory/ajax.php  —  JSON API for dynamic actions
// ============================================================
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/inventory.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    echo json_encode(['ok' => false, 'msg' => 'Unauthenticated.']);
    exit;
}

$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {

    // ── Quick stock adjustment ────────────────────────────────
    case 'adjust_stock':
        if (!verifyCsrf($_POST['csrf'] ?? '')) {
            echo json_encode(['ok'=>false,'msg'=>'CSRF error.']); exit;
        }
        $pid   = (int)($_POST['product_id'] ?? 0);
        $delta = (int)($_POST['delta'] ?? 0);
        $type  = $_POST['type'] ?? 'adjustment';
        $ref   = trim($_POST['reference'] ?? '');
        $notes = trim($_POST['notes'] ?? '');
        if (!$pid || $delta === 0) {
            echo json_encode(['ok'=>false,'msg'=>'Invalid parameters.']); exit;
        }
        $result = adjustStock($pid, $delta, $type, 0, $ref, $notes);
        echo json_encode($result);
        break;

    // ── Fetch product detail (for edit modal) ─────────────────
    case 'get_product':
        $pid  = (int)($_GET['id'] ?? 0);
        $prod = getProduct($pid);
        echo json_encode($prod ?: ['ok'=>false,'msg'=>'Not found.']);
        break;

    // ── Get serial numbers ────────────────────────────────────
    case 'get_serials':
        $pid = (int)($_GET['id'] ?? 0);
        echo json_encode(getSerials($pid));
        break;

    // ── Add serial number ─────────────────────────────────────
    case 'add_serial':
        if (!verifyCsrf($_POST['csrf'] ?? '')) {
            echo json_encode(['ok'=>false,'msg'=>'CSRF error.']); exit;
        }
        $pid    = (int)($_POST['product_id'] ?? 0);
        $serial = trim($_POST['serial'] ?? '');
        if (!$pid || !$serial) {
            echo json_encode(['ok'=>false,'msg'=>'Missing fields.']); exit;
        }
        echo json_encode(addSerial($pid, $serial, $_POST['notes'] ?? ''));
        break;

    // ── Mark alert read ───────────────────────────────────────
    case 'mark_alert':
        $aid = (int)($_POST['alert_id'] ?? 0);
        if ($aid) markAlertRead($aid);
        echo json_encode(['ok'=>true]);
        break;

    case 'mark_all_alerts':
        markAllAlertsRead();
        echo json_encode(['ok'=>true]);
        break;

    // ── Alert count (for badge polling) ──────────────────────
    case 'alert_count':
        $n = (int)DB::fetchOne('SELECT COUNT(*) AS n FROM alerts WHERE is_read=0')['n'];
        echo json_encode(['count' => $n]);
        break;

    // ── Get alerts list ───────────────────────────────────────
    case 'get_alerts':
        echo json_encode(getAlerts(true));
        break;

    default:
        echo json_encode(['ok'=>false,'msg'=>'Unknown action.']);
}
