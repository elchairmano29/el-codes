<?php
// ============================================================
// dashboard.php  —  Main application dashboard
// ============================================================
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/modules/inventory/inventory.php';

requireAuth();

// ── Handle product creation POST ────────────────────────────
$flash = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!verifyCsrf($_POST['csrf'] ?? '')) {
        $flash = ['type'=>'error', 'msg'=>'Security token mismatch.'];
    } elseif ($_POST['action'] === 'create_product') {
        $result = createProduct($_POST);
        $flash  = $result['ok']
            ? ['type'=>'success', 'msg'=>'Product added to inventory.']
            : ['type'=>'error',   'msg'=>$result['msg']];
    } elseif ($_POST['action'] === 'update_product') {
        $result = updateProduct((int)$_POST['product_id'], $_POST);
        $flash  = $result['ok']
            ? ['type'=>'success', 'msg'=>'Product updated successfully.']
            : ['type'=>'error',   'msg'=>$result['msg']];
    } elseif ($_POST['action'] === 'logout') {
        logoutUser();
    }
}

// ── Get current view ─────────────────────────────────────────
$view = $_GET['view'] ?? 'dashboard';

// ── Load data for active view ─────────────────────────────────
$stats      = getDashboardStats();
$filters    = [
    'category_id' => (int)($_GET['cat'] ?? 0),
    'search'      => trim($_GET['q']   ?? ''),
    'low_stock'   => isset($_GET['low']),
];
$products   = getProducts($filters);
$categories = getCategories();
$suppliers  = getSuppliers();
$alerts     = getAlerts(true);
$user       = currentUser();
$csrf       = csrfToken();

// ── Helpers ───────────────────────────────────────────────────
function qtyClass(int $qty, int $threshold): string {
    if ($qty <= 0)          return 'pill-red';
    if ($qty <= $threshold) return 'pill-amber';
    return 'pill-green';
}
function fmtMoney(float $n): string {
    return '$' . number_format($n, 2);
}
function timeAgoPhp(string $dt): string {
    $diff = time() - strtotime($dt);
    if ($diff < 60)    return 'just now';
    if ($diff < 3600)  return round($diff/60)   . 'm ago';
    if ($diff < 86400) return round($diff/3600) . 'h ago';
    return date('d M', strtotime($dt));
}
?>
<!DOCTYPE html>
<html lang="en" data-theme="arctic-crystal">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="csrf" content="<?= $csrf ?>">
<title><?= APP_NAME ?> — Dashboard</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
<link rel="stylesheet" href="assets/css/glass.css">
<style>
/* ── Dashboard-specific extras ─────────────────────────── */
.orb-d1 { background:radial-gradient(ellipse,#4361ee,#00b4d8); width:500px;height:500px; top:-200px;left:-100px; animation-duration:25s; opacity:.15; }
.orb-d2 { background:radial-gradient(ellipse,#00b4d8,#90e0ef); width:350px;height:350px; bottom:-80px;right:-80px; animation-duration:18s;animation-delay:-9s; opacity:.12; }

/* Alerts floating panel */
.alerts-panel {
    position:absolute; top:calc(100% + .5rem); right:0;
    width:340px; z-index:200;
    border-radius:16px; overflow:hidden;
    background:rgba(10,14,39,0.95);
    border:1px solid var(--card-border);
    backdrop-filter:blur(20px);
    box-shadow:0 20px 60px rgba(0,0,0,.5);
    transform:translateY(-8px) scale(.97);
    opacity:0; pointer-events:none;
    transition:opacity .2s, transform .2s;
}
.alerts-panel.open { opacity:1; transform:none; pointer-events:all; }

/* Category progress bars */
.cat-progress { display:flex; align-items:center; gap:1rem; padding:.7rem 0; border-bottom:1px solid rgba(255,255,255,.05); }
.cat-progress:last-child { border-bottom:none; }
.cat-progress-bar { flex:1; height:6px; background:rgba(255,255,255,.08); border-radius:3px; overflow:hidden; }
.cat-progress-fill { height:100%; border-radius:3px; transition:width .8s ease; }

/* Transaction type icons */
.txn-badge { width:32px;height:32px; border-radius:9px; display:flex;align-items:center;justify-content:center; font-size:.85rem; flex-shrink:0; }

/* Topbar position for alerts */
.topbar-right { position:relative; display:flex; gap:.5rem; align-items:center; }

/* Quick adjust inline buttons */
.qty-btn { width:26px;height:26px;border-radius:6px;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);color:var(--text-secondary);cursor:pointer;display:inline-flex;align-items:center;justify-content:center;font-size:.8rem;transition:background .15s,color .15s; }
.qty-btn:hover { background:rgba(0,180,216,.2);color:var(--accent-1); }

/* Product image placeholder */
.prod-avatar { width:36px;height:36px;border-radius:9px;display:flex;align-items:center;justify-content:center;font-size:1.1rem;flex-shrink:0; }

/* Filter bar */
.filter-bar { display:flex;gap:.6rem;flex-wrap:wrap;margin-bottom:1.25rem;align-items:center; }
.filter-pill { padding:.35rem .9rem;border-radius:20px;background:var(--glass-bg);border:1px solid var(--glass-border);color:var(--text-secondary);font-size:.78rem;font-weight:500;cursor:pointer;transition:background .2s,color .2s,border-color .2s;text-decoration:none; }
.filter-pill:hover,.filter-pill.active { background:rgba(0,180,216,.15);border-color:var(--accent-1);color:var(--accent-1); }

/* Value highlight */
.value-highlight { color:var(--accent-1);font-weight:600; }
</style>
</head>
<body>

<!-- BG -->
<div class="bg-canvas">
    <div class="orb orb-d1"></div>
    <div class="orb orb-d2"></div>
</div>

<div class="app-layout">

    <!-- ╔══════════════════════════════════════════════════╗
         ║  SIDEBAR                                         ║
         ╚══════════════════════════════════════════════════╝ -->
    <nav class="sidebar">
        <div class="sidebar-brand">
            <div class="sidebar-brand-icon"><i class="bi bi-boxes"></i></div>
            <div>
                <div class="sidebar-brand-text">Stock Master</div>
                <div class="sidebar-brand-sub">Mall Inventory System</div>
            </div>
        </div>

        <div class="nav-section-label">Overview</div>
        <a href="dashboard.php" class="nav-item <?= $view==='dashboard'?'active':'' ?>">
            <i class="bi bi-grid-1x2"></i> Dashboard
        </a>
        <a href="dashboard.php?view=inventory" class="nav-item <?= $view==='inventory'?'active':'' ?>">
            <i class="bi bi-box-seam"></i> Inventory
        </a>
        <a href="dashboard.php?view=alerts" class="nav-item <?= $view==='alerts'?'active':'' ?>">
            <i class="bi bi-bell"></i> Alerts
            <?php if ($stats['unreadAlerts']): ?>
            <span class="nav-badge"><?= $stats['unreadAlerts'] ?></span>
            <?php endif; ?>
        </a>

        <div class="nav-section-label">Categories</div>
        <?php foreach ($categories as $cat): ?>
        <a href="dashboard.php?view=inventory&cat=<?= $cat['id'] ?>"
           class="nav-item <?= ($view==='inventory' && $filters['category_id']==$cat['id'])?'active':'' ?>">
            <i class="bi <?= htmlspecialchars($cat['icon']) ?>" style="color:<?= $cat['color_hex'] ?>"></i>
            <?= htmlspecialchars($cat['name']) ?>
        </a>
        <?php endforeach; ?>

        <div class="nav-section-label">Management</div>
        <a href="dashboard.php?view=inventory&low=1" class="nav-item <?= isset($_GET['low'])?'active':'' ?>">
            <i class="bi bi-exclamation-triangle" style="color:#ef4444"></i> Low Stock
        </a>
        <a href="#" class="nav-item" onclick="SM.modal.open('modal-add-product');return false">
            <i class="bi bi-plus-circle"></i> Add Product
        </a>

        <!-- Footer -->
        <div class="sidebar-footer">
            <div class="sidebar-user">
                <div class="avatar" style="background:<?= htmlspecialchars($user['color']) ?>">
                    <?= strtoupper(substr($user['name'],0,1)) ?>
                </div>
                <div class="sidebar-user-info">
                    <div class="sidebar-user-name"><?= htmlspecialchars($user['name']) ?></div>
                    <div class="sidebar-user-role"><?= htmlspecialchars($user['role']) ?></div>
                </div>
                <form method="POST" style="margin:0">
                    <input type="hidden" name="csrf"   value="<?= $csrf ?>">
                    <input type="hidden" name="action" value="logout">
                    <button type="submit" class="btn-icon" title="Sign out" style="width:30px;height:30px">
                        <i class="bi bi-box-arrow-right"></i>
                    </button>
                </form>
            </div>
        </div>
    </nav>

    <!-- ╔══════════════════════════════════════════════════╗
         ║  MAIN CONTENT                                    ║
         ╚══════════════════════════════════════════════════╝ -->
    <div class="main-content">

        <!-- Topbar -->
        <header class="topbar">
            <button class="btn-icon" id="btn-menu" style="display:none">
                <i class="bi bi-list"></i>
            </button>
            <div class="topbar-title">
                <?php
                $titles = ['dashboard'=>'Dashboard', 'inventory'=>'Inventory', 'alerts'=>'Alerts'];
                echo $titles[$view] ?? 'Dashboard';
                ?>
            </div>
            <div class="topbar-search">
                <i class="bi bi-search"></i>
                <input type="text" id="table-search" placeholder="Search products…"
                       value="<?= htmlspecialchars($filters['search']) ?>">
            </div>
            <div class="topbar-right">
                <div style="position:relative">
                    <button class="btn-icon" id="btn-alerts" title="Alerts">
                        <i class="bi bi-bell"></i>
                        <?php if ($stats['unreadAlerts']): ?>
                        <span class="badge-dot" id="alert-dot"></span>
                        <?php endif; ?>
                    </button>
                    <span id="alert-badge" style="display:<?= $stats['unreadAlerts']?'inline-block':'none' ?>;position:absolute;top:-4px;right:-4px;background:#ef4444;color:#fff;border-radius:10px;font-size:.65rem;padding:.1rem .4rem;font-weight:700;min-width:18px;text-align:center">
                        <?= $stats['unreadAlerts'] ?>
                    </span>
                    <!-- Alerts dropdown panel -->
                    <div class="alerts-panel" id="alerts-panel"></div>
                </div>
                <a href="#" onclick="SM.modal.open('modal-add-product');return false"
                   class="btn-glass-secondary d-flex align-center gap-2"
                   style="text-decoration:none;white-space:nowrap;padding:.5rem 1rem">
                    <i class="bi bi-plus-lg"></i>
                    <span style="font-size:.85rem">Add Product</span>
                </a>
            </div>
        </header>

        <div class="page-body">

        <?php if ($flash): ?>
        <div class="flash flash-<?= $flash['type'] ?>" style="margin-bottom:1.25rem">
            <i class="bi bi-<?= $flash['type']==='success'?'check-circle-fill':'exclamation-circle-fill' ?>"></i>
            <?= htmlspecialchars($flash['msg']) ?>
        </div>
        <?php endif; ?>

        <?php if ($view === 'dashboard'): ?>
        <!-- ══════════════════════════════════════════════════
             DASHBOARD VIEW
             ══════════════════════════════════════════════════ -->

        <!-- Summary stat cards -->
        <div class="stats-grid">
            <?php
            $statsCards = [
                ['icon'=>'bi-box-seam',       'label'=>'Total SKUs',      'value'=>$stats['totals']['total_skus']  ?? 0,  'color'=>'#4361ee', 'prefix'=>'',  'suffix'=>''],
                ['icon'=>'bi-stack',           'label'=>'Total Units',     'value'=>$stats['totals']['total_units'] ?? 0,  'color'=>'#00b4d8', 'prefix'=>'',  'suffix'=>''],
                ['icon'=>'bi-currency-dollar', 'label'=>'Portfolio Value', 'value'=>$stats['totals']['total_value'] ?? 0,  'color'=>'#10b981', 'prefix'=>'$', 'suffix'=>'', 'float'=>true],
                ['icon'=>'bi-exclamation-triangle','label'=>'Low Stock Alerts','value'=>$stats['unreadAlerts'],           'color'=>'#ef4444', 'prefix'=>'',  'suffix'=>''],
            ];
            foreach($statsCards as $sc): ?>
            <div class="glass-card stat-card">
                <div class="stat-card-glow" style="background:<?= $sc['color'] ?>"></div>
                <div class="stat-icon" style="background:<?= $sc['color'] ?>22">
                    <i class="bi <?= $sc['icon'] ?>" style="color:<?= $sc['color'] ?>"></i>
                </div>
                <div class="stat-value" data-count="<?= $sc['value'] ?>"
                     <?= ($sc['float']??false)?'data-float="true"':'' ?>
                     data-prefix="<?= $sc['prefix'] ?>"
                     style="color:<?= $sc['color'] ?>">
                    <?= $sc['prefix'] . number_format((float)$sc['value'], ($sc['float']??false)?2:0) ?>
                </div>
                <div class="stat-label"><?= $sc['label'] ?></div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- 2-column row: category breakdown + recent transactions -->
        <div style="display:grid;grid-template-columns:1fr 1.6fr;gap:1.5rem;margin-bottom:2rem" class="responsive-grid-2">

            <!-- Category breakdown -->
            <div class="glass-card" style="padding:1.5rem">
                <div class="section-header">
                    <div class="section-title">By Category</div>
                </div>
                <?php
                $maxVal = max(array_column($stats['summary'], 'total_value') ?: [1]);
                foreach($stats['summary'] as $s): ?>
                <div class="cat-progress">
                    <div style="width:120px;font-size:.83rem;display:flex;align-items:center;gap:.5rem;color:var(--text-secondary)">
                        <span class="cat-dot" style="background:<?= $s['color_hex'] ?>"></span>
                        <?= htmlspecialchars($s['category']) ?>
                    </div>
                    <div class="cat-progress-bar">
                        <div class="cat-progress-fill"
                             style="width:<?= round(($s['total_value']/$maxVal)*100) ?>%;background:<?= $s['color_hex'] ?>">
                        </div>
                    </div>
                    <div style="font-size:.78rem;color:var(--text-secondary);white-space:nowrap;text-align:right;min-width:55px">
                        <?= $s['total_skus'] ?> SKUs
                    </div>
                    <?php if($s['low_stock_count']>0): ?>
                    <span class="pill pill-red" style="white-space:nowrap"><?= $s['low_stock_count'] ?>⚠</span>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- Recent transactions -->
            <div class="glass-card" style="padding:1.5rem">
                <div class="section-header">
                    <div class="section-title">Recent Activity</div>
                    <a href="dashboard.php?view=inventory" style="font-size:.8rem;color:var(--accent-1);text-decoration:none">View all →</a>
                </div>
                <div style="display:flex;flex-direction:column;gap:.25rem">
                <?php foreach(array_slice($stats['recentTxns'],0,8) as $t):
                    $txnColors = ['purchase'=>'#10b981','sale'=>'#4361ee','adjustment'=>'#f59e0b','return'=>'#8b5cf6','loss'=>'#ef4444','transfer'=>'#00b4d8'];
                    $txnIcons  = ['purchase'=>'bi-arrow-down-circle','sale'=>'bi-arrow-up-circle','adjustment'=>'bi-pencil','return'=>'bi-arrow-counterclockwise','loss'=>'bi-dash-circle','transfer'=>'bi-arrow-left-right'];
                    $c = $txnColors[$t['type']] ?? '#999';
                    $i = $txnIcons[$t['type']] ?? 'bi-circle';
                ?>
                <div style="display:flex;align-items:center;gap:.85rem;padding:.6rem 0;border-bottom:1px solid rgba(255,255,255,.04)">
                    <div class="txn-badge" style="background:<?= $c ?>22">
                        <i class="bi <?= $i ?>" style="color:<?= $c ?>"></i>
                    </div>
                    <div style="flex:1;min-width:0">
                        <div style="font-size:.83rem;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
                            <?= htmlspecialchars($t['product_name']) ?>
                        </div>
                        <div style="font-size:.72rem;color:var(--text-secondary)">
                            <?= ucfirst($t['type']) ?> · <?= htmlspecialchars($t['actor']) ?>
                        </div>
                    </div>
                    <div style="text-align:right;flex-shrink:0">
                        <div style="font-size:.83rem;font-weight:600;color:<?= $c ?>">
                            <?= ($t['quantity']>0?'+':''). $t['quantity'] ?>
                        </div>
                        <div style="font-size:.7rem;color:var(--text-secondary)"><?= timeAgoPhp($t['created_at']) ?></div>
                    </div>
                </div>
                <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- Low stock warnings -->
        <?php if(!empty($stats['lowStock'])): ?>
        <div class="section-header"><div class="section-title">⚠ Low Stock Items</div></div>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:1rem;margin-bottom:2rem">
            <?php foreach($stats['lowStock'] as $ls): ?>
            <div class="glass-card" style="padding:1.25rem;border-left:3px solid <?= $ls['quantity']<=3?'#ef4444':'#f59e0b' ?>">
                <div style="display:flex;align-items:center;gap:.75rem;margin-bottom:.75rem">
                    <div class="prod-avatar" style="background:<?= htmlspecialchars($ls['color_hex']) ?>22">
                        <i class="bi bi-box-seam" style="color:<?= htmlspecialchars($ls['color_hex']) ?>"></i>
                    </div>
                    <div style="flex:1;min-width:0">
                        <div style="font-size:.85rem;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
                            <?= htmlspecialchars($ls['name']) ?>
                        </div>
                        <div style="font-size:.72rem;color:var(--text-secondary)"><?= htmlspecialchars($ls['sku']) ?></div>
                    </div>
                    <span class="pill <?= $ls['quantity']<=3?'pill-red':'pill-amber' ?>">
                        <?= $ls['quantity'] ?> left
                    </span>
                </div>
                <div class="stock-bar">
                    <div class="stock-bar-fill"
                         style="width:<?= min(100,round(($ls['quantity']/$ls['low_stock_threshold'])*100)) ?>%;background:<?= $ls['quantity']<=3?'#ef4444':'#f59e0b' ?>">
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <?php elseif($view==='inventory'): ?>
        <!-- ══════════════════════════════════════════════════
             INVENTORY TABLE VIEW
             ══════════════════════════════════════════════════ -->
        <!-- Filter pills -->
        <div class="filter-bar">
            <a href="dashboard.php?view=inventory"
               class="filter-pill <?= !$filters['category_id']&&!$filters['low_stock']?'active':'' ?>">All</a>
            <?php foreach($categories as $cat): ?>
            <a href="dashboard.php?view=inventory&cat=<?= $cat['id'] ?>"
               class="filter-pill <?= $filters['category_id']==$cat['id']?'active':'' ?>"
               style="<?= $filters['category_id']==$cat['id']?'color:'.$cat['color_hex'].';border-color:'.$cat['color_hex'].';background:'.$cat['color_hex'].'18':'' ?>">
                <i class="bi <?= $cat['icon'] ?>"></i> <?= htmlspecialchars($cat['name']) ?>
            </a>
            <?php endforeach; ?>
            <a href="dashboard.php?view=inventory&low=1"
               class="filter-pill <?= $filters['low_stock']?'active':'' ?>"
               style="<?= $filters['low_stock']?'color:#ef4444;border-color:#ef4444;background:#ef444418':'' ?>">
                ⚠ Low Stock
            </a>
            <div style="margin-left:auto;font-size:.78rem;color:var(--text-secondary)">
                <?= count($products) ?> products
            </div>
        </div>

        <!-- Inventory table -->
        <div class="glass-table-wrap">
            <table class="glass-table">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Category</th>
                        <th>SKU / Batch</th>
                        <th>Quantity</th>
                        <th>Unit Price</th>
                        <th>Total Value</th>
                        <th>Location</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if(empty($products)): ?>
                    <tr><td colspan="9" style="text-align:center;padding:3rem;color:var(--text-secondary)">
                        <i class="bi bi-inbox" style="font-size:2rem;display:block;margin-bottom:.5rem"></i>
                        No products found
                    </td></tr>
                <?php endif; ?>
                <?php foreach($products as $p):
                    $qc = qtyClass((int)$p['quantity'], (int)$p['low_stock_threshold']);
                ?>
                <tr class="product-row" data-category="<?= $p['category_id'] ?>" data-product-id="<?= $p['id'] ?>">
                    <td>
                        <div style="display:flex;align-items:center;gap:.75rem">
                            <div class="prod-avatar" style="background:<?= htmlspecialchars($p['color_hex']) ?>22">
                                <i class="bi <?= htmlspecialchars($p['icon']) ?>" style="color:<?= htmlspecialchars($p['color_hex']) ?>"></i>
                            </div>
                            <div>
                                <div style="font-weight:500;font-size:.88rem"><?= htmlspecialchars($p['name']) ?></div>
                                <?php if($p['supplier_name']): ?>
                                <div style="font-size:.72rem;color:var(--text-secondary)"><?= htmlspecialchars($p['supplier_name']) ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </td>
                    <td>
                        <span class="cat-chip">
                            <span class="cat-dot" style="background:<?= $p['color_hex'] ?>"></span>
                            <?= htmlspecialchars($p['category_name']) ?>
                        </span>
                    </td>
                    <td>
                        <div style="font-size:.82rem;font-family:monospace;color:var(--accent-1)"><?= htmlspecialchars($p['sku']) ?></div>
                        <?php if($p['batch_number']): ?>
                        <div style="font-size:.7rem;color:var(--text-secondary)"><?= htmlspecialchars($p['batch_number']) ?></div>
                        <?php endif; ?>
                        <?php if($p['requires_serial']): ?>
                        <span class="pill pill-purple" style="margin-top:.2rem"><i class="bi bi-upc"></i> Serial</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div style="display:flex;align-items:center;gap:.4rem">
                            <button class="qty-btn" data-adjust="<?= $p['id'] ?>" data-delta="-1" title="Remove 1">−</button>
                            <span class="pill <?= $qc ?>">
                                <span class="qty-display"><?= $p['quantity'] ?></span>
                                <?= htmlspecialchars($p['unit']) ?>
                            </span>
                            <button class="qty-btn" data-adjust="<?= $p['id'] ?>" data-delta="1" title="Add 1">+</button>
                        </div>
                        <div class="stock-bar" style="margin-top:.35rem;width:80px">
                            <div class="stock-bar-fill"
                                 data-max="<?= max($p['quantity'], $p['low_stock_threshold']*3) ?>"
                                 style="width:<?= min(100,round(($p['quantity']/max($p['quantity'],$p['low_stock_threshold']*3))*100)) ?>%;
                                        background:<?= $p['quantity']<=3?'#ef4444':($p['quantity']<=$p['low_stock_threshold']?'#f59e0b':'#10b981') ?>">
                            </div>
                        </div>
                    </td>
                    <td class="value-highlight"><?= fmtMoney((float)$p['unit_price']) ?></td>
                    <td style="font-weight:600"><?= fmtMoney($p['quantity'] * $p['unit_price']) ?></td>
                    <td style="font-size:.8rem;color:var(--text-secondary)"><?= htmlspecialchars($p['location'] ?? '—') ?></td>
                    <td>
                        <span class="pill <?= $p['status']==='active'?'pill-green':'pill-red' ?>">
                            <?= ucfirst($p['status']) ?>
                        </span>
                    </td>
                    <td>
                        <div style="display:flex;gap:.4rem">
                            <button class="btn-icon"
                                    data-open-adjust="<?= $p['id'] ?>"
                                    data-product-name="<?= htmlspecialchars($p['name']) ?>"
                                    title="Adjust stock" style="width:30px;height:30px;font-size:.85rem">
                                <i class="bi bi-arrow-left-right"></i>
                            </button>
                            <button class="btn-icon"
                                    onclick="openEditModal(<?= $p['id'] ?>)"
                                    title="Edit product" style="width:30px;height:30px;font-size:.85rem">
                                <i class="bi bi-pencil"></i>
                            </button>
                            <?php if($p['requires_serial']): ?>
                            <button class="btn-icon"
                                    onclick="openSerialModal(<?= $p['id'] ?>,'<?= htmlspecialchars($p['name'],ENT_QUOTES) ?>')"
                                    title="Manage serials" style="width:30px;height:30px;font-size:.85rem">
                                <i class="bi bi-upc-scan"></i>
                            </button>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php elseif($view==='alerts'): ?>
        <!-- ══════════════════════════════════════════════════
             ALERTS VIEW
             ══════════════════════════════════════════════════ -->
        <div class="section-header">
            <div class="section-title">Unread Alerts (<?= count($alerts) ?>)</div>
            <button onclick="SM.markAllAlerts()" class="btn-glass-secondary">
                <i class="bi bi-check-all"></i> Mark all read
            </button>
        </div>
        <div class="glass-card">
            <?php if(empty($alerts)): ?>
            <div style="text-align:center;padding:3rem;color:var(--text-secondary)">
                <i class="bi bi-bell-slash" style="font-size:2rem;display:block;margin-bottom:.5rem"></i>
                No unread alerts — all clear!
            </div>
            <?php endif; ?>
            <?php foreach($alerts as $a): ?>
            <div class="alert-item unread" data-alert-id="<?= $a['id'] ?>"
                 onclick="SM.markAlert(<?= $a['id'] ?>, this)">
                <div class="alert-dot"></div>
                <div style="flex:1">
                    <div class="alert-msg"><?= htmlspecialchars($a['message']) ?></div>
                    <div style="font-size:.72rem;color:var(--text-secondary);margin-top:.25rem">
                        <strong><?= htmlspecialchars($a['product_name']) ?></strong>
                        · SKU: <?= htmlspecialchars($a['sku']) ?>
                        · <?= timeAgoPhp($a['created_at']) ?>
                    </div>
                </div>
                <span class="pill pill-<?= $a['type']==='out_of_stock'?'red':'amber' ?>"><?= ucfirst(str_replace('_',' ',$a['type'])) ?></span>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        </div><!-- /page-body -->
    </div><!-- /main-content -->
</div><!-- /app-layout -->

<!-- ════════════════════════════════════════════════════════
     MODAL: Add Product
     ════════════════════════════════════════════════════════ -->
<div class="modal-overlay" id="modal-add-product">
    <div class="modal-box glass">
        <div class="modal-header">
            <div class="modal-title"><i class="bi bi-plus-circle" style="color:var(--accent-1)"></i> Add New Product</div>
            <button class="modal-close"><i class="bi bi-x"></i></button>
        </div>
        <form method="POST">
            <input type="hidden" name="csrf"   value="<?= $csrf ?>">
            <input type="hidden" name="action" value="create_product">
            <div class="grid-2">
                <div>
                    <label class="form-label-glass">Product Name *</label>
                    <input class="glass-input" type="text" name="name" required placeholder="Premium Sofa">
                </div>
                <div>
                    <label class="form-label-glass">SKU *</label>
                    <input class="glass-input" type="text" name="sku" required placeholder="FRN-005">
                </div>
            </div>
            <div class="grid-2" style="margin-top:1rem">
                <div>
                    <label class="form-label-glass">Category *</label>
                    <select class="glass-input" name="category_id" required>
                        <option value="">Select…</option>
                        <?php foreach($categories as $c): ?>
                        <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="form-label-glass">Supplier</label>
                    <select class="glass-input" name="supplier_id">
                        <option value="">None</option>
                        <?php foreach($suppliers as $s): ?>
                        <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="grid-2" style="margin-top:1rem">
                <div>
                    <label class="form-label-glass">Unit Price ($) *</label>
                    <input class="glass-input" type="number" name="unit_price" step=".01" min="0" required placeholder="0.00">
                </div>
                <div>
                    <label class="form-label-glass">Initial Qty *</label>
                    <input class="glass-input" type="number" name="quantity" min="0" required placeholder="0">
                </div>
            </div>
            <div class="grid-2" style="margin-top:1rem">
                <div>
                    <label class="form-label-glass">Unit</label>
                    <input class="glass-input" type="text" name="unit" placeholder="pcs" value="pcs">
                </div>
                <div>
                    <label class="form-label-glass">Low Stock Alert ≤</label>
                    <input class="glass-input" type="number" name="low_stock_threshold" min="1" value="10">
                </div>
            </div>
            <div class="grid-2" style="margin-top:1rem">
                <div>
                    <label class="form-label-glass">Batch Number</label>
                    <input class="glass-input" type="text" name="batch_number" placeholder="BATCH-XXX-24A">
                </div>
                <div>
                    <label class="form-label-glass">Location</label>
                    <input class="glass-input" type="text" name="location" placeholder="W1-A1-S1">
                </div>
            </div>
            <div style="margin-top:1rem">
                <label class="form-label-glass">Description</label>
                <textarea class="glass-input" name="description" rows="2" placeholder="Optional product description…" style="resize:vertical"></textarea>
            </div>
            <label style="display:flex;align-items:center;gap:.6rem;margin-top:1rem;cursor:pointer">
                <input type="checkbox" name="requires_serial" value="1" style="accent-color:var(--accent-1)">
                <span style="font-size:.85rem;color:var(--text-secondary)">Requires serial number tracking</span>
            </label>
            <button type="submit" class="btn-glass-primary" style="margin-top:1.5rem">
                <i class="bi bi-plus-circle"></i> Add Product
            </button>
        </form>
    </div>
</div>

<!-- ════════════════════════════════════════════════════════
     MODAL: Stock Adjustment
     ════════════════════════════════════════════════════════ -->
<div class="modal-overlay" id="modal-adjust">
    <div class="modal-box glass" style="max-width:420px">
        <div class="modal-header">
            <div class="modal-title"><i class="bi bi-arrow-left-right" style="color:var(--accent-1)"></i> Adjust Stock</div>
            <button class="modal-close"><i class="bi bi-x"></i></button>
        </div>
        <p style="font-size:.85rem;color:var(--text-secondary);margin-bottom:1.25rem" id="adj-product-name"></p>
        <form id="form-adjust">
            <input type="hidden" name="product_id" id="adj-product-id">
            <div style="margin-bottom:1rem">
                <label class="form-label-glass">Transaction Type</label>
                <select class="glass-input" name="type" id="adj-type">
                    <option value="purchase">📦 Purchase (add stock)</option>
                    <option value="sale">🛒 Sale (remove stock)</option>
                    <option value="adjustment">✏ Manual Adjustment</option>
                    <option value="return">↩ Return</option>
                    <option value="transfer">⇄ Transfer</option>
                    <option value="loss">❌ Loss / Damage</option>
                </select>
            </div>
            <div class="grid-2">
                <div>
                    <label class="form-label-glass">Quantity (+/−) *</label>
                    <input class="glass-input" type="number" name="delta" id="adj-delta" required placeholder="+10 or -5">
                </div>
                <div>
                    <label class="form-label-glass">Reference #</label>
                    <input class="glass-input" type="text" name="reference" id="adj-ref" placeholder="PO-12345">
                </div>
            </div>
            <div style="margin-top:1rem">
                <label class="form-label-glass">Notes</label>
                <textarea class="glass-input" name="notes" id="adj-notes" rows="2" placeholder="Optional note…" style="resize:vertical"></textarea>
            </div>
            <button type="submit" class="btn-glass-primary" style="margin-top:1.25rem">
                <i class="bi bi-check-lg"></i> Save
            </button>
        </form>
    </div>
</div>

<!-- ════════════════════════════════════════════════════════
     MODAL: Serial Numbers
     ════════════════════════════════════════════════════════ -->
<div class="modal-overlay" id="modal-serials">
    <div class="modal-box glass" style="max-width:480px">
        <div class="modal-header">
            <div class="modal-title"><i class="bi bi-upc-scan" style="color:var(--accent-1)"></i> Serial Numbers</div>
            <button class="modal-close"><i class="bi bi-x"></i></button>
        </div>
        <p style="font-size:.85rem;color:var(--text-secondary);margin-bottom:1rem" id="serial-product-name"></p>
        <!-- Add serial form -->
        <div style="display:flex;gap:.5rem;margin-bottom:1rem">
            <input class="glass-input" type="text" id="new-serial-input" placeholder="Enter serial number" style="flex:1">
            <button onclick="addSerial()" class="btn-glass-secondary">Add</button>
        </div>
        <input type="hidden" id="serial-product-id">
        <!-- Serials list -->
        <div id="serials-list" style="max-height:280px;overflow-y:auto;font-size:.83rem">
            <div style="color:var(--text-secondary);text-align:center;padding:2rem">Loading…</div>
        </div>
    </div>
</div>

<script src="assets/js/app.js"></script>
<script>
/* ── Edit product modal ────────────────────────────────── */
async function openEditModal(id) {
    const p = await fetch(`modules/inventory/ajax.php?action=get_product&id=${id}&csrf=<?= $csrf ?>`).then(r=>r.json());
    if (!p || !p.id) { SM.toast('Failed to load product.','error'); return; }

    const modal = document.getElementById('modal-add-product');
    modal.querySelector('.modal-title').innerHTML = '<i class="bi bi-pencil" style="color:var(--accent-1)"></i> Edit Product';
    const form = modal.querySelector('form');
    form.action.value = 'update_product';

    // Add hidden product_id if not present
    let pidInput = form.querySelector('[name=product_id]');
    if (!pidInput) {
        pidInput = document.createElement('input');
        pidInput.type = 'hidden'; pidInput.name = 'product_id';
        form.appendChild(pidInput);
    }
    pidInput.value = p.id;

    // Populate fields
    const set = (n, v) => { const el = form.querySelector(`[name="${n}"]`); if (el) el.value = v ?? ''; };
    set('name', p.name); set('sku', p.sku);
    set('category_id', p.category_id); set('supplier_id', p.supplier_id ?? '');
    set('unit_price', p.unit_price); set('quantity', p.quantity);
    set('unit', p.unit); set('low_stock_threshold', p.low_stock_threshold);
    set('batch_number', p.batch_number); set('location', p.location);
    set('description', p.description); set('status', p.status);
    const sr = form.querySelector('[name=requires_serial]');
    if (sr) sr.checked = !!p.requires_serial;

    SM.modal.open('modal-add-product');
}

/* ── Serial modal ────────────────────────────────────── */
async function openSerialModal(id, name) {
    document.getElementById('serial-product-id').value = id;
    document.getElementById('serial-product-name').textContent = name;
    SM.modal.open('modal-serials');
    await loadSerials(id);
}

async function loadSerials(id) {
    const list = document.getElementById('serials-list');
    list.innerHTML = '<div style="color:var(--text-secondary);text-align:center;padding:1.5rem">Loading…</div>';
    const serials = await fetch(`modules/inventory/ajax.php?action=get_serials&id=${id}&csrf=<?= $csrf ?>`).then(r=>r.json());
    if (!serials.length) {
        list.innerHTML = '<div style="color:var(--text-secondary);text-align:center;padding:1.5rem">No serials registered yet.</div>';
        return;
    }
    const statusColors = {available:'pill-green',sold:'pill-blue',reserved:'pill-amber',faulty:'pill-red'};
    list.innerHTML = serials.map(s=>`
        <div style="display:flex;align-items:center;gap:.75rem;padding:.6rem 0;border-bottom:1px solid rgba(255,255,255,.05)">
            <i class="bi bi-upc" style="color:var(--accent-1)"></i>
            <span style="font-family:monospace;flex:1">${s.serial}</span>
            <span class="pill ${statusColors[s.status]??'pill-blue'}">${s.status}</span>
        </div>`).join('');
}

async function addSerial() {
    const pid    = document.getElementById('serial-product-id').value;
    const serial = document.getElementById('new-serial-input').value.trim();
    if (!serial) { SM.toast('Please enter a serial number.','warn'); return; }
    const res = await SM.post?.('modules/inventory/ajax.php',{action:'add_serial',product_id:pid,serial}) ??
        await fetch('modules/inventory/ajax.php',{method:'POST',body:new URLSearchParams({action:'add_serial',product_id:pid,serial,csrf:'<?= $csrf ?>'})}).then(r=>r.json());
    if (res.ok) {
        document.getElementById('new-serial-input').value='';
        SM.toast('Serial added.','success');
        loadSerials(pid);
    } else {
        SM.toast(res.msg??'Error','error');
    }
}
</script>
</body>
</html>
