/* ============================================================
   Stock Master — assets/js/app.js
   Dynamic interactions: AJAX, modals, toasts, live poll
   ============================================================ */
'use strict';

const SM = (() => {

    /* ── CSRF token from meta tag ──────────────────────────── */
    const csrf = () => document.querySelector('meta[name="csrf"]')?.content ?? '';

    /* ── Toast notifications ───────────────────────────────── */
    const toast = (() => {
        const container = (() => {
            let el = document.querySelector('.toast-container');
            if (!el) {
                el = document.createElement('div');
                el.className = 'toast-container';
                document.body.appendChild(el);
            }
            return el;
        })();

        const icons = { success:'bi-check-circle-fill', error:'bi-x-circle-fill',
                        warn:'bi-exclamation-triangle-fill', info:'bi-info-circle-fill' };
        const colors = { success:'#6ee7b7', error:'#fca5a5', warn:'#fcd34d', info:'#93c5fd' };

        return (msg, type = 'info', duration = 3500) => {
            const t = document.createElement('div');
            t.className = 'toast';
            t.innerHTML = `
                <i class="bi ${icons[type]} toast-icon" style="color:${colors[type]}"></i>
                <span>${msg}</span>`;
            container.appendChild(t);
            setTimeout(() => {
                t.classList.add('leaving');
                t.addEventListener('animationend', () => t.remove());
            }, duration);
        };
    })();

    /* ── AJAX helper ───────────────────────────────────────── */
    const post = async (url, data) => {
        const fd = new FormData();
        Object.entries({ ...data, csrf: csrf() }).forEach(([k,v]) => fd.append(k, v));
        const r = await fetch(url, { method: 'POST', body: fd });
        return r.json();
    };

    const get = async (url, params = {}) => {
        const qs = new URLSearchParams({ ...params, csrf: csrf() }).toString();
        const r  = await fetch(`${url}?${qs}`);
        return r.json();
    };

    /* ── Modal system ──────────────────────────────────────── */
    const modal = (() => {
        const open  = id => document.getElementById(id)?.classList.add('open');
        const close = id => document.getElementById(id)?.classList.remove('open');

        document.addEventListener('click', e => {
            if (e.target.classList.contains('modal-overlay')) {
                e.target.classList.remove('open');
            }
            if (e.target.classList.contains('modal-close')) {
                e.target.closest('.modal-overlay')?.classList.remove('open');
            }
        });
        document.addEventListener('keydown', e => {
            if (e.key === 'Escape')
                document.querySelectorAll('.modal-overlay.open')
                    .forEach(m => m.classList.remove('open'));
        });
        return { open, close };
    })();

    /* ── Quick stock adjustment ────────────────────────────── */
    const initStockAdjust = () => {
        document.addEventListener('click', async e => {
            const btn = e.target.closest('[data-adjust]');
            if (!btn) return;
            const pid   = btn.dataset.adjust;
            const delta = parseInt(btn.dataset.delta ?? (btn.dataset.adjustType === 'add' ? 1 : -1));
            const row   = btn.closest('tr');
            const qtyEl = row?.querySelector('.qty-display');

            btn.disabled = true;
            try {
                const res = await post(
                    'modules/inventory/ajax.php',
                    { action: 'adjust_stock', product_id: pid, delta, type: 'adjustment' }
                );
                if (res.ok) {
                    if (qtyEl) {
                        qtyEl.textContent = res.new_qty;
                        qtyEl.closest('.pill')?.setAttribute('class',
                            `pill ${res.new_qty <= 3 ? 'pill-red' : res.new_qty <= 10 ? 'pill-amber' : 'pill-green'}`);
                        updateStockBar(row, res.new_qty);
                    }
                    toast(res.alert ? `⚠ Low stock alert triggered!` : 'Stock updated.', res.alert ? 'warn' : 'success');
                    if (res.alert) refreshAlertBadge();
                } else {
                    toast(res.msg ?? 'Error updating stock.', 'error');
                }
            } catch { toast('Network error.', 'error'); }
            finally  { btn.disabled = false; }
        });
    };

    const updateStockBar = (row, qty) => {
        const max  = parseInt(row?.querySelector('.stock-bar-fill')?.dataset.max ?? 100);
        const fill = row?.querySelector('.stock-bar-fill');
        if (!fill) return;
        const pct  = Math.min(100, Math.round((qty / max) * 100));
        fill.style.width = pct + '%';
        fill.style.background = qty <= 3 ? '#ef4444' : qty <= 10 ? '#f59e0b' : '#10b981';
    };

    /* ── Stock adjustment modal ────────────────────────────── */
    const initAdjustModal = () => {
        document.addEventListener('click', e => {
            const btn = e.target.closest('[data-open-adjust]');
            if (!btn) return;
            const pid  = btn.dataset.openAdjust;
            const name = btn.dataset.productName;
            document.getElementById('adj-product-id').value = pid;
            document.getElementById('adj-product-name').textContent = name;
            document.getElementById('adj-delta').value = '';
            document.getElementById('adj-type').value = 'adjustment';
            document.getElementById('adj-ref').value = '';
            document.getElementById('adj-notes').value = '';
            modal.open('modal-adjust');
        });

        document.getElementById('form-adjust')?.addEventListener('submit', async e => {
            e.preventDefault();
            const fd  = new FormData(e.target);
            const btn = e.target.querySelector('[type=submit]');
            btn.disabled = true; btn.textContent = 'Saving…';
            try {
                const res = await post('modules/inventory/ajax.php', {
                    action:     'adjust_stock',
                    product_id: fd.get('product_id'),
                    delta:      fd.get('delta'),
                    type:       fd.get('type'),
                    reference:  fd.get('reference'),
                    notes:      fd.get('notes'),
                });
                if (res.ok) {
                    modal.close('modal-adjust');
                    toast(`Stock updated → ${res.new_qty} units.`, res.alert ? 'warn' : 'success');
                    if (res.alert) refreshAlertBadge();
                    setTimeout(() => location.reload(), 800);
                } else {
                    toast(res.msg, 'error');
                }
            } catch { toast('Network error.', 'error'); }
            finally  { btn.disabled = false; btn.textContent = 'Save'; }
        });
    };

    /* ── Alert badge live polling ──────────────────────────── */
    const refreshAlertBadge = async () => {
        try {
            const res = await get('modules/inventory/ajax.php', { action: 'alert_count' });
            const badge = document.getElementById('alert-badge');
            if (!badge) return;
            if (res.count > 0) {
                badge.textContent = res.count;
                badge.style.display = 'inline-block';
            } else {
                badge.style.display = 'none';
            }
        } catch {}
    };

    const initAlertPolling = () => {
        refreshAlertBadge();
        setInterval(refreshAlertBadge, 30_000);   // every 30 s
    };

    /* ── Alerts panel ──────────────────────────────────────── */
    const initAlertPanel = () => {
        const openBtn = document.getElementById('btn-alerts');
        if (!openBtn) return;

        openBtn.addEventListener('click', async () => {
            const panel = document.getElementById('alerts-panel');
            if (panel.classList.contains('open')) {
                panel.classList.remove('open'); return;
            }
            panel.innerHTML = '<div class="p-3 text-muted text-sm">Loading…</div>';
            panel.classList.add('open');
            try {
                const alerts = await get('modules/inventory/ajax.php', { action: 'get_alerts' });
                renderAlerts(alerts, panel);
            } catch { panel.innerHTML = '<div class="p-3 text-muted text-sm">Error loading alerts.</div>'; }
        });

        document.addEventListener('click', e => {
            if (!e.target.closest('#alerts-panel') && !e.target.closest('#btn-alerts')) {
                document.getElementById('alerts-panel')?.classList.remove('open');
            }
        });
    };

    const renderAlerts = (alerts, panel) => {
        if (!alerts.length) {
            panel.innerHTML = '<div style="padding:1.5rem;text-align:center;color:var(--text-secondary);font-size:.85rem">✓ No unread alerts</div>';
            return;
        }
        const html = alerts.map(a => `
            <div class="alert-item unread" data-alert-id="${a.id}" onclick="SM.markAlert(${a.id}, this)">
                <div class="alert-dot"></div>
                <div>
                    <div class="alert-msg">${a.message}</div>
                    <div class="alert-time">${timeAgo(a.created_at)}</div>
                </div>
            </div>`).join('');
        panel.innerHTML = `
            <div style="padding:.75rem 1rem;border-bottom:1px solid var(--card-border);display:flex;justify-content:space-between;align-items:center">
                <span style="font-size:.8rem;font-weight:600;text-transform:uppercase;letter-spacing:.06em;color:var(--text-secondary)">Alerts</span>
                <button onclick="SM.markAllAlerts()" style="font-size:.75rem;background:none;border:none;color:var(--accent-1);cursor:pointer">Mark all read</button>
            </div>
            <div style="max-height:360px;overflow-y:auto">${html}</div>`;
    };

    const markAlert = async (id, el) => {
        await post('modules/inventory/ajax.php', { action: 'mark_alert', alert_id: id });
        el.classList.remove('unread');
        el.querySelector('.alert-dot').style.background = 'rgba(255,255,255,.2)';
        refreshAlertBadge();
    };

    const markAllAlerts = async () => {
        await post('modules/inventory/ajax.php', { action: 'mark_all_alerts' });
        document.querySelectorAll('.alert-item').forEach(el => {
            el.classList.remove('unread');
            el.querySelector('.alert-dot').style.background = 'rgba(255,255,255,.2)';
        });
        refreshAlertBadge();
    };

    /* ── Table search/filter ───────────────────────────────── */
    const initTableSearch = () => {
        const input = document.getElementById('table-search');
        if (!input) return;
        input.addEventListener('input', () => {
            const q = input.value.toLowerCase();
            document.querySelectorAll('.product-row').forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(q) ? '' : 'none';
            });
        });
    };

    /* ── Category filter pills ─────────────────────────────── */
    const initCategoryFilter = () => {
        document.querySelectorAll('[data-filter-cat]').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('[data-filter-cat]')
                    .forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                const cat = btn.dataset.filterCat;
                document.querySelectorAll('.product-row').forEach(row => {
                    row.style.display = (cat === 'all' || row.dataset.category === cat) ? '' : 'none';
                });
            });
        });
    };

    /* ── Mobile sidebar toggle ─────────────────────────────── */
    const initMobileSidebar = () => {
        document.getElementById('btn-menu')?.addEventListener('click', () => {
            document.querySelector('.sidebar')?.classList.toggle('open');
        });
    };

    /* ── Number counter animation ──────────────────────────── */
    const animateCounters = () => {
        document.querySelectorAll('[data-count]').forEach(el => {
            const target = parseFloat(el.dataset.count);
            const prefix = el.dataset.prefix ?? '';
            const suffix = el.dataset.suffix ?? '';
            const isFloat = el.dataset.float === 'true';
            let current = 0;
            const step  = target / 50;
            const timer = setInterval(() => {
                current = Math.min(current + step, target);
                el.textContent = prefix + (isFloat
                    ? current.toLocaleString('en-US', { minimumFractionDigits:2, maximumFractionDigits:2 })
                    : Math.round(current).toLocaleString()) + suffix;
                if (current >= target) clearInterval(timer);
            }, 20);
        });
    };

    /* ── Utility ───────────────────────────────────────────── */
    const timeAgo = dateStr => {
        const diff = (Date.now() - new Date(dateStr)) / 1000;
        if (diff < 60) return 'just now';
        if (diff < 3600) return Math.round(diff / 60) + 'm ago';
        if (diff < 86400) return Math.round(diff / 3600) + 'h ago';
        return Math.round(diff / 86400) + 'd ago';
    };

    /* ── Init ──────────────────────────────────────────────── */
    const init = () => {
        initStockAdjust();
        initAdjustModal();
        initAlertPolling();
        initAlertPanel();
        initTableSearch();
        initCategoryFilter();
        initMobileSidebar();
        setTimeout(animateCounters, 100);
    };

    document.readyState === 'loading'
        ? document.addEventListener('DOMContentLoaded', init)
        : init();

    return { toast, modal, markAlert, markAllAlerts, refreshAlertBadge };
})();
