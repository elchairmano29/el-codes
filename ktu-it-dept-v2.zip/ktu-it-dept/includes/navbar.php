<?php
// Get pending complaints count for admin notification
$notif_count = 0;
if (isAdmin()) {
    $nc_res = mysqli_query($conn, "SELECT COUNT(*) as c FROM complaints WHERE status='pending'");
    if ($nc_res) $notif_count = mysqli_fetch_assoc($nc_res)['c'];
}
// Get first letter of name for avatar
$av_letter = isset($_SESSION['user_name']) ? strtoupper(substr($_SESSION['user_name'], 0, 1)) : 'U';
?>
<nav class="navbar">
    <div class="navbar-container">
        <!-- Brand -->
        <a href="<?php echo SITE_URL; ?>/index.php" class="navbar-brand">
            <img src="<?php echo SITE_URL; ?>/assets/KsTU_logo.png" alt="KsTU Logo" class="navbar-logo">
            <div class="navbar-brand-text">
                <span class="t1">KsTU IT Dept</span>
                <span class="t2">Kumasi Technical University</span>
            </div>
        </a>

        <!-- Sidebar toggle (mobile) -->
        <?php if (isLoggedIn()): ?>
        <button class="sidebar-toggle" id="sidebarToggle" aria-label="Toggle sidebar">
            <span></span><span></span><span></span>
        </button>
        <?php endif; ?>

        <!-- Desktop Nav -->
        <ul class="navbar-menu">
            <li><a href="<?php echo SITE_URL; ?>/index.php"><i class="fas fa-home"></i> Home</a></li>
            <?php if (isLoggedIn()): ?>
                <?php if (isAdmin()): ?>
                    <li><a href="<?php echo SITE_URL; ?>/admin/dashboard.php"><i class="fas fa-th-large"></i> Dashboard</a></li>
                    <li><a href="<?php echo SITE_URL; ?>/admin/announcements.php"><i class="fas fa-bullhorn"></i> Announcements</a></li>
                    <li><a href="<?php echo SITE_URL; ?>/admin/students.php"><i class="fas fa-users"></i> Students</a></li>
                    <li><a href="<?php echo SITE_URL; ?>/admin/complaints.php">
                        <i class="fas fa-inbox"></i> Inbox
                        <?php if ($notif_count > 0): ?><span class="badge badge-complaint" style="margin-left:2px"><?php echo $notif_count; ?></span><?php endif; ?>
                    </a></li>
                <?php else: ?>
                    <li><a href="<?php echo SITE_URL; ?>/user/dashboard.php"><i class="fas fa-th-large"></i> Dashboard</a></li>
                    <li><a href="<?php echo SITE_URL; ?>/user/updates.php"><i class="fas fa-bell"></i> Updates</a></li>
                    <li><a href="<?php echo SITE_URL; ?>/user/complaints.php"><i class="fas fa-comment-dots"></i> Feedback</a></li>
                <?php endif; ?>
                <li>
                    <div class="navbar-user">
                        <div class="navbar-user-avatar"><?php echo $av_letter; ?></div>
                        <?php echo getFirstName($_SESSION['user_name']); ?>
                    </div>
                </li>
                <li><a href="<?php echo SITE_URL; ?>/logout.php" class="btn btn-outline btn-sm"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            <?php else: ?>
                <li><a href="<?php echo SITE_URL; ?>/login.php" class="btn btn-outline btn-sm"><i class="fas fa-sign-in-alt"></i> Login</a></li>
                <li><a href="<?php echo SITE_URL; ?>/signup.php" class="btn btn-primary btn-sm"><i class="fas fa-user-plus"></i> Sign Up</a></li>
            <?php endif; ?>
        </ul>
    </div>
</nav>

<!-- Sidebar Overlay -->
<?php if (isLoggedIn()): ?>
<div class="sidebar-overlay" id="sidebarOverlay"></div>
<?php endif; ?>
