    <footer class="footer">
        <p>&copy; <?php echo date('Y'); ?> Kumasi Technical University &mdash; Department of Information Technology</p>
        <p>Developed by <a href="#">Henry Addo Nortey</a> &middot; Final Semester Project</p>
    </footer>
    <script src="<?php echo SITE_URL; ?>/assets/js/main.js"></script>
</body>
</html>
