<?php
$current = basename($_SERVER['PHP_SELF']);
?>
<aside class="sidebar" id="sidebar">
    <div class="sidebar-head">
        <h3>Student Portal</h3>
        <button class="sidebar-close" id="sidebarClose" title="Close sidebar">
            <i class="fas fa-times"></i>
        </button>
    </div>
    <div class="sidebar-user">
        <div class="sidebar-user-avatar"><?php echo strtoupper(substr($_SESSION['user_name'],0,1)); ?></div>
        <div class="sidebar-user-info">
            <h4><?php echo htmlspecialchars($_SESSION['user_name']); ?></h4>
            <p><span class="badge badge-student">Student</span></p>
        </div>
    </div>
    <nav class="sidebar-nav">
        <div class="sidebar-section">
            <div class="sidebar-section-title">Main</div>
            <a href="<?php echo SITE_URL; ?>/user/dashboard.php" class="sidebar-link <?php echo $current==='dashboard.php'?'active':''; ?>">
                <i class="fas fa-th-large"></i> Dashboard
            </a>
        </div>
        <div class="sidebar-section">
            <div class="sidebar-section-title">Content</div>
            <a href="<?php echo SITE_URL; ?>/user/updates.php" class="sidebar-link <?php echo $current==='updates.php'?'active':''; ?>">
                <i class="fas fa-bell"></i> Updates & News
            </a>
            <a href="<?php echo SITE_URL; ?>/user/complaints.php" class="sidebar-link <?php echo $current==='complaints.php'?'active':''; ?>">
                <i class="fas fa-comment-dots"></i> Feedback & Complaints
            </a>
        </div>
        <div class="sidebar-section">
            <div class="sidebar-section-title">Account</div>
            <a href="<?php echo SITE_URL; ?>/index.php" class="sidebar-link">
                <i class="fas fa-home"></i> Public Home
            </a>
            <a href="<?php echo SITE_URL; ?>/logout.php" class="sidebar-link" style="color:var(--danger)">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </nav>
</aside>
