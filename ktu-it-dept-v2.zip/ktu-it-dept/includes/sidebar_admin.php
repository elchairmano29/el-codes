<?php
$notif_c = 0;
$nc = mysqli_query($conn, "SELECT COUNT(*) as c FROM complaints WHERE status='pending'");
if ($nc) $notif_c = mysqli_fetch_assoc($nc)['c'];
$current = basename($_SERVER['PHP_SELF']);
?>
<aside class="sidebar" id="sidebar">
    <div class="sidebar-head">
        <h3>Admin Panel</h3>
        <button class="sidebar-close" id="sidebarClose" title="Close sidebar">
            <i class="fas fa-times"></i>
        </button>
    </div>
    <div class="sidebar-user">
        <div class="sidebar-user-avatar"><?php echo strtoupper(substr($_SESSION['user_name'],0,1)); ?></div>
        <div class="sidebar-user-info">
            <h4><?php echo htmlspecialchars($_SESSION['user_name']); ?></h4>
            <p><span class="badge badge-admin">Administrator</span></p>
        </div>
    </div>
    <nav class="sidebar-nav">
        <div class="sidebar-section">
            <div class="sidebar-section-title">Main</div>
            <a href="<?php echo SITE_URL; ?>/admin/dashboard.php" class="sidebar-link <?php echo $current==='dashboard.php'?'active':''; ?>">
                <i class="fas fa-th-large"></i> Dashboard
            </a>
        </div>
        <div class="sidebar-section">
            <div class="sidebar-section-title">Management</div>
            <a href="<?php echo SITE_URL; ?>/admin/announcements.php" class="sidebar-link <?php echo $current==='announcements.php'?'active':''; ?>">
                <i class="fas fa-bullhorn"></i> Announcements
            </a>
            <a href="<?php echo SITE_URL; ?>/admin/students.php" class="sidebar-link <?php echo $current==='students.php'?'active':''; ?>">
                <i class="fas fa-users"></i> Students
            </a>
            <a href="<?php echo SITE_URL; ?>/admin/complaints.php" class="sidebar-link <?php echo $current==='complaints.php'?'active':''; ?>">
                <i class="fas fa-inbox"></i> Feedback & Complaints
                <?php if ($notif_c > 0): ?><span class="bc danger"><?php echo $notif_c; ?></span><?php endif; ?>
            </a>
        </div>
        <div class="sidebar-section">
            <div class="sidebar-section-title">Account</div>
            <a href="<?php echo SITE_URL; ?>/index.php" class="sidebar-link">
                <i class="fas fa-home"></i> Public Home
            </a>
            <a href="<?php echo SITE_URL; ?>/logout.php" class="sidebar-link" style="color:var(--danger)">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </nav>
</aside>
