# PROJECT STRUCTURE

```
ktu-it-dept/
│
├── .htaccess                   # Apache configuration and security
├── README.md                   # Project documentation
├── INSTALLATION.md             # Detailed installation guide
├── database.sql                # MySQL database schema and data
│
├── admin/                      # Admin Management Area
│   ├── dashboard.php          # Admin dashboard with statistics
│   ├── announcements.php      # CRUD for announcements
│   └── students.php           # View all registered students
│
├── assets/                     # Static Resources
│   ├── css/
│   │   └── style.css          # Main stylesheet (modern design)
│   └── js/
│       └── main.js            # JavaScript functionality
│
├── config/                     # Configuration Files
│   ├── database.php           # Database connection settings
│   └── functions.php          # Helper functions (auth, validation)
│
├── includes/                   # Reusable Components
│   ├── header.php             # HTML head and meta tags
│   ├── navbar.php             # Navigation menu (dynamic)
│   └── footer.php             # Footer section
│
├── user/                       # Student Area
│   ├── dashboard.php          # Student dashboard
│   └── updates.php            # View all announcements
│
├── index.php                   # Landing page (homepage)
├── login.php                   # User login page
├── signup.php                  # Student registration page
└── logout.php                  # Logout handler
```

## FILE DESCRIPTIONS

### Root Files

**index.php**
- Landing page with hero section
- Displays recent 4 announcements
- Navigation based on login status
- Call-to-action buttons

**login.php**
- User authentication form
- Email and password validation
- Session creation on success
- Redirects to appropriate dashboard

**signup.php**
- Student registration form
- Input validation and sanitization
- Duplicate check (email & student ID)
- Password hashing with bcrypt

**logout.php**
- Destroys user session
- Clears session variables
- Redirects to login page

**database.sql**
- Complete database schema
- Users table with role field
- Announcements table
- Sample data (admin + 4 announcements)
- Indexes for performance

**.htaccess**
- Security configurations
- Directory browsing prevention
- File access restrictions
- Caching rules

### Admin Directory

**admin/dashboard.php**
- Statistics overview (students, announcements)
- Quick action cards
- Recent students table
- Recent announcements table

**admin/announcements.php**
- Full CRUD interface
- Create new announcements
- Edit existing announcements
- Delete announcements
- Publish/unpublish toggle
- Category selection

**admin/students.php**
- List all registered students
- Display student details
- Search functionality
- Print option

### User Directory

**user/dashboard.php**
- Welcome message
- Statistics cards
- Profile information display
- Latest 3 announcements
- Quick links section

**user/updates.php**
- All published announcements
- Full content display
- Category badges
- Author and timestamp info

### Config Directory

**config/database.php**
- Database connection setup
- Database credentials (host, user, pass, name)
- Site URL configuration
- Session initialization

**config/functions.php**
- Authentication helpers (isLoggedIn, isAdmin, isStudent)
- Access control (requireLogin, requireAdmin)
- Input sanitization
- Password hashing/verification
- Date formatting
- User data retrieval

### Includes Directory

**includes/header.php**
- HTML DOCTYPE and head section
- Meta tags (charset, viewport, description)
- Google Fonts (Poppins, Inter)
- Font Awesome icons
- CSS stylesheet link

**includes/navbar.php**
- Dynamic navigation menu
- Changes based on user role
- Mobile-responsive toggle
- Active page highlighting

**includes/footer.php**
- Copyright information
- Developer credits
- JavaScript file inclusion
- Closing HTML tags

### Assets Directory

**assets/css/style.css** (3,500+ lines)
- CSS custom properties (variables)
- Modern color scheme
- Typography (Poppins + Inter)
- Responsive grid layouts
- Card components
- Form styling
- Button styles
- Animations and transitions
- Mobile responsive breakpoints

**assets/js/main.js**
- Mobile menu toggle
- Form validation
- Alert auto-dismiss
- Card scroll animations
- Search/filter functionality
- Confirmation dialogs
- Utility functions

## DATABASE SCHEMA

### users table
- id (INT, PRIMARY KEY, AUTO_INCREMENT)
- full_name (VARCHAR 255)
- email (VARCHAR 255, UNIQUE)
- password (VARCHAR 255, HASHED)
- role (ENUM: 'student', 'admin')
- student_id (VARCHAR 50)
- phone (VARCHAR 20)
- created_at (TIMESTAMP)
- updated_at (TIMESTAMP)

### announcements table
- id (INT, PRIMARY KEY, AUTO_INCREMENT)
- title (VARCHAR 255)
- content (TEXT)
- category (ENUM: 'event', 'notice', 'academic', 'general')
- created_by (INT, FOREIGN KEY → users.id)
- is_published (TINYINT)
- created_at (TIMESTAMP)
- updated_at (TIMESTAMP)

## KEY FEATURES IMPLEMENTATION

### Security
- Password hashing (PASSWORD_BCRYPT)
- SQL injection prevention (prepared statements)
- XSS prevention (htmlspecialchars)
- Session-based authentication
- Role-based access control
- Input sanitization

### Responsive Design
- Mobile-first approach
- Flexible grid layouts
- Media queries for breakpoints
- Touch-friendly navigation
- Responsive images

### User Experience
- Smooth animations
- Card-based interface
- Color-coded categories
- Time-ago timestamps
- Loading states
- Success/error alerts

### Performance
- CSS variables for consistency
- Minimal HTTP requests
- Efficient database queries
- Indexed database fields
- Browser caching (.htaccess)

## TECHNOLOGY VERSIONS

- PHP: 7.4+ (compatible with 8.x)
- MySQL: 5.7+ / MariaDB 10.x
- Apache: 2.4+
- Font Awesome: 6.4.0
- Google Fonts: Poppins, Inter

## CODE STATISTICS

- Total Files: 20
- PHP Files: 14
- CSS Lines: ~3,500
- JavaScript Lines: ~350
- SQL Lines: ~100
- Documentation: 3 MD files

## BROWSER COMPATIBILITY

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+
- Mobile browsers (iOS Safari, Chrome Mobile)

---

Created by: Henry Addo Nortey
Institution: Kumasi Technical University
Project: Final Semester Project
Date: March 2026
