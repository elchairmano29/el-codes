<?php
require_once '../config/database.php';
require_once '../config/functions.php';
requireLogin(); requireAdmin();
$page_title = 'Students';

$students = mysqli_query($conn,"SELECT * FROM users WHERE role='student' ORDER BY created_at DESC");
$total    = mysqli_num_rows($students);

include '../includes/header.php';
include '../includes/navbar.php';
?>
<div class="app-layout">
<?php include '../includes/sidebar_admin.php'; ?>
<main class="main-content">
  <div class="page-header animate-in">
    <div>
      <h1>Registered Students</h1>
      <p>All students enrolled in the KsTU IT Department portal</p>
    </div>
    <button onclick="window.print()" class="btn btn-outline"><i class="fas fa-print"></i> Print</button>
  </div>

  <!-- Summary card -->
  <div class="stats-grid animate-in">
    <div class="stat-card" style="max-width:260px">
      <p>Total Students</p>
      <div class="number"><?php echo $total; ?></div>
      <i class="fas fa-users stat-icon"></i>
    </div>
  </div>

  <!-- Search -->
  <div class="flex-between animate-in" style="margin-bottom:1rem">
    <div class="search-bar">
      <i class="fas fa-search"></i>
      <input type="text" id="stuSearch" placeholder="Search by name, ID, email…">
    </div>
    <span style="font-size:.85rem;color:var(--text-muted)"><i class="fas fa-info-circle"></i> <?php echo $total; ?> students found</span>
  </div>

  <div class="table-container animate-in">
    <table id="stuTable">
      <thead>
        <tr><th>#</th><th>Full Name</th><th>Student ID</th><th>Email</th><th>Phone</th><th>Joined</th></tr>
      </thead>
      <tbody>
        <?php if ($total>0): $i=1; while ($s=mysqli_fetch_assoc($students)): ?>
          <tr>
            <td style="color:var(--text-muted);font-size:.82rem"><?php echo $i++; ?></td>
            <td>
              <div style="display:flex;align-items:center;gap:.6rem">
                <div style="width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--primary-light));display:flex;align-items:center;justify-content:center;color:white;font-size:.78rem;font-weight:700;flex-shrink:0">
                  <?php echo strtoupper(substr($s['full_name'],0,1)); ?>
                </div>
                <strong><?php echo htmlspecialchars($s['full_name']); ?></strong>
              </div>
            </td>
            <td><code style="background:var(--surface-2);padding:2px 7px;border-radius:5px;font-size:.82rem"><?php echo htmlspecialchars($s['student_id']??'—'); ?></code></td>
            <td style="font-size:.88rem"><?php echo htmlspecialchars($s['email']); ?></td>
            <td style="font-size:.88rem;color:var(--text-secondary)"><?php echo htmlspecialchars($s['phone']??'—'); ?></td>
            <td style="color:var(--text-muted);font-size:.82rem"><?php echo formatDate($s['created_at']); ?></td>
          </tr>
        <?php endwhile; else: ?>
          <tr><td colspan="6"><div class="empty-state"><i class="fas fa-users"></i><p>No students registered yet.</p></div></td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</main>
</div>
<script>
document.getElementById('stuSearch').addEventListener('input',function(){
  const q=this.value.toLowerCase();
  document.querySelectorAll('#stuTable tbody tr').forEach(r=>{
    r.style.display=r.textContent.toLowerCase().includes(q)?'':'none';
  });
});
</script>
<?php include '../includes/footer.php'; mysqli_close($conn); ?>
