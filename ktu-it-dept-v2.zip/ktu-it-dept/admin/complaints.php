<?php
require_once '../config/database.php';
require_once '../config/functions.php';
requireLogin(); requireAdmin();
$page_title = 'Feedback & Complaints';
$success = ''; $error = '';

// Handle admin reply
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['reply_id'])) {
    $id    = intval($_POST['reply_id']);
    $reply = trim($_POST['admin_reply']??'');
    $status= in_array($_POST['status']??'',['pending','resolved','dismissed']) ? $_POST['status'] : 'pending';
    if (empty($reply)) {
        $error = 'Reply cannot be empty.';
    } else {
        $stmt = mysqli_prepare($conn,"UPDATE complaints SET admin_reply=?,status=?,replied_by=?,replied_at=NOW(),updated_at=NOW() WHERE id=?");
        mysqli_stmt_bind_param($stmt,"ssii",$reply,$status,$_SESSION['user_id'],$id);
        $success = mysqli_stmt_execute($stmt) ? 'Reply sent successfully!' : 'Failed to send reply.';
    }
}
// Update status only
if (isset($_GET['status']) && isset($_GET['id'])) {
    $id  = intval($_GET['id']);
    $st  = in_array($_GET['status'],['pending','resolved','dismissed']) ? $_GET['status'] : 'pending';
    mysqli_query($conn,"UPDATE complaints SET status='$st',updated_at=NOW() WHERE id=$id");
    $success = 'Status updated.';
}

// Stats
$pending_c  = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as c FROM complaints WHERE status='pending'"))['c'];
$resolved_c = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as c FROM complaints WHERE status='resolved'"))['c'];
$total_c    = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as c FROM complaints"))['c'];

// Active filter
$filter = isset($_GET['filter']) && in_array($_GET['filter'],['pending','resolved','dismissed']) ? $_GET['filter'] : 'all';
$where  = $filter==='all' ? '' : "WHERE c.status='$filter'";

$complaints = mysqli_query($conn,"SELECT c.*,u.full_name,u.student_id,u.email FROM complaints c JOIN users u ON c.user_id=u.id $where ORDER BY c.created_at DESC");

// Detail view
$detail = null;
if (isset($_GET['view'])) {
    $vid    = intval($_GET['view']);
    $detail = mysqli_fetch_assoc(mysqli_query($conn,"SELECT c.*,u.full_name,u.student_id,u.email FROM complaints c JOIN users u ON c.user_id=u.id WHERE c.id=$vid"));
}

include '../includes/header.php';
include '../includes/navbar.php';
?>
<div class="app-layout">
<?php include '../includes/sidebar_admin.php'; ?>
<main class="main-content">

  <div class="page-header animate-in">
    <div>
      <h1>Feedback &amp; Complaints</h1>
      <p>Manage student feedback, complaints, and suggestions</p>
    </div>
    <?php if ($detail): ?>
      <a href="complaints.php" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Back to Inbox</a>
    <?php endif; ?>
  </div>

  <?php if ($error): ?><div class="alert alert-danger animate-in"><i class="fas fa-exclamation-circle"></i><?php echo $error; ?></div><?php endif; ?>
  <?php if ($success): ?><div class="alert alert-success animate-in"><i class="fas fa-check-circle"></i><?php echo $success; ?></div><?php endif; ?>

  <!-- Stats -->
  <div class="stats-grid animate-in" style="grid-template-columns:repeat(3,1fr);max-width:600px">
    <div class="stat-card orange">
      <p>Pending</p><div class="number"><?php echo $pending_c; ?></div>
      <i class="fas fa-clock stat-icon"></i>
    </div>
    <div class="stat-card green">
      <p>Resolved</p><div class="number"><?php echo $resolved_c; ?></div>
      <i class="fas fa-check stat-icon"></i>
    </div>
    <div class="stat-card">
      <p>Total</p><div class="number"><?php echo $total_c; ?></div>
      <i class="fas fa-inbox stat-icon"></i>
    </div>
  </div>

  <?php if ($detail): ?>
  <!-- DETAIL VIEW -->
  <div class="card animate-in">
    <div style="display:flex;align-items:flex-start;gap:1rem;margin-bottom:1.25rem;flex-wrap:wrap">
      <div style="width:46px;height:46px;border-radius:50%;background:linear-gradient(135deg,<?php echo ['complaint'=>'#b71c1c,#e53935','feedback'=>'#01579b,#0288d1','suggestion'=>'#4a148c,#9c27b0'][$detail['type']]??'#1a237e,#3949ab'; ?>);display:flex;align-items:center;justify-content:center;color:white;font-size:1.1rem;flex-shrink:0">
        <i class="fas <?php echo getTypeIcon($detail['type']); ?>"></i>
      </div>
      <div style="flex:1">
        <div style="display:flex;gap:.5rem;align-items:center;flex-wrap:wrap;margin-bottom:.3rem">
          <span class="badge badge-<?php echo $detail['type']; ?>"><?php echo ucfirst($detail['type']); ?></span>
          <span class="badge <?php echo getStatusColor($detail['status']); ?>"><?php echo ucfirst($detail['status']); ?></span>
        </div>
        <h3><?php echo htmlspecialchars($detail['subject']); ?></h3>
        <p style="font-size:.82rem;color:var(--text-muted);margin-top:.3rem">
          <?php echo $detail['is_anonymous']?'<i class="fas fa-user-secret"></i> Anonymous':'<i class="fas fa-user"></i> '.htmlspecialchars($detail['full_name']).' ('.htmlspecialchars($detail['student_id']).')'; ?>
          &bull; <i class="fas fa-clock"></i> <?php echo formatDateTime($detail['created_at']); ?>
        </p>
      </div>
    </div>
    <div style="background:var(--surface-2);border-radius:var(--r-md);padding:1.1rem;margin-bottom:1.5rem;font-size:.92rem;line-height:1.7;color:var(--text-secondary)">
      <?php echo nl2br(htmlspecialchars($detail['message'])); ?>
    </div>

    <?php if ($detail['admin_reply']): ?>
      <div class="feedback-response">
        <strong><i class="fas fa-reply"></i> Admin Response — <?php echo formatDateTime($detail['replied_at']); ?></strong>
        <?php echo nl2br(htmlspecialchars($detail['admin_reply'])); ?>
      </div>
    <?php endif; ?>

    <!-- Reply form -->
    <div class="reply-form" style="margin-top:1.25rem">
      <h4 style="margin-bottom:1rem;font-size:.92rem"><i class="fas fa-reply"></i> <?php echo $detail['admin_reply']?'Update Reply':'Send Reply'; ?></h4>
      <form method="POST" action="">
        <input type="hidden" name="reply_id" value="<?php echo $detail['id']; ?>">
        <div class="form-group">
          <label>Your Reply</label>
          <textarea name="admin_reply" rows="4" placeholder="Write your response to the student…" required><?php echo htmlspecialchars($detail['admin_reply']??''); ?></textarea>
        </div>
        <div class="form-group">
          <label>Update Status</label>
          <select name="status">
            <option value="pending" <?php echo $detail['status']==='pending'?'selected':''; ?>>Pending</option>
            <option value="resolved" <?php echo $detail['status']==='resolved'?'selected':''; ?>>Resolved</option>
            <option value="dismissed" <?php echo $detail['status']==='dismissed'?'selected':''; ?>>Dismissed</option>
          </select>
        </div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Send Reply</button>
      </form>
    </div>
  </div>

  <?php else: ?>
  <!-- LIST VIEW -->
  <div class="filter-tabs animate-in">
    <?php foreach(['all'=>'All','pending'=>'Pending','resolved'=>'Resolved','dismissed'=>'Dismissed'] as $k=>$v): ?>
      <a href="?filter=<?php echo $k; ?>" class="filter-tab <?php echo $filter===$k?'active':''; ?>"><?php echo $v; ?></a>
    <?php endforeach; ?>
  </div>

  <div class="feedback-list animate-in">
    <?php if (mysqli_num_rows($complaints)>0): while ($c=mysqli_fetch_assoc($complaints)): ?>
      <div class="feedback-item">
        <div class="feedback-item-header">
          <div style="display:flex;align-items:center;gap:.75rem;flex:1">
            <div style="width:40px;height:40px;border-radius:50%;background:linear-gradient(135deg,<?php echo ['complaint'=>'#b71c1c,#e53935','feedback'=>'#01579b,#0288d1','suggestion'=>'#4a148c,#9c27b0'][$c['type']]??'#1a237e,#3949ab'; ?>);display:flex;align-items:center;justify-content:center;color:white;font-size:.9rem;flex-shrink:0">
              <i class="fas <?php echo getTypeIcon($c['type']); ?>"></i>
            </div>
            <div>
              <div style="display:flex;gap:.4rem;margin-bottom:.25rem">
                <span class="badge badge-<?php echo $c['type']; ?>"><?php echo ucfirst($c['type']); ?></span>
                <span class="badge <?php echo getStatusColor($c['status']); ?>"><?php echo ucfirst($c['status']); ?></span>
              </div>
              <div class="feedback-subject"><?php echo htmlspecialchars($c['subject']); ?></div>
            </div>
          </div>
          <a href="?view=<?php echo $c['id']; ?>" class="btn btn-outline btn-sm"><i class="fas fa-eye"></i> View & Reply</a>
        </div>
        <p class="feedback-body"><?php echo htmlspecialchars(substr($c['message'],0,200)).(strlen($c['message'])>200?'…':''); ?></p>
        <div class="feedback-meta">
          <i class="fas <?php echo $c['is_anonymous']?'fa-user-secret':'fa-user'; ?>"></i>
          <span><?php echo $c['is_anonymous']?'Anonymous':htmlspecialchars($c['full_name']); ?></span>
          <?php if (!$c['is_anonymous']): ?><span>&bull;</span><span><?php echo htmlspecialchars($c['student_id']); ?></span><?php endif; ?>
          <span>&bull;</span><i class="fas fa-clock"></i><span><?php echo timeAgo($c['created_at']); ?></span>
        </div>
        <?php if ($c['admin_reply']): ?>
          <div class="feedback-response"><strong><i class="fas fa-reply"></i> Admin replied</strong><?php echo htmlspecialchars(substr($c['admin_reply'],0,120)).'…'; ?></div>
        <?php endif; ?>
      </div>
    <?php endwhile; else: ?>
      <div class="empty-state" style="background:var(--surface);border-radius:var(--r-lg);border:1px solid var(--border)">
        <i class="fas fa-inbox"></i>
        <p>No <?php echo $filter!=='all'?$filter.' ':''; ?>submissions yet.</p>
      </div>
    <?php endif; ?>
  </div>
  <?php endif; ?>

</main>
</div>
<?php include '../includes/footer.php'; mysqli_close($conn); ?>
