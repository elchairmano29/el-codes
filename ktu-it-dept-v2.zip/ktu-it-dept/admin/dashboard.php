<?php
require_once '../config/database.php';
require_once '../config/functions.php';
requireLogin(); requireAdmin();
$page_title = 'Admin Dashboard';

$total_students = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as c FROM users WHERE role='student'"))['c'];
$total_ann      = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as c FROM announcements"))['c'];
$published_ann  = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as c FROM announcements WHERE is_published=1"))['c'];
$pending_comp   = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as c FROM complaints WHERE status='pending'"))['c'];
$total_comp     = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as c FROM complaints"))['c'];

$recent_students = mysqli_query($conn,"SELECT * FROM users WHERE role='student' ORDER BY created_at DESC LIMIT 6");
$recent_ann      = mysqli_query($conn,"SELECT * FROM announcements ORDER BY created_at DESC LIMIT 5");
$recent_comp     = mysqli_query($conn,"SELECT c.*,u.full_name,u.student_id FROM complaints c JOIN users u ON c.user_id=u.id ORDER BY c.created_at DESC LIMIT 5");

include '../includes/header.php';
include '../includes/navbar.php';
?>
<div class="app-layout">
<?php include '../includes/sidebar_admin.php'; ?>
<main class="main-content">
  <div class="dashboard-header animate-in">
    <h1>Admin Dashboard</h1>
    <p>Welcome back, <?php echo htmlspecialchars(getFirstName($_SESSION['user_name'])); ?>! Here's your department overview.</p>
  </div>

  <!-- Stats -->
  <div class="stats-grid animate-in">
    <div class="stat-card">
      <p>Total Students</p>
      <div class="number"><?php echo $total_students; ?></div>
      <div class="trend"><i class="fas fa-users"></i> Registered</div>
      <i class="fas fa-users stat-icon"></i>
    </div>
    <div class="stat-card green">
      <p>Announcements</p>
      <div class="number"><?php echo $total_ann; ?></div>
      <div class="trend"><?php echo $published_ann; ?> published</div>
      <i class="fas fa-bullhorn stat-icon"></i>
    </div>
    <div class="stat-card orange">
      <p>Pending Feedback</p>
      <div class="number"><?php echo $pending_comp; ?></div>
      <div class="trend"><?php echo $total_comp; ?> total received</div>
      <i class="fas fa-inbox stat-icon"></i>
    </div>
    <div class="stat-card purple">
      <p>Published Updates</p>
      <div class="number"><?php echo $published_ann; ?></div>
      <div class="trend">Active announcements</div>
      <i class="fas fa-check-circle stat-icon"></i>
    </div>
  </div>

  <!-- Quick Actions -->
  <div class="section animate-in">
    <h3 style="margin-bottom:1rem">Quick Actions</h3>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:1rem">
      <?php
      $actions = [
        ['href'=>SITE_URL.'/admin/announcements.php?action=new','bg'=>'#1a237e,#3949ab','icon'=>'fa-plus','title'=>'New Announcement','sub'=>'Post a department update'],
        ['href'=>SITE_URL.'/admin/announcements.php','bg'=>'#00695c,#00897b','icon'=>'fa-list','title'=>'Manage Posts','sub'=>'View & edit announcements'],
        ['href'=>SITE_URL.'/admin/students.php','bg'=>'#e65100,#fb8c00','icon'=>'fa-users','title'=>'View Students','sub'=>'Browse registered students'],
        ['href'=>SITE_URL.'/admin/complaints.php','bg'=>'#6a1b9a,#9c27b0','icon'=>'fa-inbox','title'=>'Inbox '.($pending_comp>0?'('.$pending_comp.' new)':''),'sub'=>'Feedback & complaints'],
      ];
      foreach ($actions as $a): ?>
        <a href="<?php echo $a['href']; ?>" class="card" style="display:flex;flex-direction:column;gap:.75rem;cursor:pointer">
          <div class="card-icon" style="background:linear-gradient(135deg,<?php echo $a['bg']; ?>)">
            <i class="fas <?php echo $a['icon']; ?>"></i>
          </div>
          <div>
            <h4 style="font-size:.92rem;margin-bottom:.2rem"><?php echo $a['title']; ?></h4>
            <p style="font-size:.78rem"><?php echo $a['sub']; ?></p>
          </div>
        </a>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Recent Students -->
  <div class="section animate-in">
    <div class="flex-between mb-2">
      <h3>Recent Registrations</h3>
      <a href="<?php echo SITE_URL; ?>/admin/students.php" class="btn btn-outline btn-sm">View All</a>
    </div>
    <div class="table-container">
      <table>
        <thead><tr><th>Student</th><th>ID</th><th>Email</th><th>Phone</th><th>Joined</th></tr></thead>
        <tbody>
          <?php if (mysqli_num_rows($recent_students)>0): ?>
            <?php while ($s=mysqli_fetch_assoc($recent_students)): ?>
              <tr>
                <td><strong><?php echo htmlspecialchars($s['full_name']); ?></strong></td>
                <td><code style="background:var(--surface-2);padding:2px 7px;border-radius:5px;font-size:.8rem"><?php echo htmlspecialchars($s['student_id']); ?></code></td>
                <td><?php echo htmlspecialchars($s['email']); ?></td>
                <td><?php echo htmlspecialchars($s['phone']??'—'); ?></td>
                <td style="color:var(--text-muted);font-size:.82rem"><?php echo timeAgo($s['created_at']); ?></td>
              </tr>
            <?php endwhile; ?>
          <?php else: ?>
            <tr><td colspan="5" class="text-center" style="color:var(--text-muted);padding:2rem">No students registered yet.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Recent Complaints -->
  <?php if (mysqli_num_rows($recent_comp)>0): ?>
  <div class="section animate-in">
    <div class="flex-between mb-2">
      <h3>Recent Feedback / Complaints</h3>
      <a href="<?php echo SITE_URL; ?>/admin/complaints.php" class="btn btn-outline btn-sm">View All</a>
    </div>
    <div class="table-container">
      <table>
        <thead><tr><th>Student</th><th>Type</th><th>Subject</th><th>Status</th><th>Received</th></tr></thead>
        <tbody>
          <?php while ($c=mysqli_fetch_assoc($recent_comp)): ?>
            <tr>
              <td><?php echo $c['is_anonymous'] ? '<em style="color:var(--text-muted)">Anonymous</em>' : htmlspecialchars($c['full_name']); ?></td>
              <td><span class="badge badge-<?php echo $c['type']; ?>"><?php echo ucfirst($c['type']); ?></span></td>
              <td><?php echo htmlspecialchars(substr($c['subject'],0,45)).(strlen($c['subject'])>45?'…':''); ?></td>
              <td><span class="badge <?php echo getStatusColor($c['status']); ?>"><?php echo ucfirst($c['status']); ?></span></td>
              <td style="color:var(--text-muted);font-size:.82rem"><?php echo timeAgo($c['created_at']); ?></td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>
  <?php endif; ?>

</main>
</div>
<?php include '../includes/footer.php'; mysqli_close($conn); ?>
