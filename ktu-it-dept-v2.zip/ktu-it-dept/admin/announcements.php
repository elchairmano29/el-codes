<?php
require_once '../config/database.php';
require_once '../config/functions.php';
requireLogin(); requireAdmin();
$page_title = 'Announcements';
$error = ''; $success = '';

if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['action'])) {
    $title       = sanitizeInput($_POST['title']??'');
    $content     = trim($_POST['content']??'');
    $category    = in_array($_POST['category']??'',['event','notice','academic','general']) ? $_POST['category'] : 'general';
    $is_published= isset($_POST['is_published']) ? 1 : 0;
    if (empty($title)||empty($content)) {
        $error = 'Title and content are required.';
    } elseif ($_POST['action']==='create') {
        $stmt = mysqli_prepare($conn,"INSERT INTO announcements (title,content,category,is_published,created_by) VALUES (?,?,?,?,?)");
        mysqli_stmt_bind_param($stmt,"sssii",$title,$content,$category,$is_published,$_SESSION['user_id']);
        $success = mysqli_stmt_execute($stmt) ? 'Announcement created!' : 'Failed to create.';
    } elseif ($_POST['action']==='update') {
        $id = intval($_POST['id']??0);
        $stmt = mysqli_prepare($conn,"UPDATE announcements SET title=?,content=?,category=?,is_published=?,updated_at=NOW() WHERE id=?");
        mysqli_stmt_bind_param($stmt,"sssii",$title,$content,$category,$is_published,$id);
        $success = mysqli_stmt_execute($stmt) ? 'Announcement updated!' : 'Failed to update.';
    }
}
if (isset($_GET['delete'])) {
    $id   = intval($_GET['delete']);
    $stmt = mysqli_prepare($conn,"DELETE FROM announcements WHERE id=?");
    mysqli_stmt_bind_param($stmt,"i",$id);
    $success = mysqli_stmt_execute($stmt) ? 'Announcement deleted.' : 'Failed to delete.';
}
if (isset($_GET['toggle'])) {
    $id  = intval($_GET['toggle']);
    $cur = mysqli_fetch_assoc(mysqli_query($conn,"SELECT is_published FROM announcements WHERE id=$id"));
    $new = $cur ? ($cur['is_published'] ? 0 : 1) : 1;
    mysqli_query($conn,"UPDATE announcements SET is_published=$new WHERE id=$id");
    $success = 'Status updated.';
}

$edit_ann = null;
if (isset($_GET['edit'])) {
    $id  = intval($_GET['edit']);
    $res = mysqli_query($conn,"SELECT * FROM announcements WHERE id=$id");
    $edit_ann = mysqli_fetch_assoc($res);
}

$announcements = mysqli_query($conn,"SELECT a.*,u.full_name as author FROM announcements a JOIN users u ON a.created_by=u.id ORDER BY a.created_at DESC");

include '../includes/header.php';
include '../includes/navbar.php';
?>
<div class="app-layout">
<?php include '../includes/sidebar_admin.php'; ?>
<main class="main-content">
  <div class="page-header animate-in">
    <div>
      <h1>Announcements</h1>
      <p>Create and manage department updates for students</p>
    </div>
    <?php if (!isset($_GET['action']) && !$edit_ann): ?>
      <a href="?action=new" class="btn btn-primary"><i class="fas fa-plus"></i> New Announcement</a>
    <?php else: ?>
      <a href="announcements.php" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Back to List</a>
    <?php endif; ?>
  </div>

  <?php if ($error): ?><div class="alert alert-danger animate-in"><i class="fas fa-exclamation-circle"></i><?php echo $error; ?></div><?php endif; ?>
  <?php if ($success): ?><div class="alert alert-success animate-in"><i class="fas fa-check-circle"></i><?php echo $success; ?></div><?php endif; ?>

  <?php if (isset($_GET['action'])||$edit_ann): ?>
  <div class="card animate-in">
    <h3 style="margin-bottom:1.5rem"><?php echo $edit_ann?'<i class="fas fa-edit"></i> Edit':'<i class="fas fa-plus"></i> Create'; ?> Announcement</h3>
    <form method="POST" action="">
      <input type="hidden" name="action" value="<?php echo $edit_ann?'update':'create'; ?>">
      <?php if ($edit_ann): ?><input type="hidden" name="id" value="<?php echo $edit_ann['id']; ?>"><?php endif; ?>
      <div class="form-group">
        <label>Title <span style="color:var(--danger)">*</span></label>
        <input type="text" name="title" placeholder="Announcement title…" value="<?php echo $edit_ann?htmlspecialchars($edit_ann['title']):''; ?>" required>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Category</label>
          <select name="category">
            <?php foreach(['general'=>'General','event'=>'Event','notice'=>'Notice','academic'=>'Academic'] as $k=>$v): ?>
              <option value="<?php echo $k; ?>"<?php echo ($edit_ann&&$edit_ann['category']===$k)||(!$edit_ann&&$k==='general')?' selected':''; ?>><?php echo $v; ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group" style="display:flex;align-items:flex-end;padding-bottom:.2rem">
          <label class="form-check">
            <input type="checkbox" name="is_published" <?php echo (!$edit_ann||$edit_ann['is_published'])?'checked':''; ?>>
            Publish immediately
          </label>
        </div>
      </div>
      <div class="form-group">
        <label>Content <span style="color:var(--danger)">*</span></label>
        <textarea name="content" rows="8" placeholder="Write your announcement content here…" required><?php echo $edit_ann?htmlspecialchars($edit_ann['content']):''; ?></textarea>
      </div>
      <div style="display:flex;gap:.75rem;flex-wrap:wrap">
        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> <?php echo $edit_ann?'Update':'Publish'; ?> Announcement</button>
        <a href="announcements.php" class="btn btn-outline">Cancel</a>
      </div>
    </form>
  </div>

  <?php else: ?>

  <!-- Filter & Search -->
  <div class="flex-between animate-in" style="margin-bottom:1rem">
    <div class="filter-tabs" id="catTabs">
      <button class="filter-tab active" data-cat="all">All</button>
      <button class="filter-tab" data-cat="general">General</button>
      <button class="filter-tab" data-cat="event">Events</button>
      <button class="filter-tab" data-cat="notice">Notices</button>
      <button class="filter-tab" data-cat="academic">Academic</button>
    </div>
    <div class="search-bar">
      <i class="fas fa-search"></i>
      <input type="text" id="annSearch" placeholder="Search announcements…">
    </div>
  </div>

  <div class="table-container animate-in">
    <table id="annTable">
      <thead>
        <tr><th>Title</th><th>Category</th><th>Status</th><th>Author</th><th>Created</th><th>Actions</th></tr>
      </thead>
      <tbody>
        <?php if (mysqli_num_rows($announcements)>0): ?>
          <?php while ($a=mysqli_fetch_assoc($announcements)): ?>
            <tr data-cat="<?php echo $a['category']; ?>">
              <td><strong><?php echo htmlspecialchars($a['title']); ?></strong></td>
              <td><span class="badge badge-<?php echo $a['category']; ?>"><?php echo ucfirst($a['category']); ?></span></td>
              <td>
                <a href="?toggle=<?php echo $a['id']; ?>" title="Click to toggle">
                  <span class="badge <?php echo $a['is_published']?'badge-published':'badge-draft'; ?>">
                    <?php echo $a['is_published']?'Published':'Draft'; ?>
                  </span>
                </a>
              </td>
              <td style="font-size:.85rem"><?php echo htmlspecialchars($a['author']); ?></td>
              <td style="color:var(--text-muted);font-size:.82rem"><?php echo timeAgo($a['created_at']); ?></td>
              <td>
                <div style="display:flex;gap:.4rem">
                  <a href="?edit=<?php echo $a['id']; ?>" class="btn btn-outline btn-sm btn-icon" title="Edit"><i class="fas fa-edit"></i></a>
                  <a href="?delete=<?php echo $a['id']; ?>" class="btn btn-danger btn-sm btn-icon" title="Delete"
                    onclick="return confirm('Delete this announcement?')"><i class="fas fa-trash"></i></a>
                </div>
              </td>
            </tr>
          <?php endwhile; ?>
        <?php else: ?>
          <tr><td colspan="6"><div class="empty-state"><i class="fas fa-bullhorn"></i><p>No announcements yet. Create one above!</p></div></td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>

</main>
</div>
<script>
// Category filter
document.querySelectorAll('#catTabs .filter-tab').forEach(btn=>{
  btn.addEventListener('click',()=>{
    document.querySelectorAll('#catTabs .filter-tab').forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    const cat=btn.dataset.cat;
    document.querySelectorAll('#annTable tbody tr').forEach(row=>{
      row.style.display=(cat==='all'||row.dataset.cat===cat)?'':'none';
    });
  });
});
// Search
document.getElementById('annSearch')?.addEventListener('input',function(){
  const q=this.value.toLowerCase();
  document.querySelectorAll('#annTable tbody tr').forEach(r=>{
    r.style.display=r.textContent.toLowerCase().includes(q)?'':'none';
  });
});
</script>
<?php include '../includes/footer.php'; mysqli_close($conn); ?>
