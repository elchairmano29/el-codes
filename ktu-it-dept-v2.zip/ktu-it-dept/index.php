<?php
require_once 'config/database.php';
require_once 'config/functions.php';
$page_title = 'Home';
include 'includes/header.php';
include 'includes/navbar.php';

$query = "SELECT a.*, u.full_name as author_name FROM announcements a
          JOIN users u ON a.created_by=u.id WHERE a.is_published=1
          ORDER BY a.created_at DESC LIMIT 4";
$ann_result = mysqli_query($conn, $query);

$total_students = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as c FROM users WHERE role='student'"))['c'];
$total_ann      = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as c FROM announcements WHERE is_published=1"))['c'];
?>

<!-- HERO -->
<section class="hero">
  <div class="hero-container">
    <div class="hero-content">
      <div class="hero-badge"><i class="fas fa-star"></i> KsTU Student Portal 2025</div>
      <h1>Welcome to <span class="highlight">KsTU IT</span><br>Department</h1>
      <p>Your central hub for department news, academic updates, events, and resources. Stay connected with everything happening in the Department of Information Technology.</p>
      <div class="hero-buttons">
        <?php if (!isLoggedIn()): ?>
          <a href="signup.php" class="btn btn-accent btn-lg"><i class="fas fa-rocket"></i> Get Started</a>
          <a href="login.php" class="btn btn-lg" style="background:rgba(255,255,255,.15);color:white;border:1.5px solid rgba(255,255,255,.35)"><i class="fas fa-sign-in-alt"></i> Sign In</a>
        <?php elseif (isAdmin()): ?>
          <a href="admin/dashboard.php" class="btn btn-accent btn-lg"><i class="fas fa-th-large"></i> Admin Dashboard</a>
        <?php else: ?>
          <a href="user/dashboard.php" class="btn btn-accent btn-lg"><i class="fas fa-th-large"></i> My Dashboard</a>
          <a href="user/updates.php" class="btn btn-lg" style="background:rgba(255,255,255,.15);color:white;border:1.5px solid rgba(255,255,255,.35)"><i class="fas fa-bell"></i> Latest Updates</a>
        <?php endif; ?>
      </div>
      <div class="hero-stats">
        <div class="hero-stat"><div class="num"><?php echo $total_students; ?>+</div><div class="lbl">Students Enrolled</div></div>
        <div class="hero-stat"><div class="num"><?php echo $total_ann; ?>+</div><div class="lbl">Announcements</div></div>
        <div class="hero-stat"><div class="num">24/7</div><div class="lbl">Portal Access</div></div>
      </div>
    </div>
    <img src="assets/KsTU_logo.png" alt="KsTU Logo" class="hero-logo">
  </div>
</section>

<!-- RECENT UPDATES -->
<section style="padding:3.5rem 0">
  <div class="container">
    <div class="section-header">
      <h2>Recent Updates</h2>
      <p>Stay informed with the latest announcements from the IT Department</p>
    </div>
    <div class="cards-grid">
      <?php if (mysqli_num_rows($ann_result) > 0): ?>
        <?php while ($a = mysqli_fetch_assoc($ann_result)): ?>
          <div class="card animate-in" style="position:relative;padding-left:1.75rem">
            <div style="position:absolute;left:0;top:0;bottom:0;width:4px;border-radius:4px 0 0 4px;background:<?php echo ['event'=>'#0288d1','notice'=>'#fb8c00','academic'=>'#9c27b0','general'=>'#00897b'][$a['category']]??'#5a6380'; ?>"></div>
            <div class="card-icon" style="background:linear-gradient(135deg,<?php echo ['event'=>'#0288d1,#4fc3f7','notice'=>'#fb8c00,#ffcc02','academic'=>'#9c27b0,#ce93d8','general'=>'#00897b,#4db6ac'][$a['category']]??'#1a237e,#3949ab'; ?>)">
              <i class="fas <?php echo getCategoryIcon($a['category']); ?>"></i>
            </div>
            <span class="badge badge-<?php echo $a['category']; ?>" style="margin-bottom:.65rem"><?php echo ucfirst($a['category']); ?></span>
            <h3><?php echo htmlspecialchars($a['title']); ?></h3>
            <p style="margin-top:.4rem"><?php echo htmlspecialchars(substr($a['content'],0,130)).'…'; ?></p>
            <div class="card-meta" style="margin-top:1rem">
              <i class="fas fa-user-circle"></i><span><?php echo htmlspecialchars($a['author_name']); ?></span>
              <span>&bull;</span><i class="fas fa-clock"></i><span><?php echo timeAgo($a['created_at']); ?></span>
            </div>
          </div>
        <?php endwhile; ?>
      <?php else: ?>
        <div class="empty-state" style="grid-column:1/-1">
          <i class="fas fa-inbox"></i><p>No announcements yet. Check back soon!</p>
        </div>
      <?php endif; ?>
    </div>
    <?php if (isStudent()): ?>
      <div class="text-center" style="margin-top:2rem">
        <a href="user/updates.php" class="btn btn-primary"><i class="fas fa-arrow-right"></i> View All Updates</a>
      </div>
    <?php endif; ?>
  </div>
</section>

<!-- FEATURES -->
<section style="padding:3.5rem 0;background:white">
  <div class="container">
    <div class="section-header">
      <h2>Why Use Our Portal?</h2>
      <p>Everything you need as a KsTU IT Department student, in one place</p>
    </div>
    <div class="cards-grid">
      <?php
      $features = [
        ['icon'=>'fa-bolt','bg'=>'#0288d1,#4fc3f7','title'=>'Real-time Updates','desc'=>'Instant access to announcements, event schedules, and academic deadlines as soon as they are posted.'],
        ['icon'=>'fa-comment-dots','bg'=>'#00897b,#4db6ac','title'=>'Send Feedback','desc'=>'Submit complaints, feedback, or suggestions directly to department admins and track their responses.'],
        ['icon'=>'fa-graduation-cap','bg'=>'#9c27b0,#ce93d8','title'=>'Academic Resources','desc'=>'Stay on top of project deadlines, lab schedules, and academic notices from your lecturers.'],
        ['icon'=>'fa-shield-alt','bg'=>'#1a237e,#3949ab','title'=>'Secure & Private','desc'=>'Your data is protected with industry-standard security. Anonymous submissions are also supported.'],
        ['icon'=>'fa-mobile-alt','bg'=>'#fb8c00,#ffcc02','title'=>'Mobile Friendly','desc'=>'Access the portal on any device — phone, tablet, or desktop — with a responsive and clean design.'],
        ['icon'=>'fa-users','bg'=>'#c62828,#ef5350','title'=>'Community Hub','desc'=>'Connect with the IT department community and stay engaged with all departmental activities.'],
      ];
      foreach ($features as $f): ?>
        <div class="card">
          <div class="card-icon" style="background:linear-gradient(135deg,<?php echo $f['bg']; ?>)">
            <i class="fas <?php echo $f['icon']; ?>"></i>
          </div>
          <h3><?php echo $f['title']; ?></h3>
          <p><?php echo $f['desc']; ?></p>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- CTA -->
<?php if (!isLoggedIn()): ?>
<section style="padding:3.5rem 0;background:linear-gradient(135deg,var(--primary-dark),var(--primary))">
  <div class="container text-center">
    <h2 style="color:white;margin-bottom:.75rem">Ready to Get Started?</h2>
    <p style="color:rgba(255,255,255,.75);margin-bottom:2rem">Create your free account and stay connected with the IT Department.</p>
    <div style="display:flex;gap:1rem;justify-content:center;flex-wrap:wrap">
      <a href="signup.php" class="btn btn-accent btn-lg"><i class="fas fa-user-plus"></i> Create Account</a>
      <a href="login.php" class="btn btn-lg" style="background:rgba(255,255,255,.15);color:white;border:1.5px solid rgba(255,255,255,.35)"><i class="fas fa-sign-in-alt"></i> Already have an account</a>
    </div>
  </div>
</section>
<?php endif; ?>

<?php include 'includes/footer.php'; mysqli_close($conn); ?>
