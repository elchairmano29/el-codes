# 🚀 QUICK START - KTU IT Department Management System

**Ready to run in 5 minutes!**

---

## ⚡ SUPER QUICK SETUP

### 1️⃣ Install XAMPP (if not installed)
Download from: https://www.apachefriends.org

### 2️⃣ Copy Project
Move `ktu-it-dept` folder to:
- Windows: `C:\xampp\htdocs\`
- Mac: `/Applications/XAMPP/htdocs/`
- Linux: `/opt/lampp/htdocs/`

### 3️⃣ Start Services
Open XAMPP Control Panel → Start **Apache** and **MySQL**

### 4️⃣ Create Database
1. Go to: http://localhost/phpmyadmin
2. Click "New" → Name: `it_department_db` → Create
3. Click "Import" → Choose `database.sql` → Go

### 5️⃣ Access System
Open browser → http://localhost/ktu-it-dept

---

## 🔑 DEFAULT LOGIN

**Admin:**
- Email: `admin@ktu.edu.gh`
- Password: `admin123`

**Student:**
- Register a new account at signup page

---

## ✅ WHAT YOU GET

✨ **20 Complete Files:**
- 14 PHP files (fully functional)
- 1 CSS file (3,500+ lines, modern design)
- 1 JavaScript file (interactive features)
- 1 SQL database file
- 3 Documentation files

🎨 **Modern UI Features:**
- Responsive design (mobile-friendly)
- Professional color scheme
- Smooth animations
- Card-based layout
- Dynamic navigation

🔐 **Security Features:**
- Password hashing (bcrypt)
- SQL injection prevention
- Session management
- Role-based access control
- Input sanitization

📊 **Admin Features:**
- Create/Edit/Delete announcements
- View all students
- Dashboard with statistics
- Search functionality

👨‍🎓 **Student Features:**
- Personal dashboard
- View all announcements
- Profile information
- Real-time updates

---

## 📁 FILES INCLUDED

```
✓ Root Files (8)
  - index.php (landing page)
  - login.php, signup.php, logout.php
  - database.sql
  - README.md, INSTALLATION.md, PROJECT_STRUCTURE.md
  - .htaccess

✓ Admin Files (3)
  - dashboard.php
  - announcements.php (CRUD)
  - students.php

✓ User Files (2)
  - dashboard.php
  - updates.php

✓ Config Files (2)
  - database.php
  - functions.php

✓ Includes (3)
  - header.php, navbar.php, footer.php

✓ Assets (2)
  - style.css (modern design)
  - main.js (interactions)
```

---

## 🎯 TESTING CHECKLIST

After setup, verify:
- [ ] Homepage loads
- [ ] Can register student account
- [ ] Can login as student
- [ ] Can login as admin
- [ ] Admin can create announcement
- [ ] Student can view announcements
- [ ] Mobile menu works
- [ ] Logout works

---

## 🆘 COMMON ISSUES

**"Database connection failed"**
→ Start MySQL in XAMPP

**"Page not found"**
→ Check folder is named `ktu-it-dept`

**CSS not loading**
→ Clear browser cache (Ctrl+F5)

**Can't login**
→ Re-import database.sql

---

## 📚 DOCUMENTATION

Full guides available:
- `README.md` - Complete documentation
- `INSTALLATION.md` - Step-by-step guide
- `PROJECT_STRUCTURE.md` - File structure

---

## 🎓 PROJECT INFO

**Developer:** Henry Addo Nortey  
**Institution:** Kumasi Technical University  
**Department:** Computer Science (Final Semester Project)

**Tech Stack:**
- PHP + MySQL (Backend)
- HTML5 + CSS3 + JavaScript (Frontend)
- XAMPP Server
- Google Fonts + Font Awesome

---

## ✨ READY TO PRESENT

Perfect for:
- ✅ Final year project submission
- ✅ Live demonstrations
- ✅ Portfolio showcase
- ✅ Real-world deployment

All code is production-ready, well-commented, and follows best practices!

---

**Need help?** Check the detailed guides in README.md and INSTALLATION.md

**Good luck with your project! 🎉**
