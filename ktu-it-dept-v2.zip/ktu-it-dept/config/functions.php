<?php
/**
 * Helper Functions — KsTU IT Department
 */

function isLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['user_role']);
}
function isAdmin() {
    return isLoggedIn() && $_SESSION['user_role'] === 'admin';
}
function isStudent() {
    return isLoggedIn() && $_SESSION['user_role'] === 'student';
}
function requireLogin() {
    if (!isLoggedIn()) {
        header("Location: " . SITE_URL . "/login.php");
        exit();
    }
}
function requireAdmin() {
    if (!isAdmin()) {
        header("Location: " . SITE_URL . "/login.php");
        exit();
    }
}
function redirectIfLoggedIn() {
    if (isLoggedIn()) {
        if (isAdmin()) {
            header("Location: " . SITE_URL . "/admin/dashboard.php");
        } else {
            header("Location: " . SITE_URL . "/user/dashboard.php");
        }
        exit();
    }
}
function sanitizeInput($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}
function hashPassword($password) {
    return password_hash($password, PASSWORD_BCRYPT);
}
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}
function formatDate($date) {
    return date('M j, Y', strtotime($date));
}
function formatDateTime($datetime) {
    return date('M j, Y g:i A', strtotime($datetime));
}
function timeAgo($datetime) {
    $diff = time() - strtotime($datetime);
    if ($diff < 60) return 'just now';
    if ($diff < 3600) { $m = floor($diff/60); return $m.' min'.($m>1?'s':'').' ago'; }
    if ($diff < 86400) { $h = floor($diff/3600); return $h.' hr'.($h>1?'s':'').' ago'; }
    if ($diff < 604800) { $d = floor($diff/86400); return $d.' day'.($d>1?'s':'').' ago'; }
    return formatDate($datetime);
}
function getUserById($conn, $id) {
    $stmt = mysqli_prepare($conn, "SELECT * FROM users WHERE id=?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    return mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
}
function getFirstName($name) {
    return explode(' ', $name)[0];
}
function getCategoryIcon($cat) {
    $map = ['event'=>'fa-calendar-alt','notice'=>'fa-bell','academic'=>'fa-graduation-cap','general'=>'fa-info-circle'];
    return $map[$cat] ?? 'fa-info-circle';
}
function getTypeIcon($type) {
    $map = ['complaint'=>'fa-exclamation-circle','feedback'=>'fa-comment-dots','suggestion'=>'fa-lightbulb'];
    return $map[$type] ?? 'fa-comment';
}
function getTypeColor($type) {
    $map = ['complaint'=>'#e53935','feedback'=>'#0288d1','suggestion'=>'#9c27b0'];
    return $map[$type] ?? '#5a6380';
}
function getStatusColor($status) {
    $map = ['pending'=>'badge-pending','resolved'=>'badge-resolved','dismissed'=>'badge-dismissed'];
    return $map[$status] ?? 'badge-pending';
}
