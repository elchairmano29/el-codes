<?php
/**
 * Database Configuration
 * KTU IT Department Management System
 */

// Database credentials
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'it_department_db');

// Create connection
$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Set charset to utf8mb4
mysqli_set_charset($conn, "utf8mb4");

// Site configuration
define('SITE_NAME', 'KTU IT Department');
define('SITE_URL', 'http://localhost/ktu-it-dept');

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
