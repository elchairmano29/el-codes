<?php
require_once 'config/database.php';
require_once 'config/functions.php';
session_destroy();
header("Location: " . SITE_URL . "/login.php?logout=1");
exit();
