/**
 * KsTU IT Department — Main JS
 */
document.addEventListener('DOMContentLoaded', () => {

  /* ── Sidebar toggle (mobile) ── */
  const sidebar   = document.getElementById('sidebar');
  const overlay   = document.getElementById('sidebarOverlay');
  const toggleBtn = document.getElementById('sidebarToggle');
  const closeBtn  = document.getElementById('sidebarClose');

  function openSidebar() {
    sidebar?.classList.add('open');
    overlay?.classList.add('show');
    document.body.style.overflow = 'hidden';
  }
  function closeSidebar() {
    sidebar?.classList.remove('open');
    overlay?.classList.remove('show');
    document.body.style.overflow = '';
  }

  toggleBtn?.addEventListener('click', openSidebar);
  closeBtn?.addEventListener('click', closeSidebar);
  overlay?.addEventListener('click', closeSidebar);

  // Close on Escape
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') closeSidebar();
  });

  // Close sidebar when resizing to desktop width
  window.addEventListener('resize', () => {
    if (window.innerWidth > 900) closeSidebar();
  });

  /* ── Navbar active link ── */
  const currentPath = window.location.pathname;
  document.querySelectorAll('.navbar-menu a').forEach(link => {
    if (link.href && currentPath.includes(link.getAttribute('href').split('/').pop())) {
      link.classList.add('active');
    }
  });

  /* ── Alert auto-dismiss ── */
  document.querySelectorAll('.alert').forEach(el => {
    setTimeout(() => {
      el.style.transition = 'opacity .5s ease, max-height .5s ease, margin .5s ease, padding .5s ease';
      el.style.opacity = '0';
      el.style.maxHeight = '0';
      el.style.marginBottom = '0';
      el.style.paddingTop = '0';
      el.style.paddingBottom = '0';
    }, 5500);
  });

  /* ── Stagger animate cards ── */
  const observer = new IntersectionObserver(entries => {
    entries.forEach((entry, i) => {
      if (entry.isIntersecting) {
        setTimeout(() => {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
        }, i * 70);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.08 });

  document.querySelectorAll('.card, .feedback-item, .stat-card').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(16px)';
    el.style.transition = 'opacity .4s ease, transform .4s ease';
    observer.observe(el);
  });

  /* ── Confirm delete ── */
  document.querySelectorAll('[data-confirm]').forEach(el => {
    el.addEventListener('click', e => {
      if (!confirm(el.dataset.confirm || 'Are you sure?')) e.preventDefault();
    });
  });

  /* ── Character counter for textareas ── */
  document.querySelectorAll('textarea[maxlength]').forEach(ta => {
    const max = parseInt(ta.getAttribute('maxlength'));
    const counter = document.createElement('small');
    counter.style.cssText = 'float:right;color:var(--text-muted);font-size:.75rem';
    ta.parentNode.appendChild(counter);
    const update = () => counter.textContent = `${ta.value.length}/${max}`;
    ta.addEventListener('input', update);
    update();
  });

  /* ── Back to top ── */
  const toTop = document.createElement('button');
  toTop.innerHTML = '<i class="fas fa-arrow-up"></i>';
  toTop.title = 'Back to top';
  toTop.style.cssText = 'position:fixed;bottom:1.5rem;right:1.5rem;z-index:999;width:42px;height:42px;border-radius:50%;background:var(--primary);color:white;border:none;cursor:pointer;box-shadow:0 4px 14px rgba(26,35,126,.35);display:none;align-items:center;justify-content:center;font-size:.95rem;transition:all .25s ease';
  document.body.appendChild(toTop);
  window.addEventListener('scroll', () => {
    toTop.style.display = window.scrollY > 400 ? 'flex' : 'none';
  });
  toTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

});
