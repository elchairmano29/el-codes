# KTU IT Department Management System

A complete full-stack web application for managing the IT Department at Kumasi Technical University.

**Author:** Henry Addo Nortey  
**Project:** Final Semester Project  
**Institution:** Kumasi Technical University

---

## Features

### User Authentication
- Secure login and signup system
- Role-based access control (Admin and Student)
- Password hashing with bcrypt
- Session management

### Admin Dashboard
- View total statistics (students, announcements, etc.)
- Create, Read, Update, Delete (CRUD) announcements
- View all registered students
- Manage department updates

### Student Dashboard
- View personal profile information
- Access all published announcements
- Real-time updates section
- Modern, responsive interface

### Modern UI/UX
- Responsive design (mobile-friendly)
- Professional color scheme (Academic Blue & Gold)
- Card-based layout
- Smooth animations and transitions
- Dynamic navigation based on login status

---

## Technology Stack

- **Backend:** PHP (with MySQLi)
- **Database:** MySQL
- **Frontend:** HTML5, CSS3, Vanilla JavaScript
- **Fonts:** Google Fonts (Poppins, Inter)
- **Icons:** Font Awesome 6
- **Server:** XAMPP (Apache + MySQL)

---

## Installation Instructions

### Prerequisites
- XAMPP installed on your computer
- Web browser (Chrome, Firefox, Edge, etc.)

### Step 1: Setup XAMPP
1. Download and install XAMPP from [https://www.apachefriends.org](https://www.apachefriends.org)
2. Start Apache and MySQL services from the XAMPP Control Panel

### Step 2: Extract Project Files
1. Extract the `ktu-it-dept` folder
2. Copy the entire folder to your XAMPP `htdocs` directory
   - Windows: `C:\xampp\htdocs\`
   - Mac: `/Applications/XAMPP/htdocs/`
   - Linux: `/opt/lampp/htdocs/`

### Step 3: Create Database
1. Open your web browser and go to: `http://localhost/phpmyadmin`
2. Click on "New" to create a new database
3. Name it: `it_department_db`
4. Click on the "Import" tab
5. Click "Choose File" and select `database.sql` from the project folder
6. Click "Go" to import the database structure and sample data

### Step 4: Configure Database Connection
1. Open `config/database.php` in a text editor
2. Verify the database credentials (default settings should work):
   ```php
   DB_HOST: localhost
   DB_USER: root
   DB_PASS: (empty)
   DB_NAME: it_department_db
   ```
3. If you've changed your MySQL password, update `DB_PASS`

### Step 5: Access the Application
1. Open your web browser
2. Navigate to: `http://localhost/ktu-it-dept`
3. You should see the landing page

---

## Default Login Credentials

### Admin Account
- **Email:** admin@ktu.edu.gh
- **Password:** admin123

### Test Student Account
- You can create a new student account using the signup page

---

## Project Structure

```
ktu-it-dept/
│
├── admin/                      # Admin dashboard and management pages
│   ├── dashboard.php          # Admin dashboard
│   ├── announcements.php      # CRUD for announcements
│   └── students.php           # View registered students
│
├── assets/                     # Static assets
│   ├── css/
│   │   └── style.css          # Main stylesheet
│   └── js/
│       └── main.js            # JavaScript functions
│
├── config/                     # Configuration files
│   ├── database.php           # Database connection
│   └── functions.php          # Helper functions
│
├── includes/                   # Reusable components
│   ├── header.php             # HTML head section
│   ├── navbar.php             # Navigation bar
│   └── footer.php             # Footer section
│
├── user/                       # Student dashboard pages
│   ├── dashboard.php          # Student dashboard
│   └── updates.php            # View all announcements
│
├── database.sql               # Database schema and sample data
├── index.php                  # Landing page
├── login.php                  # Login page
├── signup.php                 # Registration page
├── logout.php                 # Logout handler
└── README.md                  # This file
```

---

## Usage Guide

### For Students

1. **Register an Account**
   - Click "Sign Up" on the homepage
   - Fill in your details (name, email, student ID, password)
   - Submit the form

2. **Login**
   - Enter your email and password
   - Click "Login"

3. **Access Dashboard**
   - View your profile information
   - See latest announcements
   - Navigate to "All Updates" for complete list

### For Administrators

1. **Login as Admin**
   - Use admin credentials (admin@ktu.edu.gh / admin123)

2. **Manage Announcements**
   - Click "Announcements" in the navigation
   - Create new announcements with the "New Announcement" button
   - Edit or delete existing announcements
   - Toggle publish status

3. **View Students**
   - Click "Students" in the navigation
   - See all registered students
   - Use search bar to filter students

---

## Database Schema

### Users Table
- `id` - Primary key
- `full_name` - User's full name
- `email` - Email address (unique)
- `password` - Hashed password
- `role` - 'student' or 'admin'
- `student_id` - Student ID number
- `phone` - Phone number
- `created_at` - Registration timestamp

### Announcements Table
- `id` - Primary key
- `title` - Announcement title
- `content` - Announcement content
- `category` - 'event', 'notice', 'academic', or 'general'
- `created_by` - Foreign key to users table
- `is_published` - Published status (1 or 0)
- `created_at` - Creation timestamp

---

## Security Features

- Password hashing using PHP's `password_hash()` with bcrypt
- SQL injection prevention using prepared statements
- Input sanitization and validation
- Session-based authentication
- Role-based access control
- CSRF protection ready (can be enhanced)

---

## Customization

### Changing Colors
Edit `/assets/css/style.css` and modify the CSS variables:
```css
:root {
    --primary: #1a237e;      /* Main color */
    --accent: #ffa000;       /* Accent color */
    /* ... other colors ... */
}
```

### Adding More Fields
1. Add columns to database tables using phpMyAdmin
2. Update corresponding PHP files to handle new fields
3. Modify forms to include new input fields

### Changing Site Name
Edit `config/database.php`:
```php
define('SITE_NAME', 'Your Custom Name');
```

---

## Troubleshooting

### Database Connection Failed
- Ensure MySQL is running in XAMPP
- Verify database credentials in `config/database.php`
- Check if database `it_department_db` exists

### Page Not Found (404)
- Ensure project is in the correct htdocs folder
- Check that Apache is running
- Verify the URL: `http://localhost/ktu-it-dept`

### Styles Not Loading
- Clear browser cache
- Check file paths in `includes/header.php`
- Ensure CSS file exists in `/assets/css/style.css`

### Login Issues
- Clear browser cookies and sessions
- Verify user exists in database
- Check password is correct (use demo credentials to test)

---

## Future Enhancements

Potential features that can be added:
- File upload for announcements (images, PDFs)
- Email notifications for new announcements
- Student profile editing
- Comment system on announcements
- Advanced search and filtering
- Export student data to Excel/PDF
- Password reset functionality
- Multi-language support

---

## Support

For questions or issues, contact:
- **Developer:** Henry Addo Nortey
- **Email:** (Your email here)
- **Institution:** Kumasi Technical University

---

## License

This project is developed as a final semester project for educational purposes at Kumasi Technical University.

---

## Acknowledgments

- Kumasi Technical University IT Department
- Project Supervisor: (Supervisor's name)
- All students and faculty who provided feedback

---

**Last Updated:** March 31, 2026
