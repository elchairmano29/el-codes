<?php
require_once 'config/database.php';
require_once 'config/functions.php';
redirectIfLoggedIn();
$page_title = 'Sign Up';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name       = sanitizeInput($_POST['full_name'] ?? '');
    $email           = trim($_POST['email'] ?? '');
    $student_id      = sanitizeInput($_POST['student_id'] ?? '');
    $phone           = sanitizeInput($_POST['phone'] ?? '');
    $password        = $_POST['password'] ?? '';
    $confirm_password= $_POST['confirm_password'] ?? '';

    if (empty($full_name)||empty($email)||empty($student_id)||empty($password)) {
        $error = 'Please fill in all required fields.';
    } elseif (!validateEmail($email)) {
        $error = 'Please enter a valid email address.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } elseif ($password !== $confirm_password) {
        $error = 'Passwords do not match.';
    } else {
        $chk = mysqli_prepare($conn, "SELECT id FROM users WHERE email=? OR student_id=?");
        mysqli_stmt_bind_param($chk, "ss", $email, $student_id);
        mysqli_stmt_execute($chk);
        mysqli_stmt_store_result($chk);
        if (mysqli_stmt_num_rows($chk) > 0) {
            $error = 'Email or Student ID is already registered.';
        } else {
            $hash = hashPassword($password);
            $ins  = mysqli_prepare($conn, "INSERT INTO users (full_name,email,password,student_id,phone,role) VALUES (?,?,?,?,?,'student')");
            mysqli_stmt_bind_param($ins, "sssss", $full_name, $email, $hash, $student_id, $phone);
            if (mysqli_stmt_execute($ins)) {
                header("Location: login.php?registered=1");
                exit();
            } else {
                $error = 'Registration failed. Please try again.';
            }
        }
    }
}
include 'includes/header.php';
include 'includes/navbar.php';
?>
<div class="container" style="padding-top:2rem;padding-bottom:3rem">
  <div class="form-container animate-in" style="max-width:560px">
    <div class="form-header">
      <div class="logo-wrap"><img src="<?php echo SITE_URL; ?>/assets/KsTU_logo.png" alt="KsTU"></div>
      <h2>Create Your Account</h2>
      <p>Join the KsTU IT Department student portal</p>
    </div>

    <?php if ($error): ?>
      <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i><?php echo $error; ?></div>
    <?php endif; ?>

    <form method="POST" action="" autocomplete="off">
      <div class="form-row">
        <div class="form-group">
          <label>Full Name <span style="color:var(--danger)">*</span></label>
          <div class="input-wrap">
            <i class="fas fa-user ico"></i>
            <input type="text" name="full_name" placeholder="e.g. Kwame Mensah"
              value="<?php echo htmlspecialchars($_POST['full_name'] ?? ''); ?>" required>
          </div>
        </div>
        <div class="form-group">
          <label>Student ID <span style="color:var(--danger)">*</span></label>
          <div class="input-wrap">
            <i class="fas fa-id-card ico"></i>
            <input type="text" name="student_id" placeholder="e.g. 2021CS001"
              value="<?php echo htmlspecialchars($_POST['student_id'] ?? ''); ?>" required>
          </div>
        </div>
      </div>
      <div class="form-group">
        <label>Email Address <span style="color:var(--danger)">*</span></label>
        <div class="input-wrap">
          <i class="fas fa-envelope ico"></i>
          <input type="email" name="email" placeholder="student@ktu.edu.gh"
            value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
        </div>
      </div>
      <div class="form-group">
        <label>Phone Number</label>
        <div class="input-wrap">
          <i class="fas fa-phone ico"></i>
          <input type="tel" name="phone" placeholder="0501234567"
            value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>">
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Password <span style="color:var(--danger)">*</span></label>
          <div class="input-wrap">
            <i class="fas fa-lock ico"></i>
            <input type="password" name="password" id="pw1" placeholder="Min. 6 characters" required>
            <button type="button" class="pw-toggle" onclick="togglePw('pw1','ic1')"><i class="fas fa-eye" id="ic1"></i></button>
          </div>
        </div>
        <div class="form-group">
          <label>Confirm Password <span style="color:var(--danger)">*</span></label>
          <div class="input-wrap">
            <i class="fas fa-lock ico"></i>
            <input type="password" name="confirm_password" id="pw2" placeholder="Re-enter password" required>
            <button type="button" class="pw-toggle" onclick="togglePw('pw2','ic2')"><i class="fas fa-eye" id="ic2"></i></button>
          </div>
        </div>
      </div>
      <button type="submit" class="btn btn-primary btn-block btn-lg" style="margin-top:.75rem">
        <i class="fas fa-user-plus"></i> Create Account
      </button>
    </form>
    <p style="text-align:center;margin-top:1.5rem;font-size:.88rem">
      Already have an account? <a href="login.php" style="color:var(--primary);font-weight:700">Sign in here</a>
    </p>
  </div>
</div>
<script>
function togglePw(id,ic){const i=document.getElementById(id),ico=document.getElementById(ic);i.type=i.type==='password'?'text':'password';ico.className=i.type==='password'?'fas fa-eye':'fas fa-eye-slash';}
</script>
<?php include 'includes/footer.php'; mysqli_close($conn); ?>
