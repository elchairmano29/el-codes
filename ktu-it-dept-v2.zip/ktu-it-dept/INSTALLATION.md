# INSTALLATION GUIDE
## KTU IT Department Management System

**Student:** Henry Addo Nortey  
**Institution:** Kumasi Technical University  
**Supervisor:** (Your Supervisor's Name)

---

## QUICK START GUIDE

Follow these steps to get your project running on XAMPP:

### STEP 1: Install XAMPP

1. Download XAMPP from: https://www.apachefriends.org
2. Install XAMPP on your computer
3. Launch XAMPP Control Panel
4. Start **Apache** and **MySQL** services

### STEP 2: Setup Project Files

1. Locate your XAMPP `htdocs` folder:
   - **Windows:** `C:\xampp\htdocs\`
   - **Mac:** `/Applications/XAMPP/htdocs/`
   - **Linux:** `/opt/lampp/htdocs/`

2. Copy the entire `ktu-it-dept` folder into the `htdocs` directory

3. Your structure should look like:
   ```
   htdocs/
   └── ktu-it-dept/
       ├── admin/
       ├── assets/
       ├── config/
       ├── includes/
       ├── user/
       ├── database.sql
       ├── index.php
       └── ... (other files)
   ```

### STEP 3: Create Database

1. Open your web browser

2. Go to: `http://localhost/phpmyadmin`

3. Click on **"New"** in the left sidebar

4. Enter database name: `it_department_db`

5. Click **"Create"**

6. Click on the newly created `it_department_db` database

7. Click on the **"Import"** tab at the top

8. Click **"Choose File"** button

9. Navigate to your project folder and select: `database.sql`

10. Scroll down and click **"Go"**

11. Wait for the import to complete (you should see a success message)

### STEP 4: Verify Installation

1. Open your web browser

2. Go to: `http://localhost/ktu-it-dept`

3. You should see the landing page with:
   - KTU IT Department header
   - Hero section with welcome message
   - Recent Updates section
   - Login and Sign Up buttons

### STEP 5: Test Login

**Admin Access:**
- Go to: `http://localhost/ktu-it-dept/login.php`
- Email: `admin@ktu.edu.gh`
- Password: `admin123`
- Click "Login"
- You should be redirected to the Admin Dashboard

**Student Access:**
- Go to: `http://localhost/ktu-it-dept/signup.php`
- Create a new student account
- Login with your credentials
- You should see the Student Dashboard

---

## CONFIGURATION SETTINGS

### Database Configuration

If you need to change database settings, edit: `config/database.php`

```php
// Default settings (works out of the box with XAMPP)
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');  // Empty by default in XAMPP
define('DB_NAME', 'it_department_db');
```

**If you set a MySQL password:**
1. Open `config/database.php`
2. Change the `DB_PASS` value to your password
3. Save the file

### Site URL Configuration

The site URL is automatically set to: `http://localhost/ktu-it-dept`

If you changed the folder name, update `config/database.php`:
```php
define('SITE_URL', 'http://localhost/your-folder-name');
```

---

## TESTING CHECKLIST

Use this checklist to verify everything works:

### Public Pages
- [ ] Home page loads correctly (`http://localhost/ktu-it-dept`)
- [ ] Login page accessible
- [ ] Signup page accessible
- [ ] Navigation menu works
- [ ] Recent updates display on homepage

### Student Features
- [ ] Student can register a new account
- [ ] Student can login
- [ ] Student dashboard displays correctly
- [ ] Student can view profile information
- [ ] Student can view all announcements
- [ ] Logout works

### Admin Features
- [ ] Admin can login with default credentials
- [ ] Admin dashboard shows statistics
- [ ] Admin can create new announcement
- [ ] Admin can edit existing announcement
- [ ] Admin can delete announcement
- [ ] Admin can view list of students
- [ ] Search functionality works on students page
- [ ] Logout works

### Security
- [ ] Cannot access admin pages without login
- [ ] Cannot access student pages without login
- [ ] Passwords are hidden during input
- [ ] Cannot register with duplicate email
- [ ] Cannot register with duplicate student ID

---

## TROUBLESHOOTING

### Problem: "Database connection failed"
**Solution:**
1. Verify MySQL is running in XAMPP Control Panel
2. Check if database `it_department_db` exists in phpMyAdmin
3. Verify database credentials in `config/database.php`
4. Restart Apache and MySQL services

### Problem: "Page not found" or "404 Error"
**Solution:**
1. Ensure folder name is exactly `ktu-it-dept`
2. Check that Apache is running
3. Clear browser cache
4. Try: `http://localhost/ktu-it-dept/index.php` (with index.php explicitly)

### Problem: CSS not loading / page looks broken
**Solution:**
1. Check that `assets` folder exists with `css` and `js` subfolders
2. Clear browser cache (Ctrl+F5 or Cmd+Shift+R)
3. Verify file path in `includes/header.php`
4. Check browser console for errors (F12)

### Problem: Cannot login with admin credentials
**Solution:**
1. Go to phpMyAdmin: `http://localhost/phpmyadmin`
2. Select `it_department_db` database
3. Browse the `users` table
4. Verify admin user exists with email: `admin@ktu.edu.gh`
5. If not found, re-import `database.sql`

### Problem: "Call to undefined function mysqli_connect()"
**Solution:**
1. Open XAMPP Control Panel
2. Click "Config" button next to Apache
3. Select "PHP (php.ini)"
4. Find line: `;extension=mysqli`
5. Remove the semicolon: `extension=mysqli`
6. Save file and restart Apache

### Problem: Images or fonts not loading
**Solution:**
1. Check internet connection (Google Fonts loads from CDN)
2. Verify Font Awesome CDN link in `includes/header.php`
3. If offline, download fonts locally

---

## PROJECT DEMONSTRATION GUIDE

### For Your Lecturer/Supervisor

**1. Introduction (2 minutes)**
- Explain the purpose of the system
- Mention the technologies used
- Show the project structure

**2. User Registration (2 minutes)**
- Navigate to signup page
- Register a new student account
- Explain form validation

**3. Student Features (3 minutes)**
- Login as the student you just created
- Show student dashboard
- Display profile information
- View announcements
- Demonstrate navigation
- Logout

**4. Admin Features (5 minutes)**
- Login as admin (admin@ktu.edu.gh / admin123)
- Show admin dashboard with statistics
- Create a new announcement
- Edit an existing announcement
- Delete an announcement
- View students list
- Demonstrate search functionality
- Logout

**5. Security Features (2 minutes)**
- Try to access admin page while logged out (redirect)
- Show password hashing in database (phpMyAdmin)
- Explain session management

**6. Responsive Design (1 minute)**
- Resize browser window to show mobile responsiveness
- Demonstrate mobile menu

**Total Time:** ~15 minutes

---

## ADDITIONAL NOTES

### Changing Admin Password

1. Login as admin
2. Go to phpMyAdmin
3. Select `it_department_db` database
4. Open `users` table
5. Edit admin user record
6. Use this PHP snippet to generate new password hash:
   ```php
   <?php
   echo password_hash('your_new_password', PASSWORD_BCRYPT);
   ?>
   ```
7. Replace the `password` field value with the generated hash

### Adding Sample Students

If you want to add more sample students:
1. Use the signup page, OR
2. Go to phpMyAdmin → `users` table → Insert
3. Manually add records (make sure to hash passwords first)

### Backup Your Database

Before making changes:
1. Go to phpMyAdmin
2. Select `it_department_db`
3. Click "Export" tab
4. Click "Go"
5. Save the SQL file as backup

### Customizing the Design

All styling is in: `assets/css/style.css`

Key sections to customize:
- Colors: Search for `:root` CSS variables
- Fonts: Change `--font-display` and `--font-body`
- Layout: Modify grid and container styles

---

## SUPPORT & CONTACT

**Developer:** Henry Addo Nortey  
**Institution:** Kumasi Technical University  
**Department:** Computer Science  
**Project Type:** Final Semester Project

For technical issues or questions about the project, contact the developer or project supervisor.

---

## PROJECT SUBMISSION CHECKLIST

Before submitting your project:

- [ ] All files are in the correct folder structure
- [ ] Database.sql file is included and tested
- [ ] README.md is complete with instructions
- [ ] All features work as expected
- [ ] Code is commented appropriately
- [ ] No syntax errors or warnings
- [ ] Tested on a clean XAMPP installation
- [ ] Screenshots of key pages captured
- [ ] Project documentation prepared
- [ ] Supervisor approval obtained

---

**Installation Guide Last Updated:** March 31, 2026

Good luck with your project presentation! 🎓
