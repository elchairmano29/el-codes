<?php
require_once '../config/database.php';
require_once '../config/functions.php';
requireLogin();
if (isAdmin()) { header("Location:".SITE_URL."/admin/dashboard.php"); exit(); }
$page_title = 'My Dashboard';
$user = getUserById($conn, $_SESSION['user_id']);

$ann_count  = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as c FROM announcements WHERE is_published=1"))['c'];
$comp_count = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as c FROM complaints WHERE user_id={$_SESSION['user_id']}"))['c'];
$pending_c  = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as c FROM complaints WHERE user_id={$_SESSION['user_id']} AND status='pending'"))['c'];

$latest = mysqli_query($conn,"SELECT a.*,u.full_name as author FROM announcements a JOIN users u ON a.created_by=u.id WHERE a.is_published=1 ORDER BY a.created_at DESC LIMIT 3");

include '../includes/header.php';
include '../includes/navbar.php';
?>
<div class="app-layout">
<?php include '../includes/sidebar_user.php'; ?>
<main class="main-content">

  <!-- Profile card -->
  <div class="profile-card animate-in">
    <div class="profile-banner"></div>
    <div class="profile-avatar-wrap">
      <div class="profile-avatar"><?php echo strtoupper(substr($user['full_name'],0,1)); ?></div>
    </div>
    <div class="profile-info">
      <h2><?php echo htmlspecialchars($user['full_name']); ?></h2>
      <div class="role-badge"><i class="fas fa-graduation-cap"></i> IT Department Student</div>
      <div class="profile-details-grid">
        <div class="profile-detail">
          <label>Student ID</label>
          <p><?php echo htmlspecialchars($user['student_id']??'—'); ?></p>
        </div>
        <div class="profile-detail">
          <label>Email</label>
          <p><?php echo htmlspecialchars($user['email']); ?></p>
        </div>
        <div class="profile-detail">
          <label>Phone</label>
          <p><?php echo htmlspecialchars($user['phone']??'Not provided'); ?></p>
        </div>
        <div class="profile-detail">
          <label>Member Since</label>
          <p><?php echo formatDate($user['created_at']); ?></p>
        </div>
      </div>
    </div>
  </div>

  <!-- Stats -->
  <div class="stats-grid animate-in">
    <div class="stat-card">
      <p>Total Updates</p>
      <div class="number"><?php echo $ann_count; ?></div>
      <div class="trend">Department announcements</div>
      <i class="fas fa-bell stat-icon"></i>
    </div>
    <div class="stat-card green">
      <p>My Submissions</p>
      <div class="number"><?php echo $comp_count; ?></div>
      <div class="trend">Feedback &amp; complaints sent</div>
      <i class="fas fa-comment-dots stat-icon"></i>
    </div>
    <div class="stat-card orange">
      <p>Awaiting Reply</p>
      <div class="number"><?php echo $pending_c; ?></div>
      <div class="trend">Pending responses</div>
      <i class="fas fa-clock stat-icon"></i>
    </div>
  </div>

  <!-- Quick Links -->
  <div class="section animate-in">
    <h3 style="margin-bottom:1rem">Quick Actions</h3>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:1rem">
      <?php
      $links=[
        ['href'=>SITE_URL.'/user/updates.php','bg'=>'#1a237e,#3949ab','icon'=>'fa-bell','title'=>'View All Updates','sub'=>'Browse all announcements'],
        ['href'=>SITE_URL.'/user/complaints.php?action=new','bg'=>'#00695c,#00897b','icon'=>'fa-comment-dots','title'=>'Send Feedback','sub'=>'Submit complaint or suggestion'],
        ['href'=>SITE_URL.'/user/complaints.php','bg'=>'#e65100,#fb8c00','icon'=>'fa-inbox','title'=>'My Submissions','sub'=>'Track your feedback status'],
        ['href'=>'mailto:itdepartment@ktu.edu.gh','bg'=>'#6a1b9a,#9c27b0','icon'=>'fa-envelope','title'=>'Email Department','sub'=>'itdepartment@ktu.edu.gh'],
      ];
      foreach ($links as $l): ?>
        <a href="<?php echo $l['href']; ?>" class="card" style="display:flex;flex-direction:column;gap:.75rem;cursor:pointer">
          <div class="card-icon" style="background:linear-gradient(135deg,<?php echo $l['bg']; ?>)">
            <i class="fas <?php echo $l['icon']; ?>"></i>
          </div>
          <div>
            <h4 style="font-size:.9rem;margin-bottom:.2rem"><?php echo $l['title']; ?></h4>
            <p style="font-size:.78rem"><?php echo $l['sub']; ?></p>
          </div>
        </a>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Latest Updates -->
  <div class="section animate-in">
    <div class="flex-between mb-2">
      <h3>Latest Updates</h3>
      <a href="<?php echo SITE_URL; ?>/user/updates.php" class="btn btn-outline btn-sm">View All</a>
    </div>
    <div class="cards-grid">
      <?php if (mysqli_num_rows($latest)>0): while ($a=mysqli_fetch_assoc($latest)): ?>
        <div class="card" style="position:relative;padding-left:1.75rem">
          <div style="position:absolute;left:0;top:0;bottom:0;width:4px;border-radius:4px 0 0 4px;background:<?php echo ['event'=>'#0288d1','notice'=>'#fb8c00','academic'=>'#9c27b0','general'=>'#00897b'][$a['category']]??'#1a237e'; ?>"></div>
          <div class="card-icon" style="background:linear-gradient(135deg,<?php echo ['event'=>'#0288d1,#4fc3f7','notice'=>'#fb8c00,#ffcc02','academic'=>'#9c27b0,#ce93d8','general'=>'#00897b,#4db6ac'][$a['category']]??'#1a237e,#3949ab'; ?>)">
            <i class="fas <?php echo getCategoryIcon($a['category']); ?>"></i>
          </div>
          <span class="badge badge-<?php echo $a['category']; ?>"><?php echo ucfirst($a['category']); ?></span>
          <h3 style="margin-top:.5rem"><?php echo htmlspecialchars($a['title']); ?></h3>
          <p style="margin-top:.35rem"><?php echo htmlspecialchars(substr($a['content'],0,120)).'…'; ?></p>
          <div class="card-meta"><i class="fas fa-clock"></i><span><?php echo timeAgo($a['created_at']); ?></span></div>
        </div>
      <?php endwhile; else: ?>
        <div class="empty-state" style="grid-column:1/-1"><i class="fas fa-inbox"></i><p>No updates yet.</p></div>
      <?php endif; ?>
    </div>
  </div>

</main>
</div>
<?php include '../includes/footer.php'; mysqli_close($conn); ?>
