<?php
require_once '../config/database.php';
require_once '../config/functions.php';
requireLogin();
if (isAdmin()) { header("Location:".SITE_URL."/admin/dashboard.php"); exit(); }
$page_title = 'Feedback & Complaints';
$error = ''; $success = '';

// Submit new complaint/feedback
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['submit_complaint'])) {
    $type      = in_array($_POST['type']??'',['complaint','feedback','suggestion']) ? $_POST['type'] : 'feedback';
    $subject   = sanitizeInput($_POST['subject']??'');
    $message   = trim($_POST['message']??'');
    $anonymous = isset($_POST['is_anonymous']) ? 1 : 0;
    if (empty($subject)||empty($message)) {
        $error = 'Please fill in all required fields.';
    } elseif (strlen($message)<10) {
        $error = 'Message must be at least 10 characters.';
    } else {
        $stmt = mysqli_prepare($conn,"INSERT INTO complaints (user_id,type,subject,message,is_anonymous) VALUES (?,?,?,?,?)");
        mysqli_stmt_bind_param($stmt,"isssi",$_SESSION['user_id'],$type,$subject,$message,$anonymous);
        if (mysqli_stmt_execute($stmt)) {
            $success = 'Your '.($type).' has been submitted successfully! The admin will respond soon.';
            // Clear POST to avoid resubmission
            $_POST = [];
        } else {
            $error = 'Submission failed. Please try again.';
        }
    }
}

$filter     = isset($_GET['filter']) && in_array($_GET['filter'],['complaint','feedback','suggestion']) ? $_GET['filter'] : 'all';
$where      = $filter==='all' ? '' : "AND type='$filter'";
$uid        = intval($_SESSION['user_id']);
$complaints = mysqli_query($conn,"SELECT * FROM complaints WHERE user_id=$uid $where ORDER BY created_at DESC");
$total_my   = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as c FROM complaints WHERE user_id=$uid"))['c'];
$pending_my = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as c FROM complaints WHERE user_id=$uid AND status='pending'"))['c'];
$resolved_my= mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as c FROM complaints WHERE user_id=$uid AND status='resolved'"))['c'];

$show_form = isset($_GET['action']) && $_GET['action']==='new';

include '../includes/header.php';
include '../includes/navbar.php';
?>
<div class="app-layout">
<?php include '../includes/sidebar_user.php'; ?>
<main class="main-content">

  <div class="page-header animate-in">
    <div>
      <h1>Feedback &amp; Complaints</h1>
      <p>Submit feedback, complaints, or suggestions to the IT Department</p>
    </div>
    <?php if (!$show_form): ?>
      <a href="?action=new" class="btn btn-primary"><i class="fas fa-plus"></i> New Submission</a>
    <?php else: ?>
      <a href="complaints.php" class="btn btn-outline"><i class="fas fa-arrow-left"></i> My Submissions</a>
    <?php endif; ?>
  </div>

  <?php if ($error): ?><div class="alert alert-danger animate-in"><i class="fas fa-exclamation-circle"></i><?php echo $error; ?></div><?php endif; ?>
  <?php if ($success): ?><div class="alert alert-success animate-in"><i class="fas fa-check-circle"></i><?php echo $success; ?></div><?php endif; ?>

  <?php if ($show_form): ?>
  <!-- SUBMISSION FORM -->
  <div class="card animate-in" style="max-width:620px">
    <h3 style="margin-bottom:1.5rem"><i class="fas fa-paper-plane"></i> New Submission</h3>
    <form method="POST" action="">
      <div class="form-group">
        <label>Type <span style="color:var(--danger)">*</span></label>
        <select name="type" id="typeSelect">
          <option value="feedback" <?php echo (($_POST['type']??'')==='feedback')?'selected':''; ?>>💬 Feedback — General feedback about the department</option>
          <option value="complaint" <?php echo (($_POST['type']??'')==='complaint')?'selected':''; ?>>⚠️ Complaint — Report an issue or problem</option>
          <option value="suggestion" <?php echo (($_POST['type']??'')==='suggestion')?'selected':''; ?>>💡 Suggestion — Propose an improvement</option>
        </select>
      </div>
      <div class="form-group">
        <label>Subject <span style="color:var(--danger)">*</span></label>
        <div class="input-wrap">
          <i class="fas fa-heading ico"></i>
          <input type="text" name="subject" placeholder="Brief subject line…" value="<?php echo htmlspecialchars($_POST['subject']??''); ?>" required>
        </div>
      </div>
      <div class="form-group">
        <label>Message <span style="color:var(--danger)">*</span></label>
        <textarea name="message" rows="6" placeholder="Describe your feedback, complaint, or suggestion in detail…" required><?php echo htmlspecialchars($_POST['message']??''); ?></textarea>
        <small style="color:var(--text-muted);font-size:.78rem">Minimum 10 characters. Be as detailed as possible.</small>
      </div>
      <div class="form-group">
        <label class="form-check">
          <input type="checkbox" name="is_anonymous" <?php echo isset($_POST['is_anonymous'])?'checked':''; ?>>
          <span>Submit anonymously <small style="color:var(--text-muted)">(your name will be hidden from admins)</small></span>
        </label>
      </div>
      <div style="display:flex;gap:.75rem;flex-wrap:wrap;margin-top:.5rem">
        <button type="submit" name="submit_complaint" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Submit</button>
        <a href="complaints.php" class="btn btn-outline">Cancel</a>
      </div>
    </form>
  </div>

  <?php else: ?>
  <!-- MY SUBMISSIONS LIST -->
  <div class="stats-grid animate-in" style="grid-template-columns:repeat(3,1fr);max-width:500px">
    <div class="stat-card"><p>Total</p><div class="number"><?php echo $total_my; ?></div><i class="fas fa-inbox stat-icon"></i></div>
    <div class="stat-card orange"><p>Pending</p><div class="number"><?php echo $pending_my; ?></div><i class="fas fa-clock stat-icon"></i></div>
    <div class="stat-card green"><p>Resolved</p><div class="number"><?php echo $resolved_my; ?></div><i class="fas fa-check stat-icon"></i></div>
  </div>

  <div class="filter-tabs animate-in">
    <?php foreach(['all'=>'All','feedback'=>'Feedback','complaint'=>'Complaints','suggestion'=>'Suggestions'] as $k=>$v): ?>
      <a href="?filter=<?php echo $k; ?>" class="filter-tab <?php echo $filter===$k?'active':''; ?>"><?php echo $v; ?></a>
    <?php endforeach; ?>
  </div>

  <div class="feedback-list animate-in">
    <?php if (mysqli_num_rows($complaints)>0): while ($c=mysqli_fetch_assoc($complaints)): ?>
      <div class="feedback-item">
        <div class="feedback-item-header">
          <div style="display:flex;align-items:center;gap:.75rem;flex:1">
            <div style="width:40px;height:40px;border-radius:50%;background:linear-gradient(135deg,<?php echo ['complaint'=>'#b71c1c,#e53935','feedback'=>'#01579b,#0288d1','suggestion'=>'#4a148c,#9c27b0'][$c['type']]??'#1a237e,#3949ab'; ?>);display:flex;align-items:center;justify-content:center;color:white;font-size:.9rem;flex-shrink:0">
              <i class="fas <?php echo getTypeIcon($c['type']); ?>"></i>
            </div>
            <div>
              <div style="display:flex;gap:.4rem;margin-bottom:.25rem">
                <span class="badge badge-<?php echo $c['type']; ?>"><?php echo ucfirst($c['type']); ?></span>
                <span class="badge <?php echo getStatusColor($c['status']); ?>"><?php echo ucfirst($c['status']); ?></span>
                <?php if ($c['is_anonymous']): ?><span class="badge" style="background:rgba(0,0,0,.08);color:var(--text-muted)"><i class="fas fa-user-secret"></i> Anonymous</span><?php endif; ?>
              </div>
              <div class="feedback-subject"><?php echo htmlspecialchars($c['subject']); ?></div>
            </div>
          </div>
          <span style="font-size:.78rem;color:var(--text-muted);white-space:nowrap"><?php echo timeAgo($c['created_at']); ?></span>
        </div>
        <p class="feedback-body"><?php echo htmlspecialchars(substr($c['message'],0,220)).(strlen($c['message'])>220?'…':''); ?></p>
        <div class="feedback-meta">
          <i class="fas fa-calendar"></i><span><?php echo formatDateTime($c['created_at']); ?></span>
        </div>
        <?php if ($c['admin_reply']): ?>
          <div class="feedback-response">
            <strong><i class="fas fa-reply"></i> Admin Response — <?php echo formatDateTime($c['replied_at']); ?></strong>
            <?php echo nl2br(htmlspecialchars($c['admin_reply'])); ?>
          </div>
        <?php elseif ($c['status']==='pending'): ?>
          <div style="margin-top:.75rem;padding:.6rem .85rem;background:var(--warning-light);border-radius:var(--r-sm);font-size:.8rem;color:var(--warning)">
            <i class="fas fa-clock"></i> Awaiting admin response…
          </div>
        <?php endif; ?>
      </div>
    <?php endwhile; else: ?>
      <div class="empty-state" style="background:var(--surface);border-radius:var(--r-lg);border:1px solid var(--border)">
        <i class="fas fa-comment-dots"></i>
        <p>You haven't submitted anything yet.</p>
        <a href="?action=new" class="btn btn-primary" style="margin-top:1rem"><i class="fas fa-plus"></i> Submit Feedback</a>
      </div>
    <?php endif; ?>
  </div>
  <?php endif; ?>

</main>
</div>
<?php include '../includes/footer.php'; mysqli_close($conn); ?>
