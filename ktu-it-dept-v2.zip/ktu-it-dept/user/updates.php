<?php
require_once '../config/database.php';
require_once '../config/functions.php';
requireLogin();
if (isAdmin()) { header("Location:".SITE_URL."/admin/dashboard.php"); exit(); }
$page_title = 'Updates & News';

$filter = isset($_GET['cat']) && in_array($_GET['cat'],['event','notice','academic','general']) ? $_GET['cat'] : 'all';
$where  = $filter==='all' ? "WHERE a.is_published=1" : "WHERE a.is_published=1 AND a.category='$filter'";
$announcements = mysqli_query($conn,"SELECT a.*,u.full_name as author FROM announcements a JOIN users u ON a.created_by=u.id $where ORDER BY a.created_at DESC");

include '../includes/header.php';
include '../includes/navbar.php';
?>
<div class="app-layout">
<?php include '../includes/sidebar_user.php'; ?>
<main class="main-content">

  <div class="page-header animate-in">
    <div>
      <h1>Updates &amp; News</h1>
      <p>All announcements and notices from the IT Department</p>
    </div>
  </div>

  <!-- Filter tabs -->
  <div class="filter-tabs animate-in">
    <?php foreach(['all'=>'All','general'=>'General','event'=>'Events','notice'=>'Notices','academic'=>'Academic'] as $k=>$v): ?>
      <a href="?cat=<?php echo $k; ?>" class="filter-tab <?php echo $filter===$k?'active':''; ?>"><?php echo $v; ?></a>
    <?php endforeach; ?>
  </div>

  <div class="cards-grid animate-in">
    <?php if (mysqli_num_rows($announcements)>0): while ($a=mysqli_fetch_assoc($announcements)): ?>
      <div class="card" style="position:relative;padding-left:1.75rem">
        <div style="position:absolute;left:0;top:0;bottom:0;width:4px;border-radius:4px 0 0 4px;background:<?php echo ['event'=>'#0288d1','notice'=>'#fb8c00','academic'=>'#9c27b0','general'=>'#00897b'][$a['category']]??'#1a237e'; ?>"></div>
        <div class="card-icon" style="background:linear-gradient(135deg,<?php echo ['event'=>'#0288d1,#4fc3f7','notice'=>'#fb8c00,#ffcc02','academic'=>'#9c27b0,#ce93d8','general'=>'#00897b,#4db6ac'][$a['category']]??'#1a237e,#3949ab'; ?>)">
          <i class="fas <?php echo getCategoryIcon($a['category']); ?>"></i>
        </div>
        <span class="badge badge-<?php echo $a['category']; ?>"><?php echo ucfirst($a['category']); ?></span>
        <h3 style="margin-top:.5rem"><?php echo htmlspecialchars($a['title']); ?></h3>
        <p style="margin-top:.4rem"><?php echo htmlspecialchars($a['content']); ?></p>
        <div class="card-meta" style="margin-top:1rem">
          <i class="fas fa-user-circle"></i><span><?php echo htmlspecialchars($a['author']); ?></span>
          <span>&bull;</span><i class="fas fa-clock"></i><span><?php echo timeAgo($a['created_at']); ?></span>
          <span>&bull;</span><span><?php echo formatDate($a['created_at']); ?></span>
        </div>
      </div>
    <?php endwhile; else: ?>
      <div class="empty-state" style="grid-column:1/-1;background:var(--surface);border-radius:var(--r-lg);border:1px solid var(--border)">
        <i class="fas fa-bell-slash"></i>
        <p>No <?php echo $filter!=='all'?$filter.' ':''; ?>announcements at the moment. Check back later!</p>
      </div>
    <?php endif; ?>
  </div>

</main>
</div>
<?php include '../includes/footer.php'; mysqli_close($conn); ?>
