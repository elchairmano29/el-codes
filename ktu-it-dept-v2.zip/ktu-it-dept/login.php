<?php
require_once 'config/database.php';
require_once 'config/functions.php';
redirectIfLoggedIn();
$page_title = 'Login';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = 'Please fill in all fields.';
    } else {
        $stmt = mysqli_prepare($conn, "SELECT * FROM users WHERE email = ?");
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $user   = mysqli_fetch_assoc($result);

        if ($user && verifyPassword($password, $user['password'])) {
            $_SESSION['user_id']    = $user['id'];
            $_SESSION['user_name']  = $user['full_name'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_role']  = $user['role'];

            if ($user['role'] === 'admin') {
                header("Location: " . SITE_URL . "/admin/dashboard.php");
            } else {
                header("Location: " . SITE_URL . "/user/dashboard.php");
            }
            exit();
        } else {
            $error = 'Invalid email or password. Please try again.';
        }
    }
}
include 'includes/header.php';
include 'includes/navbar.php';
?>
<div class="container" style="padding-top:2rem;padding-bottom:3rem">
  <div class="form-container animate-in">
    <div class="form-header">
      <div class="logo-wrap"><img src="<?php echo SITE_URL; ?>/assets/KsTU_logo.png" alt="KsTU"></div>
      <h2>Welcome Back!</h2>
      <p>Sign in to your KsTU IT Department account</p>
    </div>

    <?php if ($error): ?>
      <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i><?php echo $error; ?></div>
    <?php endif; ?>
    <?php if (isset($_GET['registered'])): ?>
      <div class="alert alert-success"><i class="fas fa-check-circle"></i> Registration successful! You can now log in.</div>
    <?php endif; ?>
    <?php if (isset($_GET['logout'])): ?>
      <div class="alert alert-info"><i class="fas fa-info-circle"></i> You have been logged out successfully.</div>
    <?php endif; ?>

    <form method="POST" action="" autocomplete="on">
      <div class="form-group">
        <label>Email Address</label>
        <div class="input-wrap">
          <i class="fas fa-envelope ico"></i>
          <input type="email" name="email" placeholder="your@email.com"
            value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" required autocomplete="email">
        </div>
      </div>
      <div class="form-group">
        <label>Password</label>
        <div class="input-wrap">
          <i class="fas fa-lock ico"></i>
          <input type="password" name="password" id="pw" placeholder="Enter your password" required autocomplete="current-password">
          <button type="button" class="pw-toggle" onclick="togglePw()"><i class="fas fa-eye" id="pwIcon"></i></button>
        </div>
      </div>
      <button type="submit" class="btn btn-primary btn-block btn-lg" style="margin-top:.75rem">
        <i class="fas fa-sign-in-alt"></i> Sign In
      </button>
    </form>

    <p style="text-align:center;margin-top:1.5rem;font-size:.88rem">
      Don't have an account? <a href="signup.php" style="color:var(--primary);font-weight:700">Create one here</a>
    </p>

    <div style="margin-top:1.25rem;padding-top:1.1rem;border-top:1px solid var(--border);background:var(--surface-2);border-radius:var(--r-md);padding:1rem;font-size:.82rem;color:var(--text-secondary)">
      <strong style="display:block;margin-bottom:.35rem;color:var(--text)"><i class="fas fa-shield-alt" style="color:var(--primary)"></i> Demo Credentials</strong>
      <span>Admin — admin@ktu.edu.gh / <code>password</code></span>
    </div>
  </div>
</div>
<script>
function togglePw(){
  const i=document.getElementById('pw'),ic=document.getElementById('pwIcon');
  i.type=i.type==='password'?'text':'password';
  ic.className=i.type==='password'?'fas fa-eye':'fas fa-eye-slash';
}
</script>
<?php include 'includes/footer.php'; mysqli_close($conn); ?>
