-- KTU IT Department Management System Database
-- Kumasi Technical University (KsTU)

CREATE DATABASE IF NOT EXISTS it_department_db;
USE it_department_db;

CREATE TABLE IF NOT EXISTS users (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('student', 'admin') DEFAULT 'student',
    student_id VARCHAR(50) DEFAULT NULL,
    phone VARCHAR(20) DEFAULT NULL,
    is_active TINYINT(1) DEFAULT 1,
    last_login TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS announcements (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    category ENUM('event', 'notice', 'academic', 'general') DEFAULT 'general',
    created_by INT(11) NOT NULL,
    is_published TINYINT(1) DEFAULT 1,
    views INT(11) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Complaints & Feedback table (NEW)
CREATE TABLE IF NOT EXISTS complaints (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    user_id INT(11) NOT NULL,
    type ENUM('complaint', 'feedback', 'suggestion') DEFAULT 'feedback',
    subject VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    status ENUM('pending', 'resolved', 'dismissed') DEFAULT 'pending',
    admin_reply TEXT DEFAULT NULL,
    replied_by INT(11) DEFAULT NULL,
    replied_at TIMESTAMP NULL,
    is_anonymous TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (replied_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Default admin (password: admin123)
INSERT IGNORE INTO users (full_name, email, password, role, student_id, phone) VALUES
('IT Admin', 'admin@ktu.edu.gh', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', NULL, '0501234567');

INSERT IGNORE INTO announcements (title, content, category, created_by) VALUES
('Welcome to KsTU IT Department Portal', 'We are excited to launch the new management system. Students can now access important updates, events, and resources all in one place.', 'general', 1),
('Upcoming Web Development Workshop', 'Join us for an intensive 3-day workshop on Modern Web Development using React and Node.js. Register at the IT Department office by Friday.', 'event', 1),
('Final Year Project Submission Deadline', 'All final year students must submit their project documentation by April 30, 2026. Late submissions will not be accepted.', 'academic', 1),
('Lab Access Hours Extended', 'Starting next week, the computer labs will be open until 8 PM on weekdays to accommodate student project work.', 'notice', 1);
