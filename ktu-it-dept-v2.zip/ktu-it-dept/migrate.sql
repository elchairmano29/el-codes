-- ============================================================
-- KsTU IT Dept — Safe Migration Script
-- Run this in phpMyAdmin if you already have the old database.
-- It safely adds new columns/tables WITHOUT deleting any data.
-- ============================================================

USE it_department_db;

-- 1. Add new columns to users table (safe — won't fail if they exist)
ALTER TABLE users
    ADD COLUMN IF NOT EXISTS is_active TINYINT(1) DEFAULT 1,
    ADD COLUMN IF NOT EXISTS last_login TIMESTAMP NULL;

-- 2. Add views column to announcements table
ALTER TABLE announcements
    ADD COLUMN IF NOT EXISTS views INT(11) DEFAULT 0;

-- 3. Create complaints table (new feature)
CREATE TABLE IF NOT EXISTS complaints (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    user_id INT(11) NOT NULL,
    type ENUM('complaint', 'feedback', 'suggestion') DEFAULT 'feedback',
    subject VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    status ENUM('pending', 'resolved', 'dismissed') DEFAULT 'pending',
    admin_reply TEXT DEFAULT NULL,
    replied_by INT(11) DEFAULT NULL,
    replied_at TIMESTAMP NULL,
    is_anonymous TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (replied_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Add indexes for new columns
CREATE INDEX IF NOT EXISTS idx_comp_user   ON complaints(user_id);
CREATE INDEX IF NOT EXISTS idx_comp_status ON complaints(status);
CREATE INDEX IF NOT EXISTS idx_comp_type   ON complaints(type);

-- Done! All existing data is preserved.
SELECT 'Migration complete!' AS Status;
