<?php
/**
 * index.php — Entry point redirect
 * Redirects to login or appropriate dashboard
 */
require_once 'config.php';

if (isLoggedIn()) {
    header('Location: ' . ($_SESSION['role'] === 'admin' ? 'admin_dashboard.php' : 'employee_dashboard.php'));
} else {
    header('Location: login.php');
}
exit();
