-- ============================================================
-- PAYROLL MANAGEMENT SYSTEM - DATABASE SCHEMA
-- Compatible with MySQL 5.7+ / MariaDB 10.3+
-- ============================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

DROP DATABASE IF EXISTS `payroll_db`;
CREATE DATABASE `payroll_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `payroll_db`;

-- ============================================================
-- TABLE: departments
-- ============================================================
CREATE TABLE `departments` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `code` VARCHAR(20) NOT NULL,
  `manager_id` INT UNSIGNED DEFAULT NULL,
  `budget` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_dept_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE: users
-- ============================================================
CREATE TABLE `users` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_id` VARCHAR(20) NOT NULL,
  `first_name` VARCHAR(60) NOT NULL,
  `last_name` VARCHAR(60) NOT NULL,
  `email` VARCHAR(150) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `role` ENUM('admin','employee') NOT NULL DEFAULT 'employee',
  `department_id` INT UNSIGNED DEFAULT NULL,
  `job_title` VARCHAR(100) DEFAULT NULL,
  `hire_date` DATE DEFAULT NULL,
  `employment_type` ENUM('full_time','part_time','contract') NOT NULL DEFAULT 'full_time',
  `status` ENUM('active','inactive','terminated') NOT NULL DEFAULT 'active',
  `phone` VARCHAR(30) DEFAULT NULL,
  `address` TEXT DEFAULT NULL,
  `date_of_birth` DATE DEFAULT NULL,
  `bank_name` VARCHAR(100) DEFAULT NULL,
  `bank_account` VARCHAR(50) DEFAULT NULL,
  `tax_id` VARCHAR(50) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_email` (`email`),
  UNIQUE KEY `uk_employee_id` (`employee_id`),
  KEY `idx_department` (`department_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_user_dept` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE: salary_structures
-- ============================================================
CREATE TABLE `salary_structures` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NOT NULL,
  `base_salary` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `hourly_rate` DECIMAL(8,2) DEFAULT NULL,
  `overtime_multiplier` DECIMAL(4,2) NOT NULL DEFAULT 1.50,
  `housing_allowance` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `transport_allowance` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `meal_allowance` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `medical_allowance` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `effective_date` DATE NOT NULL,
  `currency` VARCHAR(10) NOT NULL DEFAULT 'USD',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_salary_user` (`user_id`),
  CONSTRAINT `fk_salary_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE: pay_periods
-- ============================================================
CREATE TABLE `pay_periods` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `period_name` VARCHAR(80) NOT NULL,
  `start_date` DATE NOT NULL,
  `end_date` DATE NOT NULL,
  `pay_date` DATE NOT NULL,
  `status` ENUM('open','processing','closed') NOT NULL DEFAULT 'open',
  `created_by` INT UNSIGNED DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_period_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE: payroll_records
-- ============================================================
CREATE TABLE `payroll_records` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NOT NULL,
  `pay_period_id` INT UNSIGNED NOT NULL,
  `base_salary` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `hours_worked` DECIMAL(6,2) NOT NULL DEFAULT 0.00,
  `overtime_hours` DECIMAL(6,2) NOT NULL DEFAULT 0.00,
  `overtime_pay` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `housing_allowance` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `transport_allowance` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `meal_allowance` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `medical_allowance` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `performance_bonus` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `other_bonus` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `gross_pay` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `federal_tax` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `state_tax` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `social_security` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `medicare` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `health_insurance` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `retirement_401k` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `other_deductions` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `total_deductions` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `net_pay` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `status` ENUM('draft','approved','paid') NOT NULL DEFAULT 'draft',
  `notes` TEXT DEFAULT NULL,
  `processed_by` INT UNSIGNED DEFAULT NULL,
  `processed_at` TIMESTAMP NULL DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_payroll_user_period` (`user_id`,`pay_period_id`),
  KEY `idx_payroll_period` (`pay_period_id`),
  KEY `idx_payroll_status` (`status`),
  CONSTRAINT `fk_payroll_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_payroll_period` FOREIGN KEY (`pay_period_id`) REFERENCES `pay_periods` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE: deductions
-- ============================================================
CREATE TABLE `deductions` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `type` ENUM('fixed','percentage') NOT NULL DEFAULT 'fixed',
  `is_recurring` TINYINT(1) NOT NULL DEFAULT 1,
  `effective_from` DATE NOT NULL,
  `effective_to` DATE DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_deduction_user` (`user_id`),
  CONSTRAINT `fk_deduction_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE: leave_requests
-- ============================================================
CREATE TABLE `leave_requests` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NOT NULL,
  `leave_type` ENUM('annual','sick','personal','maternity','paternity','unpaid') NOT NULL DEFAULT 'annual',
  `start_date` DATE NOT NULL,
  `end_date` DATE NOT NULL,
  `days_requested` INT NOT NULL DEFAULT 1,
  `reason` TEXT DEFAULT NULL,
  `status` ENUM('pending','approved','rejected','cancelled') NOT NULL DEFAULT 'pending',
  `reviewed_by` INT UNSIGNED DEFAULT NULL,
  `reviewed_at` TIMESTAMP NULL DEFAULT NULL,
  `review_comment` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_leave_user` (`user_id`),
  KEY `idx_leave_status` (`status`),
  CONSTRAINT `fk_leave_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE: leave_balances
-- ============================================================
CREATE TABLE `leave_balances` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NOT NULL,
  `year` YEAR NOT NULL,
  `annual_total` INT NOT NULL DEFAULT 21,
  `annual_used` INT NOT NULL DEFAULT 0,
  `sick_total` INT NOT NULL DEFAULT 10,
  `sick_used` INT NOT NULL DEFAULT 0,
  `personal_total` INT NOT NULL DEFAULT 5,
  `personal_used` INT NOT NULL DEFAULT 0,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_balance_user_year` (`user_id`,`year`),
  CONSTRAINT `fk_balance_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE: audit_log
-- ============================================================
CREATE TABLE `audit_log` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED DEFAULT NULL,
  `action` VARCHAR(100) NOT NULL,
  `table_name` VARCHAR(60) DEFAULT NULL,
  `record_id` INT UNSIGNED DEFAULT NULL,
  `old_values` TEXT DEFAULT NULL,
  `new_values` TEXT DEFAULT NULL,
  `ip_address` VARCHAR(45) DEFAULT NULL,
  `user_agent` VARCHAR(255) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_audit_user` (`user_id`),
  KEY `idx_audit_action` (`action`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE: announcements
-- ============================================================
CREATE TABLE `announcements` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(200) NOT NULL,
  `content` TEXT NOT NULL,
  `type` ENUM('info','warning','success','danger') NOT NULL DEFAULT 'info',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_by` INT UNSIGNED DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- INSERT DUMMY DATA
-- ============================================================

INSERT INTO `departments` (`name`,`code`,`budget`) VALUES
('Executive Leadership','EXEC',5000000.00),
('Engineering & Technology','ENG',8500000.00),
('Human Resources','HR',2000000.00),
('Finance & Accounting','FIN',3000000.00),
('Sales & Marketing','MKT',4500000.00),
('Operations','OPS',3500000.00),
('Customer Success','CS',2500000.00),
('Legal & Compliance','LGL',1800000.00);

-- Password for ALL accounts: Password@123
INSERT INTO `users` (`employee_id`,`first_name`,`last_name`,`email`,`password_hash`,`role`,`department_id`,`job_title`,`hire_date`,`employment_type`,`status`,`phone`,`bank_name`,`bank_account`,`tax_id`) VALUES
('EMP-0001','Alex','Morgan','admin@payroll.com','$2y$10$DNtZLaRRSi560TinPpp0o.ItFogm6mC4psg2etdZFHL6CdBg4sY6u','admin',1,'Chief Executive Officer','2018-01-15','full_time','active','+1-555-0101','Chase Bank','****4521','TAX-A001'),
('EMP-0002','Sarah','Chen','sarah.chen@payroll.com','$2y$10$DNtZLaRRSi560TinPpp0o.ItFogm6mC4psg2etdZFHL6CdBg4sY6u','admin',3,'VP Human Resources','2019-03-10','full_time','active','+1-555-0102','Bank of America','****7832','TAX-A002'),
('EMP-0003','Marcus','Thompson','marcus.t@payroll.com','$2y$10$DNtZLaRRSi560TinPpp0o.ItFogm6mC4psg2etdZFHL6CdBg4sY6u','employee',2,'Senior Software Engineer','2020-06-01','full_time','active','+1-555-0103','Wells Fargo','****3341','TAX-E001'),
('EMP-0004','Priya','Patel','priya.patel@payroll.com','$2y$10$DNtZLaRRSi560TinPpp0o.ItFogm6mC4psg2etdZFHL6CdBg4sY6u','employee',2,'Lead Frontend Developer','2020-09-15','full_time','active','+1-555-0104','Citibank','****9920','TAX-E002'),
('EMP-0005','James','Wright','james.wright@payroll.com','$2y$10$DNtZLaRRSi560TinPpp0o.ItFogm6mC4psg2etdZFHL6CdBg4sY6u','employee',4,'Senior Financial Analyst','2019-11-20','full_time','active','+1-555-0105','Chase Bank','****1127','TAX-E003'),
('EMP-0006','Elena','Rodriguez','elena.r@payroll.com','$2y$10$DNtZLaRRSi560TinPpp0o.ItFogm6mC4psg2etdZFHL6CdBg4sY6u','employee',5,'Marketing Director','2021-02-08','full_time','active','+1-555-0106','US Bank','****6634','TAX-E004'),
('EMP-0007','David','Kim','david.kim@payroll.com','$2y$10$DNtZLaRRSi560TinPpp0o.ItFogm6mC4psg2etdZFHL6CdBg4sY6u','employee',6,'Operations Manager','2018-07-22','full_time','active','+1-555-0107','TD Bank','****8821','TAX-E005'),
('EMP-0008','Amara','Osei','amara.osei@payroll.com','$2y$10$DNtZLaRRSi560TinPpp0o.ItFogm6mC4psg2etdZFHL6CdBg4sY6u','employee',7,'Customer Success Lead','2022-01-10','full_time','active','+1-555-0108','Wells Fargo','****2245','TAX-E006'),
('EMP-0009','Lucas','Ferreira','lucas.f@payroll.com','$2y$10$DNtZLaRRSi560TinPpp0o.ItFogm6mC4psg2etdZFHL6CdBg4sY6u','employee',2,'DevOps Engineer','2021-08-30','full_time','active','+1-555-0109','Regions Bank','****5567','TAX-E007'),
('EMP-0010','Mei','Zhang','mei.zhang@payroll.com','$2y$10$DNtZLaRRSi560TinPpp0o.ItFogm6mC4psg2etdZFHL6CdBg4sY6u','employee',8,'Corporate Counsel','2020-04-14','full_time','active','+1-555-0110','Chase Bank','****3391','TAX-E008'),
('EMP-0011','Tyler','Brooks','tyler.b@payroll.com','$2y$10$DNtZLaRRSi560TinPpp0o.ItFogm6mC4psg2etdZFHL6CdBg4sY6u','employee',5,'Sales Executive','2022-05-16','full_time','active','+1-555-0111','PNC Bank','****7713','TAX-E009'),
('EMP-0012','Fatima','Al-Hassan','fatima.ah@payroll.com','$2y$10$DNtZLaRRSi560TinPpp0o.ItFogm6mC4psg2etdZFHL6CdBg4sY6u','employee',3,'HR Specialist','2023-01-03','full_time','active','+1-555-0112','Bank of America','****4488','TAX-E010');

UPDATE `departments` SET `manager_id` = 1 WHERE `id` = 1;
UPDATE `departments` SET `manager_id` = 2 WHERE `id` = 3;
UPDATE `departments` SET `manager_id` = 3 WHERE `id` = 2;

INSERT INTO `salary_structures` (`user_id`,`base_salary`,`hourly_rate`,`overtime_multiplier`,`housing_allowance`,`transport_allowance`,`meal_allowance`,`medical_allowance`,`effective_date`) VALUES
(1,280000.00,134.62,1.50,3500.00,800.00,500.00,1200.00,'2024-01-01'),
(2,175000.00,84.13,1.50,2500.00,600.00,400.00,1000.00,'2024-01-01'),
(3,145000.00,69.71,1.50,2000.00,500.00,350.00,800.00,'2024-01-01'),
(4,138000.00,66.35,1.50,2000.00,500.00,350.00,800.00,'2024-01-01'),
(5,125000.00,60.10,1.50,1800.00,450.00,300.00,700.00,'2024-01-01'),
(6,155000.00,74.52,1.50,2200.00,550.00,400.00,900.00,'2024-01-01'),
(7,118000.00,56.73,1.50,1700.00,450.00,300.00,700.00,'2024-01-01'),
(8,95000.00,45.67,1.50,1500.00,400.00,250.00,600.00,'2024-01-01'),
(9,132000.00,63.46,1.50,1900.00,480.00,320.00,750.00,'2024-01-01'),
(10,148000.00,71.15,1.50,2100.00,520.00,370.00,850.00,'2024-01-01'),
(11,85000.00,40.87,1.50,1300.00,350.00,220.00,550.00,'2024-01-01'),
(12,78000.00,37.50,1.50,1200.00,320.00,200.00,500.00,'2024-01-01');

INSERT INTO `pay_periods` (`period_name`,`start_date`,`end_date`,`pay_date`,`status`,`created_by`) VALUES
('January 2025','2025-01-01','2025-01-31','2025-02-05','closed',1),
('February 2025','2025-02-01','2025-02-28','2025-03-05','closed',1),
('March 2025','2025-03-01','2025-03-31','2025-04-05','closed',1),
('April 2025','2025-04-01','2025-04-30','2025-05-05','closed',1),
('May 2025','2025-05-01','2025-05-31','2025-06-05','closed',1),
('June 2025','2025-06-01','2025-06-30','2025-07-05','closed',1),
('April 2026','2026-04-01','2026-04-30','2026-05-05','open',1);

INSERT INTO `payroll_records`
(`user_id`,`pay_period_id`,`base_salary`,`hours_worked`,`overtime_hours`,`overtime_pay`,`housing_allowance`,`transport_allowance`,`meal_allowance`,`medical_allowance`,`performance_bonus`,`other_bonus`,`gross_pay`,`federal_tax`,`state_tax`,`social_security`,`medicare`,`health_insurance`,`retirement_401k`,`other_deductions`,`total_deductions`,`net_pay`,`status`,`processed_by`,`processed_at`) VALUES
(3,1,12083.33,176.00,8.00,836.54,2000.00,500.00,350.00,800.00,0.00,0.00,16569.87,3809.07,829.49,1027.33,240.26,450.00,484.00,250.00,7090.15,9479.72,'paid',1,'2025-02-04 10:00:00'),
(4,1,11500.00,176.00,0.00,0.00,2000.00,500.00,350.00,800.00,500.00,0.00,15650.00,3578.50,786.80,970.30,226.93,450.00,460.00,75.00,6547.53,9102.47,'paid',1,'2025-02-04 10:00:00'),
(5,1,10416.67,176.00,4.00,300.50,1800.00,450.00,300.00,700.00,0.00,0.00,13967.17,3078.78,672.19,866.36,202.52,380.00,416.67,120.00,5736.52,8230.65,'paid',1,'2025-02-04 10:00:00'),
(3,2,12083.33,160.00,0.00,0.00,2000.00,500.00,350.00,800.00,1500.00,0.00,17233.33,3963.67,863.22,1068.47,249.88,450.00,484.00,250.00,7329.24,9904.09,'paid',1,'2025-03-04 10:00:00'),
(4,2,11500.00,160.00,0.00,0.00,2000.00,500.00,350.00,800.00,0.00,0.00,15150.00,3459.50,759.35,939.30,219.68,450.00,460.00,75.00,6362.83,8787.17,'paid',1,'2025-03-04 10:00:00'),
(3,3,12083.33,184.00,16.00,1673.08,2000.00,500.00,350.00,800.00,2000.00,500.00,19906.41,4578.47,1001.12,1234.20,288.64,450.00,484.00,250.00,8286.43,11619.98,'paid',1,'2025-04-04 10:00:00'),
(4,3,11500.00,176.00,5.00,412.19,2000.00,500.00,350.00,800.00,1000.00,0.00,16562.19,3809.30,831.23,1026.86,240.15,450.00,460.00,75.00,6892.54,9669.65,'paid',1,'2025-04-04 10:00:00'),
(3,4,12083.33,176.00,0.00,0.00,2000.00,500.00,350.00,800.00,0.00,0.00,15733.33,3618.67,790.23,975.47,228.13,450.00,484.00,250.00,6796.50,8936.83,'paid',1,'2025-05-04 10:00:00'),
(3,5,12083.33,176.00,10.00,1046.15,2000.00,500.00,350.00,800.00,3000.00,0.00,19779.48,4549.28,994.75,1226.33,286.80,450.00,484.00,250.00,8241.16,11538.32,'paid',1,'2025-06-04 10:00:00'),
(4,5,11500.00,176.00,0.00,0.00,2000.00,500.00,350.00,800.00,1500.00,0.00,16650.00,3829.50,836.63,1032.30,241.43,450.00,460.00,75.00,6924.86,9725.14,'paid',1,'2025-06-04 10:00:00'),
(3,6,12083.33,176.00,0.00,0.00,2000.00,500.00,350.00,800.00,0.00,1000.00,16733.33,3848.67,840.23,1037.47,242.63,450.00,484.00,250.00,7152.00,9581.33,'paid',1,'2025-07-04 10:00:00'),
(4,6,11500.00,176.00,0.00,0.00,2000.00,500.00,350.00,800.00,2000.00,0.00,17150.00,3944.50,860.93,1063.30,248.68,450.00,460.00,75.00,7102.41,10047.59,'paid',1,'2025-07-04 10:00:00'),
(5,6,10416.67,176.00,0.00,0.00,1800.00,450.00,300.00,700.00,0.00,0.00,13666.67,2989.67,647.78,847.33,198.17,380.00,416.67,120.00,5599.62,8067.05,'paid',1,'2025-07-04 10:00:00');

INSERT INTO `deductions` (`user_id`,`name`,`amount`,`type`,`is_recurring`,`effective_from`) VALUES
(3,'Employee Loan Repayment',250.00,'fixed',1,'2024-06-01'),
(4,'Gym Membership',75.00,'fixed',1,'2024-01-01'),
(5,'Parking Permit',120.00,'fixed',1,'2024-01-01'),
(6,'Professional Development',200.00,'fixed',1,'2024-03-01'),
(9,'Laptop Installment',150.00,'fixed',1,'2024-09-01');

INSERT INTO `leave_balances` (`user_id`,`year`,`annual_total`,`annual_used`,`sick_total`,`sick_used`,`personal_total`,`personal_used`) VALUES
(3,2025,21,8,10,2,5,1),(4,2025,21,5,10,0,5,2),(5,2025,21,3,10,4,5,0),
(6,2025,21,12,10,1,5,3),(7,2025,21,6,10,3,5,1),(8,2025,21,2,10,0,5,0),
(9,2025,21,10,10,5,5,2),(10,2025,21,4,10,1,5,0),(11,2025,21,1,10,0,5,1),
(12,2025,21,0,10,0,5,0),(3,2026,21,3,10,1,5,0),(4,2026,21,2,10,0,5,1),
(5,2026,21,1,10,2,5,0),(6,2026,21,0,10,0,5,0),(7,2026,21,2,10,1,5,0),
(8,2026,21,0,10,0,5,0),(9,2026,21,4,10,2,5,1),(10,2026,21,1,10,0,5,0),
(11,2026,21,0,10,0,5,0),(12,2026,21,0,10,0,5,0);

INSERT INTO `leave_requests` (`user_id`,`leave_type`,`start_date`,`end_date`,`days_requested`,`reason`,`status`,`reviewed_by`,`reviewed_at`) VALUES
(3,'annual','2025-07-14','2025-07-25',10,'Summer family vacation','approved',2,'2025-07-01 09:00:00'),
(4,'sick','2025-09-05','2025-09-06',2,'Medical appointment','approved',2,'2025-09-04 14:00:00'),
(5,'personal','2025-11-28','2025-11-28',1,'Thanksgiving travel','approved',2,'2025-11-20 10:00:00'),
(6,'annual','2025-12-20','2025-12-31',10,'End of year leave','approved',2,'2025-12-10 11:00:00'),
(8,'annual','2026-03-10','2026-03-14',5,'Spring break','pending',NULL,NULL),
(9,'sick','2026-04-02','2026-04-03',2,'Illness','approved',2,'2026-04-01 08:30:00'),
(11,'personal','2026-04-18','2026-04-18',1,'Personal matter','pending',NULL,NULL);

INSERT INTO `announcements` (`title`,`content`,`type`,`is_active`,`created_by`) VALUES
('Q2 2026 Payroll Processing Schedule','The April 2026 payroll will be processed on May 5th. Please ensure all timesheets are submitted by April 28th.','info',1,1),
('Annual Performance Reviews - April 2026','Annual performance reviews are now open. Managers must complete all reviews by April 30th. Bonuses will be reflected in the May payroll.','success',1,2),
('System Maintenance - April 12, 2026','The payroll system will be unavailable for scheduled maintenance on April 12th from 2:00 AM to 5:00 AM EST.','warning',1,1),
('New Health Insurance Open Enrollment','Open enrollment for health insurance plans begins April 15th. Review your options in the Employee Self-Service portal.','info',1,2);

INSERT INTO `audit_log` (`user_id`,`action`,`table_name`,`record_id`,`ip_address`) VALUES
(1,'LOGIN','users',1,'127.0.0.1'),
(1,'CREATE_PAY_PERIOD','pay_periods',7,'127.0.0.1'),
(2,'APPROVE_LEAVE','leave_requests',6,'127.0.0.1');
