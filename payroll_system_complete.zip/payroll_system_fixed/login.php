<?php
require_once 'config.php';

// Redirect if already logged in
if (isLoggedIn()) {
    header('Location: ' . ($_SESSION['role'] === 'admin' ? 'admin_dashboard.php' : 'employee_dashboard.php'));
    exit();
}

$error = '';
$email_val = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validateCSRF();
    
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $email_val = sanitize($email);

    if (empty($email) || empty($password)) {
        $error = 'Please enter both email and password.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        try {
            $pdo  = getPDO();
            $stmt = $pdo->prepare("SELECT u.*, d.name AS department_name 
                FROM users u 
                LEFT JOIN departments d ON u.department_id = d.id
                WHERE u.email = ? AND u.status = 'active' LIMIT 1");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password_hash'])) {
                // Regenerate session to prevent fixation
                session_regenerate_id(true);

                $_SESSION['user_id']   = $user['id'];
                $_SESSION['role']      = $user['role'];
                $_SESSION['user']      = [
                    'id'          => $user['id'],
                    'employee_id' => $user['employee_id'],
                    'first_name'  => $user['first_name'],
                    'last_name'   => $user['last_name'],
                    'email'       => $user['email'],
                    'role'        => $user['role'],
                    'job_title'   => $user['job_title'],
                    'department'  => $user['department_name'],
                    'dept_id'     => $user['department_id'],
                ];
                $_SESSION['login_time'] = time();

                auditLog('LOGIN', 'users', (int)$user['id']);

                header('Location: ' . ($user['role'] === 'admin' ? 'admin_dashboard.php' : 'employee_dashboard.php'));
                exit();
            } else {
                $error = 'Invalid email or password. Please try again.';
                auditLog('FAILED_LOGIN', 'users', 0, [], ['email' => $email]);
            }
        } catch (PDOException $e) {
            $error = 'A system error occurred. Please try again later.';
        }
    }
}

$csrf = generateCSRF();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In — <?= APP_NAME ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body class="auth-body">

<!-- Animated background orbs -->
<div class="bg-orbs">
    <div class="orb orb-1"></div>
    <div class="orb orb-2"></div>
    <div class="orb orb-3"></div>
</div>

<div class="auth-wrapper">
    <!-- Left Panel: Branding -->
    <div class="auth-left d-none d-lg-flex">
        <div class="auth-left-inner">
            <div class="brand-logo mb-4">
                <i class="fa-solid fa-building-columns"></i>
            </div>
            <h1 class="brand-title"><?= APP_NAME ?></h1>
            <p class="brand-sub">Enterprise-grade payroll intelligence for the modern workforce.</p>

            <div class="auth-stats mt-5">
                <div class="auth-stat">
                    <span class="stat-num">12K+</span>
                    <span class="stat-label">Employees Managed</span>
                </div>
                <div class="auth-stat">
                    <span class="stat-num">$4.2M</span>
                    <span class="stat-label">Monthly Payroll Processed</span>
                </div>
                <div class="auth-stat">
                    <span class="stat-num">8</span>
                    <span class="stat-label">Departments</span>
                </div>
            </div>

            <div class="auth-features mt-5">
                <div class="auth-feature-item">
                    <i class="fa-solid fa-shield-halved"></i>
                    <span>Bank-level security & encryption</span>
                </div>
                <div class="auth-feature-item">
                    <i class="fa-solid fa-chart-line"></i>
                    <span>Real-time analytics & reporting</span>
                </div>
                <div class="auth-feature-item">
                    <i class="fa-solid fa-bolt"></i>
                    <span>Automated tax calculations</span>
                </div>
            </div>
        </div>
    </div>

    <!-- Right Panel: Login Form -->
    <div class="auth-right">
        <div class="auth-card">
            <div class="auth-card-header">
                <div class="mobile-logo d-lg-none mb-4">
                    <i class="fa-solid fa-building-columns"></i>
                    <span><?= APP_NAME ?></span>
                </div>
                <h2 class="auth-heading">Welcome back</h2>
                <p class="auth-subheading">Sign in to your account to continue</p>
            </div>

            <?php if ($error): ?>
            <div class="alert-glass alert-glass-danger">
                <i class="fa-solid fa-circle-exclamation me-2"></i>
                <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
            </div>
            <?php endif; ?>

            <form method="POST" action="login.php" id="loginForm" novalidate>
                <input type="hidden" name="csrf_token" value="<?= $csrf ?>">

                <div class="form-group-glass mb-4">
                    <label class="form-label-glass" for="email">
                        <i class="fa-solid fa-envelope me-2"></i>Email Address
                    </label>
                    <input type="email" id="email" name="email"
                           class="form-control-glass <?= $error ? 'is-invalid' : '' ?>"
                           placeholder="you@company.com"
                           value="<?= $email_val ?>"
                           autocomplete="email" required>
                </div>

                <div class="form-group-glass mb-4">
                    <div class="d-flex justify-content-between align-items-center">
                        <label class="form-label-glass" for="password">
                            <i class="fa-solid fa-lock me-2"></i>Password
                        </label>
                    </div>
                    <div class="input-password-wrap">
                        <input type="password" id="password" name="password"
                               class="form-control-glass <?= $error ? 'is-invalid' : '' ?>"
                               placeholder="••••••••••••"
                               autocomplete="current-password" required>
                        <button type="button" class="toggle-pw" onclick="togglePw('password', this)" tabindex="-1">
                            <i class="fa-regular fa-eye"></i>
                        </button>
                    </div>
                </div>

                <button type="submit" class="btn-glass-primary w-100 mb-4" id="loginBtn">
                    <span class="btn-text">
                        <i class="fa-solid fa-arrow-right-to-bracket me-2"></i>Sign In
                    </span>
                    <span class="btn-loader d-none">
                        <i class="fa-solid fa-circle-notch fa-spin me-2"></i>Authenticating...
                    </span>
                </button>
            </form>

            <div class="auth-divider">
                <span>or</span>
            </div>

            <div class="demo-creds">
                <p class="demo-label"><i class="fa-solid fa-info-circle me-1"></i> Demo Credentials</p>
                <div class="demo-grid">
                    <button type="button" class="demo-btn" onclick="fillCreds('admin@payroll.com', 'Password@123')">
                        <i class="fa-solid fa-user-shield"></i>
                        <span>Admin Login</span>
                        <small>admin@payroll.com</small>
                    </button>
                    <button type="button" class="demo-btn" onclick="fillCreds('marcus.t@payroll.com', 'Password@123')">
                        <i class="fa-solid fa-user"></i>
                        <span>Employee Login</span>
                        <small>marcus.t@payroll.com</small>
                    </button>
                </div>
            </div>

            <p class="auth-footer-text">
                Don't have an account? 
                <a href="signup.php" class="auth-link">Request access</a>
            </p>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/js/bootstrap.bundle.min.js"></script>
<script>
function togglePw(id, btn) {
    const input = document.getElementById(id);
    const icon  = btn.querySelector('i');
    if (input.type === 'password') {
        input.type = 'text';
        icon.className = 'fa-regular fa-eye-slash';
    } else {
        input.type = 'password';
        icon.className = 'fa-regular fa-eye';
    }
}

function fillCreds(email, pw) {
    document.getElementById('email').value    = email;
    document.getElementById('password').value = pw;
    document.getElementById('email').focus();
}

document.getElementById('loginForm').addEventListener('submit', function(e) {
    const email    = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const btn      = document.getElementById('loginBtn');

    if (!email || !password) return;

    const emailRx = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRx.test(email)) { e.preventDefault(); return; }

    btn.querySelector('.btn-text').classList.add('d-none');
    btn.querySelector('.btn-loader').classList.remove('d-none');
    btn.disabled = true;
});
</script>
</body>
</html>
