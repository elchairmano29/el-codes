<?php
require_once 'config.php';
requireLogin();

if ($_SESSION['role'] === 'admin') {
    header('Location: admin_dashboard.php');
    exit();
}

$pdo      = getPDO();
$user     = currentUser();
$userId   = (int)$user['id'];

// ─── Handle AJAX Actions ──────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    validateCSRF();
    $action = $_POST['action'];

    if ($action === 'submit_leave') {
        $type      = $_POST['leave_type'] ?? 'annual';
        $startDate = $_POST['start_date'] ?? '';
        $endDate   = $_POST['end_date']   ?? '';
        $reason    = sanitize($_POST['reason'] ?? '');

        $validTypes = ['annual','sick','personal','maternity','paternity','unpaid'];
        if (!in_array($type, $validTypes)) jsonResponse(false, 'Invalid leave type.');
        if (!$startDate || !$endDate) jsonResponse(false, 'Please select start and end dates.');

        $start = new DateTime($startDate);
        $end   = new DateTime($endDate);
        if ($end < $start) jsonResponse(false, 'End date must be after start date.');

        $days = (int)$start->diff($end)->days + 1;

        // Check leave balance
        $balStmt = $pdo->prepare("SELECT * FROM leave_balances WHERE user_id=? AND year=?");
        $balStmt->execute([$userId, date('Y')]);
        $balance = $balStmt->fetch();

        if ($balance) {
            $col  = $type === 'sick' ? 'sick' : ($type === 'personal' ? 'personal' : 'annual');
            $avail = ($balance["{$col}_total"] ?? 0) - ($balance["{$col}_used"] ?? 0);
            if ($type !== 'unpaid' && $avail < $days) {
                jsonResponse(false, "Insufficient {$type} leave balance. Available: {$avail} days.");
            }
        }

        try {
            $pdo->prepare("INSERT INTO leave_requests (user_id,leave_type,start_date,end_date,days_requested,reason) VALUES (?,?,?,?,?,?)")
                ->execute([$userId,$type,$startDate,$endDate,$days,$reason]);
            auditLog('SUBMIT_LEAVE','leave_requests',(int)$pdo->lastInsertId());
            jsonResponse(true,"Leave request submitted for {$days} day(s). Pending approval.");
        } catch (PDOException $e) {
            jsonResponse(false,'Failed to submit leave request.');
        }
    }

    if ($action === 'update_profile') {
        $phone   = sanitize($_POST['phone']   ?? '');
        $address = sanitize($_POST['address'] ?? '');
        $bank    = sanitize($_POST['bank_name']    ?? '');
        $account = sanitize($_POST['bank_account'] ?? '');

        try {
            $pdo->prepare("UPDATE users SET phone=?,address=?,bank_name=?,bank_account=?,updated_at=NOW() WHERE id=?")
                ->execute([$phone,$address,$bank,$account,$userId]);
            auditLog('UPDATE_PROFILE','users',$userId);
            jsonResponse(true,'Profile updated successfully.');
        } catch (PDOException $e) {
            jsonResponse(false,'Update failed.');
        }
    }

    if ($action === 'change_password') {
        $current = $_POST['current_password'] ?? '';
        $new     = $_POST['new_password']     ?? '';
        $confirm = $_POST['confirm_password'] ?? '';

        if (strlen($new) < 8 || !preg_match('/[A-Z]/',$new) || !preg_match('/[0-9]/',$new)) {
            jsonResponse(false,'New password must be 8+ chars with 1 uppercase and 1 number.');
        }
        if ($new !== $confirm) jsonResponse(false,'Passwords do not match.');

        $stmt = $pdo->prepare("SELECT password_hash FROM users WHERE id=?");
        $stmt->execute([$userId]);
        $row = $stmt->fetch();
        if (!$row || !password_verify($current, $row['password_hash'])) {
            jsonResponse(false,'Current password is incorrect.');
        }

        $hash = password_hash($new, PASSWORD_BCRYPT, ['cost'=>12]);
        $pdo->prepare("UPDATE users SET password_hash=? WHERE id=?")->execute([$hash,$userId]);
        auditLog('CHANGE_PASSWORD','users',$userId);
        jsonResponse(true,'Password changed successfully.');
    }
}

// ─── Fetch Employee Data ──────────────────────────────────────────────────────
$empData = $pdo->prepare("SELECT u.*, d.name as dept_name, d.code as dept_code
    FROM users u LEFT JOIN departments d ON u.department_id=d.id WHERE u.id=?");
$empData->execute([$userId]);
$emp = $empData->fetch();

// Latest salary structure
$salary = $pdo->prepare("SELECT * FROM salary_structures WHERE user_id=? ORDER BY effective_date DESC LIMIT 1");
$salary->execute([$userId]);
$sal = $salary->fetch();

// All payroll records
$payRecords = $pdo->prepare("SELECT pr.*, pp.period_name, pp.pay_date
    FROM payroll_records pr
    JOIN pay_periods pp ON pr.pay_period_id=pp.id
    WHERE pr.user_id=? ORDER BY pp.pay_date DESC LIMIT 12");
$payRecords->execute([$userId]);
$payHistory = $payRecords->fetchAll();

// Latest payslip
$latestPay = $payHistory[0] ?? null;

// Leave balance current year
$leaveBal = $pdo->prepare("SELECT * FROM leave_balances WHERE user_id=? AND year=?");
$leaveBal->execute([$userId, date('Y')]);
$balance = $leaveBal->fetch();

// Leave history
$leaveHist = $pdo->prepare("SELECT * FROM leave_requests WHERE user_id=? ORDER BY created_at DESC LIMIT 10");
$leaveHist->execute([$userId]);
$leaveHistory = $leaveHist->fetchAll();

// Announcements
$announcements = $pdo->query("SELECT * FROM announcements WHERE is_active=1 ORDER BY created_at DESC LIMIT 3")->fetchAll();

// Chart data: last 6 months net pay
$sixMonths = $pdo->prepare("SELECT pp.period_name, pr.gross_pay, pr.net_pay, pr.total_deductions, pr.federal_tax, pr.state_tax
    FROM payroll_records pr JOIN pay_periods pp ON pr.pay_period_id=pp.id
    WHERE pr.user_id=? AND pp.status='closed' ORDER BY pp.pay_date DESC LIMIT 6");
$sixMonths->execute([$userId]);
$payTrend = array_reverse($sixMonths->fetchAll());

$trendLabels = array_column($payTrend,'period_name');
$trendNet    = array_map(fn($r)=>(float)$r['net_pay'], $payTrend);
$trendGross  = array_map(fn($r)=>(float)$r['gross_pay'], $payTrend);

// Compensation breakdown for latest payslip
$compBreakdown = [];
$compLabels    = [];
if ($latestPay) {
    $compLabels = ['Base Salary','Allowances','Overtime/Bonus'];
    $allowances = (float)$latestPay['housing_allowance']+(float)$latestPay['transport_allowance']
                +(float)$latestPay['meal_allowance']+(float)$latestPay['medical_allowance'];
    $bonuses    = (float)$latestPay['overtime_pay']+(float)$latestPay['performance_bonus']+(float)$latestPay['other_bonus'];
    $compBreakdown = [(float)$latestPay['base_salary'], $allowances, $bonuses];
}

$csrf = generateCSRF();
$leaveAnnualLeft  = ($balance['annual_total']  ?? 21) - ($balance['annual_used']  ?? 0);
$leaveSickLeft    = ($balance['sick_total']    ?? 10) - ($balance['sick_used']    ?? 0);
$leavePersonalLeft= ($balance['personal_total'] ?? 5) - ($balance['personal_used'] ?? 0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Portal — <?= APP_NAME ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body class="dashboard-body">

<!-- Sidebar -->
<div class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="sidebar-brand">
            <i class="fa-solid fa-building-columns"></i>
            <span><?= APP_NAME ?></span>
        </div>
        <button class="sidebar-close d-xl-none" onclick="toggleSidebar()">
            <i class="fa-solid fa-xmark"></i>
        </button>
    </div>

    <div class="sidebar-user">
        <div class="sidebar-avatar">
            <?= strtoupper(substr($user['first_name'],0,1).substr($user['last_name'],0,1)) ?>
        </div>
        <div>
            <div class="sidebar-user-name"><?= htmlspecialchars($user['first_name'].' '.$user['last_name']) ?></div>
            <div class="sidebar-user-role"><span class="badge-employee">Employee</span></div>
        </div>
    </div>

    <nav class="sidebar-nav">
        <div class="sidebar-section-label">My Dashboard</div>
        <a href="#" class="sidebar-link active" data-tab="overview">
            <i class="fa-solid fa-house-chimney"></i><span>Overview</span>
        </a>
        <a href="#" class="sidebar-link" data-tab="payslips">
            <i class="fa-solid fa-file-invoice-dollar"></i><span>My Payslips</span>
        </a>

        <div class="sidebar-section-label">Time Off</div>
        <a href="#" class="sidebar-link" data-tab="leave">
            <i class="fa-solid fa-umbrella-beach"></i><span>Leave & PTO</span>
            <?php if (array_sum(array_map(fn($l)=>$l['status']==='pending'?1:0,$leaveHistory)) > 0): ?>
            <span class="sidebar-badge sidebar-badge-warning">!</span>
            <?php endif; ?>
        </a>

        <div class="sidebar-section-label">Account</div>
        <a href="#" class="sidebar-link" data-tab="profile">
            <i class="fa-solid fa-user-gear"></i><span>My Profile</span>
        </a>
        <a href="#" class="sidebar-link" data-tab="security">
            <i class="fa-solid fa-shield-halved"></i><span>Security</span>
        </a>

        <div class="sidebar-footer">
            <a href="logout.php" class="sidebar-link sidebar-logout">
                <i class="fa-solid fa-right-from-bracket"></i><span>Sign Out</span>
            </a>
        </div>
    </nav>
</div>

<!-- Main -->
<div class="main-wrapper" id="mainWrapper">
    <div class="topbar">
        <button class="topbar-toggle" onclick="toggleSidebar()">
            <i class="fa-solid fa-bars"></i>
        </button>
        <div class="topbar-breadcrumb" id="breadcrumb-text">Overview</div>
        <div class="topbar-actions">
            <div class="topbar-date">
                <i class="fa-regular fa-calendar me-1"></i><?= date('F j, Y') ?>
            </div>
            <code class="emp-id-chip"><?= htmlspecialchars($emp['employee_id']) ?></code>
        </div>
    </div>

    <div class="main-content">

        <!-- ════════════ TAB: OVERVIEW ════════════ -->
        <div class="tab-content-panel active" id="tab-overview">
            <!-- Welcome Banner -->
            <div class="welcome-banner mb-4">
                <div class="welcome-text">
                    <h2>Good <?= date('H') < 12 ? 'morning' : (date('H') < 17 ? 'afternoon' : 'evening') ?>, <?= htmlspecialchars($emp['first_name']) ?> 👋</h2>
                    <p><?= htmlspecialchars($emp['job_title'] ?? 'Employee') ?> · <?= htmlspecialchars($emp['dept_name'] ?? 'Unassigned') ?> · Joined <?= $emp['hire_date'] ? date('F Y', strtotime($emp['hire_date'])) : '—' ?></p>
                </div>
                <?php foreach (array_slice($announcements,0,1) as $ann): ?>
                <div class="welcome-alert welcome-alert-<?= $ann['type'] ?>">
                    <i class="fa-solid fa-bell me-1"></i>
                    <?= htmlspecialchars($ann['title']) ?>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- Quick Stats -->
            <div class="row g-3 mb-4">
                <div class="col-xl-3 col-md-6">
                    <div class="kpi-card kpi-blue">
                        <div class="kpi-icon"><i class="fa-solid fa-wallet"></i></div>
                        <div class="kpi-value"><?= $latestPay ? money((float)$latestPay['net_pay']) : '—' ?></div>
                        <div class="kpi-label">Last Net Pay</div>
                        <div class="kpi-sub"><?= $latestPay ? htmlspecialchars($latestPay['period_name']) : 'No records' ?></div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="kpi-card kpi-emerald">
                        <div class="kpi-icon"><i class="fa-solid fa-umbrella-beach"></i></div>
                        <div class="kpi-value"><?= $leaveAnnualLeft ?></div>
                        <div class="kpi-label">Annual Leave Remaining</div>
                        <div class="kpi-sub"><?= $balance['annual_used'] ?? 0 ?> used of <?= $balance['annual_total'] ?? 21 ?></div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="kpi-card kpi-amber">
                        <div class="kpi-icon"><i class="fa-solid fa-briefcase-medical"></i></div>
                        <div class="kpi-value"><?= $leaveSickLeft ?></div>
                        <div class="kpi-label">Sick Days Remaining</div>
                        <div class="kpi-sub"><?= $balance['sick_used'] ?? 0 ?> used of <?= $balance['sick_total'] ?? 10 ?></div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="kpi-card kpi-violet">
                        <div class="kpi-icon"><i class="fa-solid fa-dollar-sign"></i></div>
                        <div class="kpi-value"><?= $sal ? money((float)$sal['base_salary']) : '—' ?></div>
                        <div class="kpi-label">Annual Base Salary</div>
                        <div class="kpi-sub"><?= $sal ? money(round($sal['base_salary']/12, 2)).'/month' : '' ?></div>
                    </div>
                </div>
            </div>

            <!-- Charts -->
            <div class="row g-4 mb-4">
                <div class="col-xl-8">
                    <div class="dash-card">
                        <div class="dash-card-header">
                            <h3 class="dash-card-title"><i class="fa-solid fa-chart-line me-2"></i>My Pay History</h3>
                        </div>
                        <div class="chart-wrap" style="height:260px">
                            <canvas id="myPayChart"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4">
                    <div class="dash-card">
                        <div class="dash-card-header">
                            <h3 class="dash-card-title"><i class="fa-solid fa-chart-pie me-2"></i>Compensation Mix</h3>
                        </div>
                        <div class="chart-wrap" style="height:260px">
                            <canvas id="compMixChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Latest Payslip Preview -->
            <?php if ($latestPay): ?>
            <div class="dash-card mb-4">
                <div class="dash-card-header">
                    <h3 class="dash-card-title"><i class="fa-solid fa-file-invoice me-2"></i>Latest Payslip Preview</h3>
                    <button class="btn-dash-sm" onclick="showTab('payslips')">View All →</button>
                </div>
                <div class="payslip-preview">
                    <div class="payslip-header-row">
                        <div>
                            <div class="payslip-company"><?= APP_NAME ?></div>
                            <div class="payslip-period"><?= htmlspecialchars($latestPay['period_name']) ?></div>
                        </div>
                        <div class="payslip-net-badge"><?= money((float)$latestPay['net_pay']) ?></div>
                    </div>
                    <div class="payslip-grid">
                        <div class="payslip-col">
                            <div class="payslip-section-title">Earnings</div>
                            <div class="payslip-row"><span>Base Salary</span><span><?= money((float)$latestPay['base_salary']) ?></span></div>
                            <div class="payslip-row"><span>Overtime Pay</span><span><?= money((float)$latestPay['overtime_pay']) ?></span></div>
                            <div class="payslip-row"><span>Housing Allowance</span><span><?= money((float)$latestPay['housing_allowance']) ?></span></div>
                            <div class="payslip-row"><span>Transport Allowance</span><span><?= money((float)$latestPay['transport_allowance']) ?></span></div>
                            <div class="payslip-row"><span>Meal Allowance</span><span><?= money((float)$latestPay['meal_allowance']) ?></span></div>
                            <div class="payslip-row"><span>Medical Allowance</span><span><?= money((float)$latestPay['medical_allowance']) ?></span></div>
                            <div class="payslip-row"><span>Performance Bonus</span><span><?= money((float)$latestPay['performance_bonus']) ?></span></div>
                            <div class="payslip-row payslip-total"><span>Gross Pay</span><span><?= money((float)$latestPay['gross_pay']) ?></span></div>
                        </div>
                        <div class="payslip-col">
                            <div class="payslip-section-title">Deductions</div>
                            <div class="payslip-row deduction"><span>Federal Tax</span><span>-<?= money((float)$latestPay['federal_tax']) ?></span></div>
                            <div class="payslip-row deduction"><span>State Tax</span><span>-<?= money((float)$latestPay['state_tax']) ?></span></div>
                            <div class="payslip-row deduction"><span>Social Security</span><span>-<?= money((float)$latestPay['social_security']) ?></span></div>
                            <div class="payslip-row deduction"><span>Medicare</span><span>-<?= money((float)$latestPay['medicare']) ?></span></div>
                            <div class="payslip-row deduction"><span>Health Insurance</span><span>-<?= money((float)$latestPay['health_insurance']) ?></span></div>
                            <div class="payslip-row deduction"><span>401(k) Retirement</span><span>-<?= money((float)$latestPay['retirement_401k']) ?></span></div>
                            <div class="payslip-row deduction"><span>Other</span><span>-<?= money((float)$latestPay['other_deductions']) ?></span></div>
                            <div class="payslip-row payslip-total deduction"><span>Total Deductions</span><span>-<?= money((float)$latestPay['total_deductions']) ?></span></div>
                        </div>
                    </div>
                    <div class="payslip-net-row">
                        <span>NET PAY</span>
                        <span class="net-amount"><?= money((float)$latestPay['net_pay']) ?></span>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- ════════════ TAB: PAYSLIPS ════════════ -->
        <div class="tab-content-panel" id="tab-payslips">
            <div class="dash-card">
                <div class="dash-card-header">
                    <h3 class="dash-card-title"><i class="fa-solid fa-file-invoice-dollar me-2"></i>My Payslip History</h3>
                </div>
                <?php if (empty($payHistory)): ?>
                <div class="empty-state">
                    <i class="fa-solid fa-file-circle-xmark"></i>
                    <p>No payroll records found yet. Check back after payroll is processed.</p>
                </div>
                <?php else: ?>
                <!-- Payslip accordion -->
                <div class="payslip-accordion">
                    <?php foreach ($payHistory as $idx => $pay): ?>
                    <div class="payslip-item">
                        <div class="payslip-item-header" onclick="togglePayslip(<?= $idx ?>)">
                            <div class="payslip-item-left">
                                <div class="payslip-period-badge"><?= htmlspecialchars($pay['period_name']) ?></div>
                                <span class="badge-status badge-<?= $pay['status'] ?>"><?= ucfirst($pay['status']) ?></span>
                            </div>
                            <div class="payslip-item-right">
                                <span class="payslip-gross">Gross: <?= money((float)$pay['gross_pay']) ?></span>
                                <span class="payslip-net-chip">Net: <?= money((float)$pay['net_pay']) ?></span>
                                <i class="fa-solid fa-chevron-down payslip-chevron" id="chevron-<?= $idx ?>"></i>
                            </div>
                        </div>
                        <div class="payslip-item-body" id="payslip-body-<?= $idx ?>" style="display:none">
                            <div class="payslip-grid">
                                <div class="payslip-col">
                                    <div class="payslip-section-title">Earnings</div>
                                    <div class="payslip-row"><span>Base Salary</span><span><?= money((float)$pay['base_salary']) ?></span></div>
                                    <div class="payslip-row"><span>Overtime (<?= $pay['overtime_hours'] ?>h)</span><span><?= money((float)$pay['overtime_pay']) ?></span></div>
                                    <div class="payslip-row"><span>Housing Allowance</span><span><?= money((float)$pay['housing_allowance']) ?></span></div>
                                    <div class="payslip-row"><span>Transport Allowance</span><span><?= money((float)$pay['transport_allowance']) ?></span></div>
                                    <div class="payslip-row"><span>Meal Allowance</span><span><?= money((float)$pay['meal_allowance']) ?></span></div>
                                    <div class="payslip-row"><span>Medical Allowance</span><span><?= money((float)$pay['medical_allowance']) ?></span></div>
                                    <div class="payslip-row"><span>Performance Bonus</span><span><?= money((float)$pay['performance_bonus']) ?></span></div>
                                    <div class="payslip-row"><span>Other Bonus</span><span><?= money((float)$pay['other_bonus']) ?></span></div>
                                    <div class="payslip-row payslip-total"><span>Gross Pay</span><span><?= money((float)$pay['gross_pay']) ?></span></div>
                                </div>
                                <div class="payslip-col">
                                    <div class="payslip-section-title">Deductions</div>
                                    <div class="payslip-row deduction"><span>Federal Income Tax</span><span>-<?= money((float)$pay['federal_tax']) ?></span></div>
                                    <div class="payslip-row deduction"><span>State Tax</span><span>-<?= money((float)$pay['state_tax']) ?></span></div>
                                    <div class="payslip-row deduction"><span>Social Security (6.2%)</span><span>-<?= money((float)$pay['social_security']) ?></span></div>
                                    <div class="payslip-row deduction"><span>Medicare (1.45%)</span><span>-<?= money((float)$pay['medicare']) ?></span></div>
                                    <div class="payslip-row deduction"><span>Health Insurance</span><span>-<?= money((float)$pay['health_insurance']) ?></span></div>
                                    <div class="payslip-row deduction"><span>401(k) Retirement (4%)</span><span>-<?= money((float)$pay['retirement_401k']) ?></span></div>
                                    <div class="payslip-row deduction"><span>Other Deductions</span><span>-<?= money((float)$pay['other_deductions']) ?></span></div>
                                    <div class="payslip-row payslip-total deduction"><span>Total Deductions</span><span>-<?= money((float)$pay['total_deductions']) ?></span></div>
                                </div>
                            </div>
                            <div class="payslip-net-row">
                                <span>NET PAY — <?= $pay['pay_date'] ? date('F j, Y', strtotime($pay['pay_date'])) : '—' ?></span>
                                <span class="net-amount"><?= money((float)$pay['net_pay']) ?></span>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- ════════════ TAB: LEAVE ════════════ -->
        <div class="tab-content-panel" id="tab-leave">
            <!-- Leave Balances -->
            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <div class="leave-balance-card">
                        <div class="lbc-icon lbc-annual"><i class="fa-solid fa-sun"></i></div>
                        <div class="lbc-info">
                            <div class="lbc-type">Annual Leave</div>
                            <div class="lbc-remaining"><?= $leaveAnnualLeft ?> days left</div>
                            <div class="lbc-bar">
                                <div class="lbc-fill lbc-fill-annual" style="width:<?= min(100,round($leaveAnnualLeft/($balance['annual_total']??21)*100)) ?>%"></div>
                            </div>
                            <small><?= $balance['annual_used']??0 ?> used / <?= $balance['annual_total']??21 ?> total</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="leave-balance-card">
                        <div class="lbc-icon lbc-sick"><i class="fa-solid fa-heart-pulse"></i></div>
                        <div class="lbc-info">
                            <div class="lbc-type">Sick Leave</div>
                            <div class="lbc-remaining"><?= $leaveSickLeft ?> days left</div>
                            <div class="lbc-bar">
                                <div class="lbc-fill lbc-fill-sick" style="width:<?= min(100,round($leaveSickLeft/($balance['sick_total']??10)*100)) ?>%"></div>
                            </div>
                            <small><?= $balance['sick_used']??0 ?> used / <?= $balance['sick_total']??10 ?> total</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="leave-balance-card">
                        <div class="lbc-icon lbc-personal"><i class="fa-solid fa-user-clock"></i></div>
                        <div class="lbc-info">
                            <div class="lbc-type">Personal Days</div>
                            <div class="lbc-remaining"><?= $leavePersonalLeft ?> days left</div>
                            <div class="lbc-bar">
                                <div class="lbc-fill lbc-fill-personal" style="width:<?= min(100,round($leavePersonalLeft/($balance['personal_total']??5)*100)) ?>%"></div>
                            </div>
                            <small><?= $balance['personal_used']??0 ?> used / <?= $balance['personal_total']??5 ?> total</small>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Request Leave Form -->
            <div class="dash-card mb-4">
                <div class="dash-card-header">
                    <h3 class="dash-card-title"><i class="fa-solid fa-paper-plane me-2"></i>Request Time Off</h3>
                </div>
                <form id="leaveForm" onsubmit="submitLeave(event)">
                    <div class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label-glass">Leave Type</label>
                            <select name="leave_type" class="form-control-glass">
                                <option value="annual">Annual Leave</option>
                                <option value="sick">Sick Leave</option>
                                <option value="personal">Personal Day</option>
                                <option value="maternity">Maternity</option>
                                <option value="paternity">Paternity</option>
                                <option value="unpaid">Unpaid Leave</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label-glass">Start Date</label>
                            <input type="date" name="start_date" id="leaveStart" class="form-control-glass"
                                   min="<?= date('Y-m-d') ?>" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label-glass">End Date</label>
                            <input type="date" name="end_date" id="leaveEnd" class="form-control-glass"
                                   min="<?= date('Y-m-d') ?>" required>
                        </div>
                        <div class="col-md-3 d-flex align-items-end">
                            <div class="days-calc-box">
                                <i class="fa-solid fa-calendar-days me-2"></i>
                                <span id="daysCalc">— days</span>
                            </div>
                        </div>
                        <div class="col-12">
                            <label class="form-label-glass">Reason (optional)</label>
                            <textarea name="reason" class="form-control-glass" rows="2" placeholder="Brief reason for your time off request..."></textarea>
                        </div>
                    </div>
                    <div class="mt-3">
                        <button type="submit" class="btn-glass-primary">
                            <i class="fa-solid fa-paper-plane me-2"></i>Submit Request
                        </button>
                    </div>
                </form>
            </div>

            <!-- Leave History -->
            <div class="dash-card">
                <div class="dash-card-header">
                    <h3 class="dash-card-title"><i class="fa-solid fa-history me-2"></i>My Leave History</h3>
                </div>
                <?php if (empty($leaveHistory)): ?>
                <div class="empty-state">
                    <i class="fa-solid fa-beach"></i>
                    <p>No leave requests yet.</p>
                </div>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="dash-table">
                        <thead>
                            <tr><th>Type</th><th>Start</th><th>End</th><th>Days</th><th>Reason</th><th>Status</th><th>Comment</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach ($leaveHistory as $lr): ?>
                            <tr>
                                <td><span class="badge-leave badge-<?= $lr['leave_type'] ?>"><?= ucfirst($lr['leave_type']) ?></span></td>
                                <td><?= date('M j, Y',strtotime($lr['start_date'])) ?></td>
                                <td><?= date('M j, Y',strtotime($lr['end_date'])) ?></td>
                                <td><?= $lr['days_requested'] ?></td>
                                <td><?= htmlspecialchars(substr($lr['reason']??'—',0,40)) ?></td>
                                <td><span class="badge-status badge-<?= $lr['status'] ?>"><?= ucfirst($lr['status']) ?></span></td>
                                <td><?= htmlspecialchars($lr['review_comment'] ?? '—') ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- ════════════ TAB: PROFILE ════════════ -->
        <div class="tab-content-panel" id="tab-profile">
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="dash-card text-center">
                        <div class="profile-avatar">
                            <?= strtoupper(substr($emp['first_name'],0,1).substr($emp['last_name'],0,1)) ?>
                        </div>
                        <h3 class="profile-name"><?= htmlspecialchars($emp['first_name'].' '.$emp['last_name']) ?></h3>
                        <p class="profile-title"><?= htmlspecialchars($emp['job_title'] ?? '—') ?></p>
                        <p class="profile-dept"><?= htmlspecialchars($emp['dept_name'] ?? '—') ?></p>
                        <div class="profile-id-badge"><?= htmlspecialchars($emp['employee_id']) ?></div>
                        <div class="profile-details-list mt-3">
                            <div class="pd-item"><i class="fa-solid fa-envelope"></i><?= htmlspecialchars($emp['email']) ?></div>
                            <div class="pd-item"><i class="fa-solid fa-calendar"></i>Joined <?= $emp['hire_date']?date('F j, Y',strtotime($emp['hire_date'])):'—' ?></div>
                            <div class="pd-item"><i class="fa-solid fa-briefcase"></i><?= ucfirst(str_replace('_',' ',$emp['employment_type'])) ?></div>
                            <div class="pd-item"><i class="fa-solid fa-tag"></i><?= $sal?money((float)$sal['base_salary']).'/yr':'—' ?></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="dash-card">
                        <div class="dash-card-header">
                            <h3 class="dash-card-title"><i class="fa-solid fa-pen-to-square me-2"></i>Edit Profile</h3>
                        </div>
                        <form id="profileForm" onsubmit="updateProfile(event)">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label-glass">Phone Number</label>
                                    <input type="tel" name="phone" class="form-control-glass"
                                           value="<?= htmlspecialchars($emp['phone']??'') ?>" placeholder="+1-555-0000">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label-glass">Bank Name</label>
                                    <input type="text" name="bank_name" class="form-control-glass"
                                           value="<?= htmlspecialchars($emp['bank_name']??'') ?>" placeholder="Chase Bank">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label-glass">Bank Account (last 4)</label>
                                    <input type="text" name="bank_account" class="form-control-glass"
                                           value="<?= htmlspecialchars($emp['bank_account']??'') ?>" placeholder="****1234">
                                </div>
                                <div class="col-12">
                                    <label class="form-label-glass">Home Address</label>
                                    <textarea name="address" class="form-control-glass" rows="2" placeholder="123 Main St, City, State"><?= htmlspecialchars($emp['address']??'') ?></textarea>
                                </div>
                            </div>
                            <div class="mt-3">
                                <button type="submit" class="btn-glass-primary">
                                    <i class="fa-solid fa-floppy-disk me-2"></i>Save Changes
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- ════════════ TAB: SECURITY ════════════ -->
        <div class="tab-content-panel" id="tab-security">
            <div class="row g-4">
                <div class="col-md-6">
                    <div class="dash-card">
                        <div class="dash-card-header">
                            <h3 class="dash-card-title"><i class="fa-solid fa-lock me-2"></i>Change Password</h3>
                        </div>
                        <form id="pwForm" onsubmit="changePassword(event)">
                            <div class="form-group-glass mb-3">
                                <label class="form-label-glass">Current Password</label>
                                <div class="input-password-wrap">
                                    <input type="password" name="current_password" id="curPw" class="form-control-glass" required>
                                    <button type="button" class="toggle-pw" onclick="togglePw('curPw',this)" tabindex="-1">
                                        <i class="fa-regular fa-eye"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="form-group-glass mb-3">
                                <label class="form-label-glass">New Password</label>
                                <div class="input-password-wrap">
                                    <input type="password" name="new_password" id="newPw" class="form-control-glass" required>
                                    <button type="button" class="toggle-pw" onclick="togglePw('newPw',this)" tabindex="-1">
                                        <i class="fa-regular fa-eye"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="form-group-glass mb-4">
                                <label class="form-label-glass">Confirm New Password</label>
                                <div class="input-password-wrap">
                                    <input type="password" name="confirm_password" id="confPw" class="form-control-glass" required>
                                    <button type="button" class="toggle-pw" onclick="togglePw('confPw',this)" tabindex="-1">
                                        <i class="fa-regular fa-eye"></i>
                                    </button>
                                </div>
                            </div>
                            <button type="submit" class="btn-glass-primary">
                                <i class="fa-solid fa-shield-halved me-2"></i>Update Password
                            </button>
                        </form>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="dash-card">
                        <div class="dash-card-header">
                            <h3 class="dash-card-title"><i class="fa-solid fa-info-circle me-2"></i>Account Info</h3>
                        </div>
                        <div class="info-row"><span>Employee ID</span><code><?= $emp['employee_id'] ?></code></div>
                        <div class="info-row"><span>Tax ID</span><code><?= htmlspecialchars($emp['tax_id']??'—') ?></code></div>
                        <div class="info-row"><span>Account Status</span><span class="badge-status badge-active">Active</span></div>
                        <div class="info-row"><span>Role</span><span>Employee</span></div>
                        <div class="info-row"><span>Member Since</span><span><?= $emp['created_at']?date('F j, Y',strtotime($emp['created_at'])):'—' ?></span></div>
                        <div class="info-row"><span>Last Updated</span><span><?= $emp['updated_at']?date('M j, Y g:i A',strtotime($emp['updated_at'])):'—' ?></span></div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<div class="toast-container" id="toastContainer"></div>
<div class="loader-overlay" id="loaderOverlay">
    <div class="loader-spinner">
        <div class="spinner-ring"></div>
        <p id="loaderMsg">Loading...</p>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script>
const CSRF = '<?= $csrf ?>';
const trendLabels = <?= json_encode($trendLabels) ?>;
const trendNet    = <?= json_encode($trendNet) ?>;
const trendGross  = <?= json_encode($trendGross) ?>;
const compLabels  = <?= json_encode($compLabels) ?>;
const compData    = <?= json_encode($compBreakdown) ?>;

// Tabs
const tabBreadcrumbs = {overview:'Overview',payslips:'My Payslips',leave:'Leave & PTO',profile:'My Profile',security:'Security'};
function showTab(tabId) {
    document.querySelectorAll('.tab-content-panel').forEach(p=>p.classList.remove('active'));
    document.querySelectorAll('.sidebar-link').forEach(l=>l.classList.remove('active'));
    const panel = document.getElementById('tab-'+tabId);
    if(panel) panel.classList.add('active');
    const link = document.querySelector(`[data-tab="${tabId}"]`);
    if(link) link.classList.add('active');
    document.getElementById('breadcrumb-text').textContent = tabBreadcrumbs[tabId]||tabId;
    if(window.innerWidth<1200) document.getElementById('sidebar').classList.remove('sidebar-open');
}
document.querySelectorAll('.sidebar-link[data-tab]').forEach(l=>{
    l.addEventListener('click',e=>{e.preventDefault();showTab(l.dataset.tab);});
});
function toggleSidebar(){document.getElementById('sidebar').classList.toggle('sidebar-open');}

// Charts
new Chart(document.getElementById('myPayChart'),{
    type:'line',
    data:{
        labels:trendLabels,
        datasets:[
            {label:'Gross Pay',data:trendGross,borderColor:'#3b82f6',backgroundColor:'rgba(59,130,246,.1)',fill:true,tension:.4,pointRadius:5,pointBackgroundColor:'#3b82f6'},
            {label:'Net Pay',data:trendNet,borderColor:'#00d4a8',backgroundColor:'rgba(0,212,168,.1)',fill:true,tension:.4,pointRadius:5,pointBackgroundColor:'#00d4a8'}
        ]
    },
    options:{responsive:true,maintainAspectRatio:false,
        plugins:{legend:{labels:{color:'#94a3b8',font:{size:11}}}},
        scales:{
            x:{ticks:{color:'#64748b'},grid:{color:'rgba(255,255,255,.04)'}},
            y:{ticks:{color:'#64748b',callback:v=>'$'+v.toLocaleString()},grid:{color:'rgba(255,255,255,.04)'}}
        }
    }
});

if(compData.length){
    new Chart(document.getElementById('compMixChart'),{
        type:'doughnut',
        data:{
            labels:compLabels,
            datasets:[{data:compData,backgroundColor:['#3b82f6','#00d4a8','#f59e0b'],borderWidth:0,hoverOffset:8}]
        },
        options:{responsive:true,maintainAspectRatio:false,cutout:'65%',
            plugins:{legend:{labels:{color:'#94a3b8',font:{size:11}},position:'bottom'}}}
    });
}

// Payslip accordion
function togglePayslip(idx){
    const body    = document.getElementById('payslip-body-'+idx);
    const chevron = document.getElementById('chevron-'+idx);
    const isOpen  = body.style.display!=='none';
    body.style.display = isOpen?'none':'block';
    chevron.style.transform = isOpen?'':'rotate(180deg)';
}

// Days calculator
function calcDays(){
    const s=document.getElementById('leaveStart').value;
    const e=document.getElementById('leaveEnd').value;
    if(!s||!e){document.getElementById('daysCalc').textContent='— days';return;}
    const diff=Math.round((new Date(e)-new Date(s))/(1000*60*60*24))+1;
    document.getElementById('daysCalc').textContent=diff>0?diff+' day'+(diff>1?'s':''):'Invalid';
}
document.getElementById('leaveStart')?.addEventListener('change',calcDays);
document.getElementById('leaveEnd')?.addEventListener('change',calcDays);

// API
function post(data){
    data.csrf_token=CSRF;
    return fetch('employee_dashboard.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(data)}).then(r=>r.json());
}
function showLoader(msg){document.getElementById('loaderMsg').textContent=msg||'Loading...';document.getElementById('loaderOverlay').classList.add('active');}
function hideLoader(){document.getElementById('loaderOverlay').classList.remove('active');}
function toast(msg,type){
    const c=document.getElementById('toastContainer'),t=document.createElement('div');
    t.className=`toast-item toast-${type||'success'}`;
    const icon=type==='error'?'circle-xmark':'circle-check';
    t.innerHTML=`<i class="fa-solid fa-${icon} me-2"></i>${msg}`;
    c.appendChild(t);setTimeout(()=>t.classList.add('toast-show'),10);
    setTimeout(()=>{t.classList.remove('toast-show');setTimeout(()=>t.remove(),400);},4000);
}

function submitLeave(e){
    e.preventDefault();
    const fd=new FormData(document.getElementById('leaveForm'));
    const data=Object.fromEntries(fd.entries());
    data.action='submit_leave';
    showLoader('Submitting leave request...');
    post(data).then(r=>{hideLoader();toast(r.message,r.success?'success':'error');if(r.success){document.getElementById('leaveForm').reset();document.getElementById('daysCalc').textContent='— days';setTimeout(()=>location.reload(),2000);}}).catch(()=>{hideLoader();toast('Network error','error');});
}

function updateProfile(e){
    e.preventDefault();
    const fd=new FormData(document.getElementById('profileForm'));
    const data=Object.fromEntries(fd.entries());
    data.action='update_profile';
    showLoader('Saving...');
    post(data).then(r=>{hideLoader();toast(r.message,r.success?'success':'error');}).catch(()=>{hideLoader();toast('Error','error');});
}

function changePassword(e){
    e.preventDefault();
    const np=document.getElementById('newPw').value;
    const cp=document.getElementById('confPw').value;
    if(np!==cp){toast('Passwords do not match','error');return;}
    const fd=new FormData(document.getElementById('pwForm'));
    const data=Object.fromEntries(fd.entries());
    data.action='change_password';
    showLoader('Updating password...');
    post(data).then(r=>{hideLoader();toast(r.message,r.success?'success':'error');if(r.success)document.getElementById('pwForm').reset();}).catch(()=>{hideLoader();toast('Error','error');});
}

function togglePw(id,btn){
    const input=document.getElementById(id),icon=btn.querySelector('i');
    input.type=input.type==='password'?'text':'password';
    icon.className=input.type==='password'?'fa-regular fa-eye':'fa-regular fa-eye-slash';
}
</script>
</body>
</html>
