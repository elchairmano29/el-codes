<?php
require_once 'config.php';

if (isLoggedIn()) {
    header('Location: ' . ($_SESSION['role'] === 'admin' ? 'admin_dashboard.php' : 'employee_dashboard.php'));
    exit();
}

$success = '';
$error   = '';
$vals    = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validateCSRF();

    $vals = [
        'first_name' => sanitize($_POST['first_name'] ?? ''),
        'last_name'  => sanitize($_POST['last_name']  ?? ''),
        'email'      => trim($_POST['email']           ?? ''),
        'job_title'  => sanitize($_POST['job_title']   ?? ''),
        'phone'      => sanitize($_POST['phone']        ?? ''),
    ];
    $password  = $_POST['password']  ?? '';
    $password2 = $_POST['password2'] ?? '';

    // Validation
    $errors = [];
    if (empty($vals['first_name'])) $errors[] = 'First name is required.';
    if (empty($vals['last_name']))  $errors[] = 'Last name is required.';
    if (!filter_var($vals['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required.';
    if (strlen($password) < 8)     $errors[] = 'Password must be at least 8 characters.';
    if (!preg_match('/[A-Z]/', $password)) $errors[] = 'Password must contain an uppercase letter.';
    if (!preg_match('/[0-9]/', $password)) $errors[] = 'Password must contain a number.';
    if ($password !== $password2)  $errors[] = 'Passwords do not match.';

    if (empty($errors)) {
        try {
            $pdo = getPDO();

            // Check email uniqueness
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$vals['email']]);
            if ($stmt->fetch()) {
                $errors[] = 'This email address is already registered.';
            } else {
                // Generate employee ID
                $countStmt = $pdo->query("SELECT COUNT(*) FROM users");
                $count     = (int)$countStmt->fetchColumn() + 1;
                $empId     = 'EMP-' . str_pad($count, 4, '0', STR_PAD_LEFT);

                $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);

                $insert = $pdo->prepare("INSERT INTO users 
                    (employee_id, first_name, last_name, email, password_hash, role, job_title, phone, status)
                    VALUES (?, ?, ?, ?, ?, 'employee', ?, ?, 'active')");
                $insert->execute([
                    $empId,
                    $vals['first_name'],
                    $vals['last_name'],
                    $vals['email'],
                    $hash,
                    $vals['job_title'],
                    $vals['phone'],
                ]);
                $newId = (int)$pdo->lastInsertId();

                // Create default leave balance
                $pdo->prepare("INSERT INTO leave_balances (user_id, year) VALUES (?, ?)")
                    ->execute([$newId, date('Y')]);

                auditLog('REGISTER', 'users', $newId);

                $success = 'Account created successfully! Your Employee ID is <strong>' . $empId . '</strong>. You can now <a href="login.php" class="auth-link">sign in</a>.';
                $vals = [];
            }
        } catch (PDOException $e) {
            $error = 'Registration failed. Please try again.';
        }
    } else {
        $error = implode('<br>', $errors);
    }
}

$csrf = generateCSRF();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Request Access — <?= APP_NAME ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body class="auth-body">

<div class="bg-orbs">
    <div class="orb orb-1"></div>
    <div class="orb orb-2"></div>
    <div class="orb orb-3"></div>
</div>

<div class="auth-wrapper">
    <!-- Left Panel -->
    <div class="auth-left d-none d-lg-flex">
        <div class="auth-left-inner">
            <div class="brand-logo mb-4">
                <i class="fa-solid fa-building-columns"></i>
            </div>
            <h1 class="brand-title"><?= APP_NAME ?></h1>
            <p class="brand-sub">Join the platform trusted by enterprise teams worldwide.</p>

            <div class="onboarding-steps mt-5">
                <div class="onboarding-step active">
                    <div class="step-num">1</div>
                    <div>
                        <div class="step-title">Create Account</div>
                        <div class="step-desc">Enter your details to get started</div>
                    </div>
                </div>
                <div class="onboarding-step">
                    <div class="step-num">2</div>
                    <div>
                        <div class="step-title">Admin Approval</div>
                        <div class="step-desc">HR assigns your department & role</div>
                    </div>
                </div>
                <div class="onboarding-step">
                    <div class="step-num">3</div>
                    <div>
                        <div class="step-title">Access Portal</div>
                        <div class="step-desc">View payslips, PTO, and more</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Right Panel: Signup Form -->
    <div class="auth-right">
        <div class="auth-card" style="max-width:480px">
            <div class="auth-card-header">
                <div class="mobile-logo d-lg-none mb-4">
                    <i class="fa-solid fa-building-columns"></i>
                    <span><?= APP_NAME ?></span>
                </div>
                <h2 class="auth-heading">Request Access</h2>
                <p class="auth-subheading">Create your employee account</p>
            </div>

            <?php if ($success): ?>
            <div class="alert-glass alert-glass-success mb-4">
                <i class="fa-solid fa-circle-check me-2"></i>
                <?= $success ?>
            </div>
            <?php elseif ($error): ?>
            <div class="alert-glass alert-glass-danger mb-4">
                <i class="fa-solid fa-circle-exclamation me-2"></i>
                <?= $error ?>
            </div>
            <?php endif; ?>

            <?php if (!$success): ?>
            <form method="POST" action="signup.php" id="signupForm" novalidate>
                <input type="hidden" name="csrf_token" value="<?= $csrf ?>">

                <div class="row g-3 mb-3">
                    <div class="col-6">
                        <label class="form-label-glass" for="first_name">First Name</label>
                        <input type="text" id="first_name" name="first_name"
                               class="form-control-glass"
                               placeholder="John"
                               value="<?= htmlspecialchars($vals['first_name'] ?? '', ENT_QUOTES) ?>"
                               required>
                    </div>
                    <div class="col-6">
                        <label class="form-label-glass" for="last_name">Last Name</label>
                        <input type="text" id="last_name" name="last_name"
                               class="form-control-glass"
                               placeholder="Doe"
                               value="<?= htmlspecialchars($vals['last_name'] ?? '', ENT_QUOTES) ?>"
                               required>
                    </div>
                </div>

                <div class="form-group-glass mb-3">
                    <label class="form-label-glass" for="email">
                        <i class="fa-solid fa-envelope me-2"></i>Work Email
                    </label>
                    <input type="email" id="email" name="email"
                           class="form-control-glass"
                           placeholder="you@company.com"
                           value="<?= htmlspecialchars($vals['email'] ?? '', ENT_QUOTES) ?>"
                           required>
                </div>

                <div class="form-group-glass mb-3">
                    <label class="form-label-glass" for="job_title">Job Title</label>
                    <input type="text" id="job_title" name="job_title"
                           class="form-control-glass"
                           placeholder="Software Engineer"
                           value="<?= htmlspecialchars($vals['job_title'] ?? '', ENT_QUOTES) ?>">
                </div>

                <div class="form-group-glass mb-3">
                    <label class="form-label-glass" for="phone">Phone Number</label>
                    <input type="tel" id="phone" name="phone"
                           class="form-control-glass"
                           placeholder="+1-555-0000"
                           value="<?= htmlspecialchars($vals['phone'] ?? '', ENT_QUOTES) ?>">
                </div>

                <div class="form-group-glass mb-3">
                    <label class="form-label-glass" for="password">
                        <i class="fa-solid fa-lock me-2"></i>Password
                    </label>
                    <div class="input-password-wrap">
                        <input type="password" id="password" name="password"
                               class="form-control-glass"
                               placeholder="Min 8 chars, 1 uppercase, 1 number"
                               required>
                        <button type="button" class="toggle-pw" onclick="togglePw('password', this)" tabindex="-1">
                            <i class="fa-regular fa-eye"></i>
                        </button>
                    </div>
                    <div class="pw-strength-bar mt-2">
                        <div class="pw-strength-fill" id="pwStrengthFill"></div>
                    </div>
                    <small class="pw-strength-label" id="pwStrengthLabel"></small>
                </div>

                <div class="form-group-glass mb-4">
                    <label class="form-label-glass" for="password2">Confirm Password</label>
                    <div class="input-password-wrap">
                        <input type="password" id="password2" name="password2"
                               class="form-control-glass"
                               placeholder="Re-enter password"
                               required>
                        <button type="button" class="toggle-pw" onclick="togglePw('password2', this)" tabindex="-1">
                            <i class="fa-regular fa-eye"></i>
                        </button>
                    </div>
                </div>

                <button type="submit" class="btn-glass-primary w-100 mb-3" id="signupBtn">
                    <span class="btn-text">
                        <i class="fa-solid fa-user-plus me-2"></i>Create Account
                    </span>
                    <span class="btn-loader d-none">
                        <i class="fa-solid fa-circle-notch fa-spin me-2"></i>Creating...
                    </span>
                </button>
            </form>
            <?php endif; ?>

            <p class="auth-footer-text">
                Already have an account? 
                <a href="login.php" class="auth-link">Sign in</a>
            </p>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/js/bootstrap.bundle.min.js"></script>
<script>
function togglePw(id, btn) {
    const input = document.getElementById(id);
    const icon  = btn.querySelector('i');
    input.type  = input.type === 'password' ? 'text' : 'password';
    icon.className = input.type === 'password' ? 'fa-regular fa-eye' : 'fa-regular fa-eye-slash';
}

// Password strength indicator
document.getElementById('password')?.addEventListener('input', function() {
    const pw    = this.value;
    const fill  = document.getElementById('pwStrengthFill');
    const label = document.getElementById('pwStrengthLabel');
    let score   = 0;

    if (pw.length >= 8)           score++;
    if (/[A-Z]/.test(pw))         score++;
    if (/[0-9]/.test(pw))         score++;
    if (/[^A-Za-z0-9]/.test(pw))  score++;
    if (pw.length >= 12)           score++;

    const levels = [
        { label: '', color: '' },
        { label: 'Weak',       color: '#ef4444' },
        { label: 'Fair',       color: '#f97316' },
        { label: 'Good',       color: '#eab308' },
        { label: 'Strong',     color: '#22c55e' },
        { label: 'Very Strong',color: '#00d4a8' },
    ];

    fill.style.width = (score / 5 * 100) + '%';
    fill.style.background = levels[score].color;
    label.textContent = levels[score].label;
    label.style.color = levels[score].color;
});

// Form validation
document.getElementById('signupForm')?.addEventListener('submit', function(e) {
    const pw  = document.getElementById('password').value;
    const pw2 = document.getElementById('password2').value;
    const btn = document.getElementById('signupBtn');

    if (pw !== pw2) {
        e.preventDefault();
        alert('Passwords do not match.');
        return;
    }
    if (pw.length < 8 || !/[A-Z]/.test(pw) || !/[0-9]/.test(pw)) {
        e.preventDefault();
        alert('Password must be at least 8 characters with 1 uppercase letter and 1 number.');
        return;
    }

    btn.querySelector('.btn-text').classList.add('d-none');
    btn.querySelector('.btn-loader').classList.remove('d-none');
    btn.disabled = true;
});
</script>
</body>
</html>
