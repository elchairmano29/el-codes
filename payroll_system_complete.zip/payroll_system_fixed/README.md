# PayrollPro Enterprise — Setup Guide
## Complete Installation on XAMPP

---

## 📁 STEP 1: Folder Structure

Place all files inside XAMPP's `htdocs` directory:

```
C:\xampp\htdocs\payroll_system\
│
├── database.sql           ← Database schema + data (passwords pre-hashed ✓)
├── config.php             ← DB config & helper functions
├── index.php              ← Entry point (auto-redirects to login)
├── login.php              ← Login page
├── signup.php             ← Registration page
├── logout.php             ← Session destroy
├── admin_dashboard.php    ← Admin control panel
├── employee_dashboard.php ← Employee self-service portal
├── style.css              ← Theme
└── setup.php              ← Password reset utility (only needed if logins break)
```

---

## 🗄️ STEP 2: Import the Database

1. Start **Apache** and **MySQL** in your XAMPP Control Panel
2. Open: `http://localhost/phpmyadmin`
3. Click **"Import"** → **"Choose File"** → select `database.sql`
4. Click **"Go"** — you should see _"Import has been successfully finished"_

---

## ⚙️ STEP 3: Configure Database Connection

Open `config.php` and verify:

```php
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'payroll_db');
define('DB_USER', 'root');
define('DB_PASS', '');   // Default XAMPP = empty password
```

---

## 🚀 STEP 4: Access the System

Open your browser and go to:

```
http://localhost/payroll_system/
```

Or directly:

```
http://localhost/payroll_system/login.php
```

> **No need to run setup.php** — passwords are already correct in the SQL file.

---

## 🔐 Login Credentials

All accounts use: **`Password@123`**

### Administrator Accounts
| Name         | Email                    |
|--------------|--------------------------|
| Alex Morgan  | admin@payroll.com        |
| Sarah Chen   | sarah.chen@payroll.com   |

### Employee Accounts
| Name              | Email                      |
|-------------------|----------------------------|
| Marcus Thompson   | marcus.t@payroll.com       |
| Priya Patel       | priya.patel@payroll.com    |
| James Wright      | james.wright@payroll.com   |
| Elena Rodriguez   | elena.r@payroll.com        |
| David Kim         | david.kim@payroll.com      |
| Amara Osei        | amara.osei@payroll.com     |
| Lucas Ferreira    | lucas.f@payroll.com        |
| Mei Zhang         | mei.zhang@payroll.com      |
| Tyler Brooks      | tyler.b@payroll.com        |
| Fatima Al-Hassan  | fatima.ah@payroll.com      |

---

## 🧩 Features

### Admin Dashboard
- 📊 **Dashboard** — KPI cards, payroll trend chart, department cost pie chart
- 📈 **Analytics** — 6-month summaries, headcount charts, period-by-period tables
- 💰 **Payroll Processing** — Run payroll for all employees, auto tax calculation
- 📅 **Pay Periods** — View/manage all periods, **create new periods**, close periods
- 👥 **Employee Management** — View all employees, add new employees, terminate
- 🏖️ **Leave Requests** — Approve or reject leave with comments
- 🛡️ **Audit Log** — Full action trail
- 📢 **Announcements** — **Post new announcements**, view existing

### Employee Self-Service Portal
- 🏠 **Overview** — Pay stats, PTO balances, latest payslip preview, charts
- 📄 **Payslips** — Full history with expandable detailed payslip accordion
- 🏖️ **Leave & PTO** — Balance tracker, submit new leave requests, history
- 👤 **Profile** — Edit phone, address, banking details
- 🔒 **Security** — Change password with strength validation

---

## 🔧 Payroll Processing Logic

When you click **"Run Payroll"**:
1. Fetches all active employees with salary structures
2. Calculates monthly base salary (annual ÷ 12)
3. Simulates hours worked (176h standard) + random overtime
4. Applies US Federal tax brackets (2026) automatically
5. Deducts: State Tax (5%), Social Security (6.2%), Medicare (1.45%)
6. Deducts: Health Insurance ($450/mo), 401(k) 4%
7. Adds any custom recurring deductions per employee
8. Creates payroll records with `approved` status
9. **"Close Period"** marks all records as `paid`

---

## 🛠️ Troubleshooting

**"Database connection failed"**
→ Ensure MySQL is running in XAMPP Control Panel  
→ Check DB credentials in `config.php`  
→ Confirm `payroll_db` was created by the import

**"Invalid email or password"**
→ Make sure you imported `database.sql` correctly  
→ If still failing, visit `http://localhost/payroll_system/setup.php` to reset passwords  
→ Password for all accounts: `Password@123`

**"Page not found (404)"**
→ Confirm files are in `C:\xampp\htdocs\payroll_system\`  
→ URL: `http://localhost/payroll_system/login.php`

**Charts not showing**
→ Requires internet connection (Chart.js loads from CDN)

---

## 🌐 Requirements

- PHP 8.0+ (XAMPP ships with 8.x) ✓
- MySQL 5.7+ or MariaDB 10.3+ ✓
- PDO + PDO_MySQL extensions (enabled by default) ✓

---

*PayrollPro Enterprise v2.6.1 — Fixed & Completed for XAMPP/PHP 8.x*
