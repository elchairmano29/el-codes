<?php
/**
 * setup.php — ONE-TIME SETUP / PASSWORD RESET SCRIPT
 *
 * NOTE: The database.sql in this package already contains correct password hashes.
 * You only need to run this if passwords stop working or you want to reset them all.
 *
 * URL: http://localhost/payroll_system/setup.php
 * DELETE this file after use.
 */
if (!in_array($_SERVER['REMOTE_ADDR'], ['127.0.0.1', '::1'])) {
    http_response_code(403);
    die('Access denied. This script can only be run from localhost.');
}

require_once 'config.php';

$password = 'Password@123';
$hash     = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
$log      = [];

try {
    $pdo  = getPDO();
    $stmt = $pdo->prepare("UPDATE users SET password_hash = ?");
    $stmt->execute([$hash]);
    $count = $stmt->rowCount();
    $log[] = ['success', "Password reset for {$count} user account(s)."];
    $log[] = ['info',    "Admin login: admin@payroll.com / {$password}"];
    $log[] = ['info',    "Employee login: marcus.t@payroll.com / {$password}"];
    $log[] = ['info',    "All other accounts also use: {$password}"];
} catch (PDOException $e) {
    $log[] = ['error', 'Database Error: ' . $e->getMessage()];
    $log[] = ['error', 'Make sure XAMPP MySQL is running and payroll_db was imported.'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Setup — PayrollPro</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Inter', sans-serif; background: #060d1f; color: #f0f4ff;
               display: flex; align-items: center; justify-content: center; min-height: 100vh; padding: 20px; }
        .box { background: rgba(255,255,255,.04); border: 1px solid rgba(255,255,255,.1);
               border-radius: 16px; padding: 40px; max-width: 520px; width: 100%; }
        h1 { font-size: 1.4rem; font-weight: 700; margin-bottom: 6px; }
        .subtitle { color: #64748b; font-size: .875rem; margin-bottom: 24px; }
        .log { padding: 12px 16px; border-radius: 8px; margin: 8px 0; font-size: .875rem; line-height: 1.5; }
        .success { background: rgba(0,212,168,.1); border: 1px solid rgba(0,212,168,.25); color: #5eead4; }
        .info    { background: rgba(59,130,246,.1); border: 1px solid rgba(59,130,246,.25); color: #93c5fd; }
        .error   { background: rgba(244,63,94,.1);  border: 1px solid rgba(244,63,94,.25);  color: #fca5a5; }
        .warn { background: rgba(245,158,11,.1); border: 1px solid rgba(245,158,11,.35);
                color: #fcd34d; padding: 16px; border-radius: 10px; margin-top: 24px; font-size: .85rem; line-height: 1.6; }
        .warn strong { display: block; font-size: .95rem; margin-bottom: 4px; }
        .btn { display: inline-block; margin-top: 24px; background: linear-gradient(135deg, #3b82f6, #1d4ed8);
               color: #fff; padding: 12px 24px; border-radius: 10px; text-decoration: none;
               font-weight: 600; font-size: .9rem; }
        hr { border: none; border-top: 1px solid rgba(255,255,255,.07); margin: 20px 0; }
    </style>
</head>
<body>
<div class="box">
    <h1>PayrollPro Setup</h1>
    <p class="subtitle">Password reset utility — localhost access only</p>

    <?php foreach ($log as [$type, $msg]): ?>
    <div class="log <?= $type ?>"><?= htmlspecialchars($msg) ?></div>
    <?php endforeach; ?>

    <hr>
    <div class="warn">
        <strong>Security Notice</strong>
        Delete setup.php from your project folder immediately after use.
        This file resets ALL user passwords and should never remain on a live server.
    </div>

    <a href="login.php" class="btn">Go to Login Page</a>
</div>
</body>
</html>
