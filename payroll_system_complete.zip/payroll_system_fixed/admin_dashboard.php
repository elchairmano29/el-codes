<?php
require_once 'config.php';
requireAdmin();

$pdo  = getPDO();
$user = currentUser();

// ─── Handle AJAX Actions ──────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    validateCSRF();
    $action = $_POST['action'];

    // ── Process Payroll for a Period ─────────────────────────────────────────
    if ($action === 'process_payroll') {
        $periodId = (int)($_POST['period_id'] ?? 0);
        if ($periodId < 1) jsonResponse(false, 'Invalid pay period.');

        try {
            $pdo->beginTransaction();

            // Get all active employees with salary structures
            $employees = $pdo->prepare("
                SELECT u.id, u.first_name, u.last_name,
                       ss.base_salary, ss.hourly_rate, ss.overtime_multiplier,
                       ss.housing_allowance, ss.transport_allowance,
                       ss.meal_allowance, ss.medical_allowance
                FROM users u
                JOIN salary_structures ss ON ss.user_id = u.id
                WHERE u.status = 'active' AND u.role = 'employee'
                ORDER BY ss.created_at DESC");
            $employees->execute();
            $empList = $employees->fetchAll();

            // Deduplicate by user_id (take latest salary structure)
            $seen = []; $unique = [];
            foreach ($empList as $emp) {
                if (!isset($seen[$emp['id']])) {
                    $seen[$emp['id']] = true;
                    $unique[] = $emp;
                }
            }

            $processed = 0;
            foreach ($unique as $emp) {
                // Skip if already processed
                $exists = $pdo->prepare("SELECT id FROM payroll_records WHERE user_id=? AND pay_period_id=?");
                $exists->execute([$emp['id'], $periodId]);
                if ($exists->fetch()) continue;

                $monthlyBase   = $emp['base_salary'] / 12;
                $hoursWorked   = 176.00; // Standard month hours
                $overtimeHours = rand(0, 15); // Simulated
                $otHourlyRate  = ($emp['hourly_rate'] ?? ($monthlyBase / 160)) * $emp['overtime_multiplier'];
                $overtimePay   = round($overtimeHours * $otHourlyRate, 2);

                // Custom deductions
                $dedStmt = $pdo->prepare("SELECT SUM(amount) as total FROM deductions 
                    WHERE user_id=? AND is_recurring=1 AND effective_from <= CURDATE()
                    AND (effective_to IS NULL OR effective_to >= CURDATE())");
                $dedStmt->execute([$emp['id']]);
                $customDed = (float)($dedStmt->fetchColumn() ?? 0);

                $grossPay = $monthlyBase + $overtimePay
                          + $emp['housing_allowance'] + $emp['transport_allowance']
                          + $emp['meal_allowance'] + $emp['medical_allowance'];

                $taxes        = calculateTaxes($emp['base_salary']);
                $healthIns    = 450.00;
                $retirement   = round($monthlyBase * 0.04, 2); // 4% 401k
                $totalDed     = $taxes['federal'] + $taxes['state'] + $taxes['socialSec']
                              + $taxes['medicare'] + $healthIns + $retirement + $customDed;
                $netPay       = round($grossPay - $totalDed, 2);

                $insert = $pdo->prepare("INSERT INTO payroll_records
                    (user_id, pay_period_id, base_salary, hours_worked, overtime_hours, overtime_pay,
                     housing_allowance, transport_allowance, meal_allowance, medical_allowance,
                     performance_bonus, other_bonus, gross_pay, federal_tax, state_tax,
                     social_security, medicare, health_insurance, retirement_401k,
                     other_deductions, total_deductions, net_pay, status, processed_by, processed_at)
                    VALUES (?,?,?,?,?,?,?,?,?,?,0,0,?,?,?,?,?,?,?,?,?,?,'approved',?,NOW())");
                $insert->execute([
                    $emp['id'], $periodId, round($monthlyBase, 2),
                    $hoursWorked, $overtimeHours, $overtimePay,
                    $emp['housing_allowance'], $emp['transport_allowance'],
                    $emp['meal_allowance'], $emp['medical_allowance'],
                    round($grossPay, 2),
                    $taxes['federal'], $taxes['state'], $taxes['socialSec'],
                    $taxes['medicare'], $healthIns, $retirement,
                    $customDed, round($totalDed, 2), $netPay,
                    $user['id']
                ]);
                $processed++;
            }

            // Update period status
            $pdo->prepare("UPDATE pay_periods SET status='processing' WHERE id=?")->execute([$periodId]);
            $pdo->commit();

            auditLog('PROCESS_PAYROLL', 'pay_periods', $periodId);
            jsonResponse(true, "Payroll processed for {$processed} employees.", ['count' => $processed]);
        } catch (PDOException $e) {
            $pdo->rollBack();
            jsonResponse(false, 'Payroll processing failed: ' . $e->getMessage());
        }
    }

    // ── Approve / Reject Leave ────────────────────────────────────────────────
    if ($action === 'review_leave') {
        $leaveId = (int)($_POST['leave_id'] ?? 0);
        $status  = $_POST['status'] ?? '';
        $comment = sanitize($_POST['comment'] ?? '');

        if (!in_array($status, ['approved', 'rejected'])) jsonResponse(false, 'Invalid status.');

        try {
            $pdo->prepare("UPDATE leave_requests SET status=?, reviewed_by=?, reviewed_at=NOW(), review_comment=? WHERE id=?")
                ->execute([$status, $user['id'], $comment, $leaveId]);
            auditLog('REVIEW_LEAVE', 'leave_requests', $leaveId);
            jsonResponse(true, 'Leave request ' . $status . '.');
        } catch (PDOException $e) {
            jsonResponse(false, 'Update failed.');
        }
    }

    // ── Add Employee ──────────────────────────────────────────────────────────
    if ($action === 'add_employee') {
        $fn    = sanitize($_POST['first_name'] ?? '');
        $ln    = sanitize($_POST['last_name']  ?? '');
        $email = trim($_POST['email'] ?? '');
        $dept  = (int)($_POST['department_id'] ?? 0);
        $title = sanitize($_POST['job_title'] ?? '');
        $type  = $_POST['employment_type'] ?? 'full_time';
        $hire  = $_POST['hire_date'] ?? date('Y-m-d');
        $sal   = (float)($_POST['base_salary'] ?? 0);

        if (!$fn || !$ln || !filter_var($email, FILTER_VALIDATE_EMAIL) || $sal < 1) {
            jsonResponse(false, 'Please fill all required fields correctly.');
        }

        try {
            $check = $pdo->prepare("SELECT id FROM users WHERE email=?");
            $check->execute([$email]);
            if ($check->fetch()) jsonResponse(false, 'Email already registered.');

            $count = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn() + 1;
            $empId = 'EMP-' . str_pad($count, 4, '0', STR_PAD_LEFT);
            $hash  = password_hash('Password@123', PASSWORD_BCRYPT, ['cost' => 12]);

            $pdo->beginTransaction();
            $ins = $pdo->prepare("INSERT INTO users 
                (employee_id,first_name,last_name,email,password_hash,role,department_id,job_title,hire_date,employment_type,status)
                VALUES (?,?,?,?,?,'employee',?,?,?,?,'active')");
            $ins->execute([$empId,$fn,$ln,$email,$hash,$dept,$title,$hire,$type]);
            $newId = (int)$pdo->lastInsertId();

            // Salary structure
            $hourly = round($sal / 2080, 2);
            $pdo->prepare("INSERT INTO salary_structures 
                (user_id,base_salary,hourly_rate,overtime_multiplier,housing_allowance,transport_allowance,meal_allowance,medical_allowance,effective_date)
                VALUES (?,?,?,1.5,1200,350,200,500,?)")
                ->execute([$newId, $sal, $hourly, date('Y-01-01')]);

            // Leave balance
            $pdo->prepare("INSERT INTO leave_balances (user_id,year) VALUES (?,?)")
                ->execute([$newId, date('Y')]);

            $pdo->commit();
            auditLog('ADD_EMPLOYEE', 'users', $newId);
            jsonResponse(true, "Employee {$fn} {$ln} added. ID: {$empId}. Default password: Password@123", ['employee_id' => $empId]);
        } catch (PDOException $e) {
            $pdo->rollBack();
            jsonResponse(false, 'Failed to add employee.');
        }
    }

    // ── Close Pay Period ──────────────────────────────────────────────────────
    if ($action === 'close_period') {
        $periodId = (int)($_POST['period_id'] ?? 0);
        try {
            $pdo->prepare("UPDATE pay_periods SET status='closed' WHERE id=?")
                ->execute([$periodId]);
            $pdo->prepare("UPDATE payroll_records SET status='paid' WHERE pay_period_id=? AND status='approved'")
                ->execute([$periodId]);
            auditLog('CLOSE_PERIOD', 'pay_periods', $periodId);
            jsonResponse(true, 'Pay period closed and all records marked as paid.');
        } catch (PDOException $e) {
            jsonResponse(false, 'Failed to close period.');
        }
    }

    // ── Create Pay Period ─────────────────────────────────────────────────────
    if ($action === 'create_period') {
        $name      = sanitize($_POST['period_name'] ?? '');
        $startDate = $_POST['start_date'] ?? '';
        $endDate   = $_POST['end_date']   ?? '';
        $payDate   = $_POST['pay_date']   ?? '';

        if (!$name || !$startDate || !$endDate || !$payDate) {
            jsonResponse(false, 'All fields are required.');
        }
        if ($endDate < $startDate) {
            jsonResponse(false, 'End date must be after start date.');
        }
        if ($payDate < $endDate) {
            jsonResponse(false, 'Pay date must be on or after end date.');
        }

        try {
            // Check for overlapping open periods
            $overlap = $pdo->prepare("SELECT id FROM pay_periods 
                WHERE status='open' AND NOT (end_date < ? OR start_date > ?)");
            $overlap->execute([$startDate, $endDate]);
            if ($overlap->fetch()) {
                jsonResponse(false, 'An open pay period already overlaps with these dates.');
            }

            $pdo->prepare("INSERT INTO pay_periods (period_name, start_date, end_date, pay_date, status, created_by) VALUES (?,?,?,?,'open',?)")
                ->execute([$name, $startDate, $endDate, $payDate, $user['id']]);
            auditLog('CREATE_PAY_PERIOD', 'pay_periods', (int)$pdo->lastInsertId());
            jsonResponse(true, "Pay period \"{$name}\" created successfully.");
        } catch (PDOException $e) {
            jsonResponse(false, 'Failed to create pay period.');
        }
    }

    // ── Create Announcement ───────────────────────────────────────────────────
    if ($action === 'create_announcement') {
        $title   = sanitize($_POST['ann_title']   ?? '');
        $content = sanitize($_POST['ann_content'] ?? '');
        $type    = $_POST['ann_type'] ?? 'info';

        if (!$title || !$content) jsonResponse(false, 'Title and content are required.');
        if (!in_array($type, ['info','warning','success','danger'])) $type = 'info';

        try {
            $pdo->prepare("INSERT INTO announcements (title, content, type, is_active, created_by) VALUES (?,?,?,1,?)")
                ->execute([$title, $content, $type, $user['id']]);
            auditLog('CREATE_ANNOUNCEMENT', 'announcements', (int)$pdo->lastInsertId());
            jsonResponse(true, 'Announcement posted successfully.');
        } catch (PDOException $e) {
            jsonResponse(false, 'Failed to create announcement.');
        }
    }

    // ── Delete Employee ───────────────────────────────────────────────────────
    if ($action === 'terminate_employee') {
        $empId = (int)($_POST['emp_id'] ?? 0);
        if ($empId === $user['id']) jsonResponse(false, 'You cannot terminate your own account.');
        try {
            $pdo->prepare("UPDATE users SET status='terminated' WHERE id=?")
                ->execute([$empId]);
            auditLog('TERMINATE_EMPLOYEE', 'users', $empId);
            jsonResponse(true, 'Employee terminated successfully.');
        } catch (PDOException $e) {
            jsonResponse(false, 'Operation failed.');
        }
    }
}

// ─── Fetch Dashboard Data ─────────────────────────────────────────────────────

// KPI Stats
$totalEmployees = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE status='active' AND role='employee'")->fetchColumn();
$totalDepts     = (int)$pdo->query("SELECT COUNT(*) FROM departments")->fetchColumn();

// Monthly payroll total (last closed period)
$lastPayroll = $pdo->query("SELECT SUM(pr.gross_pay) as total, SUM(pr.net_pay) as net
    FROM payroll_records pr
    JOIN pay_periods pp ON pr.pay_period_id = pp.id
    WHERE pp.status='closed'
    ORDER BY pp.end_date DESC LIMIT 1")->fetch();
$monthlyPayroll = $lastPayroll ? (float)$lastPayroll['total'] : 0;

// Current open period
$openPeriod = $pdo->query("SELECT * FROM pay_periods WHERE status='open' ORDER BY id DESC LIMIT 1")->fetch();

// Pending leaves
$pendingLeaves = (int)$pdo->query("SELECT COUNT(*) FROM leave_requests WHERE status='pending'")->fetchColumn();

// Recent employees
$recentEmployees = $pdo->query("SELECT u.*, d.name as dept_name, ss.base_salary
    FROM users u
    LEFT JOIN departments d ON u.department_id = d.id
    LEFT JOIN salary_structures ss ON ss.user_id = u.id
    WHERE u.role='employee' AND u.status='active'
    ORDER BY u.created_at DESC LIMIT 10")->fetchAll();

// Deduplicate by user (latest salary)
$seen = []; $empList = [];
foreach ($recentEmployees as $e) {
    if (!isset($seen[$e['id']])) { $seen[$e['id']] = true; $empList[] = $e; }
}

// All employees for management table
$allEmployees = $pdo->query("SELECT u.*, d.name as dept_name, ss.base_salary
    FROM users u
    LEFT JOIN departments d ON u.department_id = d.id
    LEFT JOIN salary_structures ss ON ss.user_id = u.id
    WHERE u.role='employee'
    ORDER BY u.status ASC, u.first_name ASC")->fetchAll();
$seen2 = []; $allEmpList = [];
foreach ($allEmployees as $e) {
    if (!isset($seen2[$e['id']])) { $seen2[$e['id']] = true; $allEmpList[] = $e; }
}

// Department breakdown
$deptStats = $pdo->query("SELECT d.name, d.budget, 
    COUNT(u.id) as emp_count,
    COALESCE(SUM(ss.base_salary/12), 0) as monthly_cost
    FROM departments d
    LEFT JOIN users u ON u.department_id = d.id AND u.status='active'
    LEFT JOIN salary_structures ss ON ss.user_id = u.id
    GROUP BY d.id
    ORDER BY monthly_cost DESC")->fetchAll();

// Monthly payroll trend (last 6 periods)
$trendData = $pdo->query("SELECT pp.period_name, pp.pay_date,
    SUM(pr.gross_pay) as total_gross,
    SUM(pr.net_pay) as total_net,
    COUNT(pr.id) as emp_count
    FROM pay_periods pp
    LEFT JOIN payroll_records pr ON pr.pay_period_id = pp.id
    WHERE pp.status='closed'
    GROUP BY pp.id
    ORDER BY pp.pay_date DESC LIMIT 6")->fetchAll();
$trendData = array_reverse($trendData);

// Leave requests pending
$leaveRequests = $pdo->query("SELECT lr.*, 
    CONCAT(u.first_name,' ',u.last_name) as employee_name,
    u.employee_id, d.name as dept_name
    FROM leave_requests lr
    JOIN users u ON lr.user_id = u.id
    LEFT JOIN departments d ON u.department_id = d.id
    ORDER BY FIELD(lr.status,'pending','approved','rejected'), lr.created_at DESC
    LIMIT 20")->fetchAll();

// Pay periods list
$payPeriods = $pdo->query("SELECT pp.*,
    COUNT(pr.id) as records_count,
    COALESCE(SUM(pr.gross_pay),0) as total_gross,
    COALESCE(SUM(pr.net_pay),0) as total_net
    FROM pay_periods pp
    LEFT JOIN payroll_records pr ON pr.pay_period_id = pp.id
    GROUP BY pp.id ORDER BY pp.start_date DESC")->fetchAll();

// Announcements
$announcements = $pdo->query("SELECT * FROM announcements WHERE is_active=1 ORDER BY created_at DESC LIMIT 5")->fetchAll();

// Audit log
$auditLog = $pdo->query("SELECT al.*, CONCAT(u.first_name,' ',u.last_name) as user_name
    FROM audit_log al
    LEFT JOIN users u ON al.user_id = u.id
    ORDER BY al.created_at DESC LIMIT 20")->fetchAll();

// Departments for add employee form
$departments = $pdo->query("SELECT id, name FROM departments ORDER BY name")->fetchAll();

// Chart: salary distribution by department
$chartLabels = array_column($deptStats, 'name');
$chartData   = array_map(fn($d) => round((float)$d['monthly_cost'], 2), $deptStats);

// Chart: trend
$trendLabels     = array_column($trendData, 'period_name');
$trendGross      = array_map(fn($d) => round((float)$d['total_gross'], 2), $trendData);
$trendNet        = array_map(fn($d) => round((float)$d['total_net'], 2), $trendData);

$csrf = generateCSRF();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard — <?= APP_NAME ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body class="dashboard-body">

<!-- ── Sidebar ──────────────────────────────────────────────────────────────── -->
<div class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="sidebar-brand">
            <i class="fa-solid fa-building-columns"></i>
            <span><?= APP_NAME ?></span>
        </div>
        <button class="sidebar-close d-xl-none" onclick="toggleSidebar()">
            <i class="fa-solid fa-xmark"></i>
        </button>
    </div>

    <div class="sidebar-user">
        <div class="sidebar-avatar">
            <?= strtoupper(substr($user['first_name'],0,1) . substr($user['last_name'],0,1)) ?>
        </div>
        <div>
            <div class="sidebar-user-name"><?= htmlspecialchars($user['first_name'].' '.$user['last_name']) ?></div>
            <div class="sidebar-user-role"><span class="badge-admin">Administrator</span></div>
        </div>
    </div>

    <nav class="sidebar-nav">
        <div class="sidebar-section-label">Overview</div>
        <a href="#" class="sidebar-link active" data-tab="dashboard">
            <i class="fa-solid fa-gauge-high"></i><span>Dashboard</span>
        </a>
        <a href="#" class="sidebar-link" data-tab="analytics">
            <i class="fa-solid fa-chart-mixed"></i><span>Analytics</span>
        </a>

        <div class="sidebar-section-label">Payroll</div>
        <a href="#" class="sidebar-link" data-tab="payroll">
            <i class="fa-solid fa-money-bill-wave"></i><span>Payroll Processing</span>
        </a>
        <a href="#" class="sidebar-link" data-tab="periods">
            <i class="fa-solid fa-calendar-days"></i><span>Pay Periods</span>
        </a>

        <div class="sidebar-section-label">People</div>
        <a href="#" class="sidebar-link" data-tab="employees">
            <i class="fa-solid fa-users"></i><span>Employees</span>
            <span class="sidebar-badge"><?= $totalEmployees ?></span>
        </a>
        <a href="#" class="sidebar-link" data-tab="leaves">
            <i class="fa-solid fa-umbrella-beach"></i><span>Leave Requests</span>
            <?php if ($pendingLeaves > 0): ?>
            <span class="sidebar-badge sidebar-badge-warning"><?= $pendingLeaves ?></span>
            <?php endif; ?>
        </a>

        <div class="sidebar-section-label">System</div>
        <a href="#" class="sidebar-link" data-tab="audit">
            <i class="fa-solid fa-shield-halved"></i><span>Audit Log</span>
        </a>
        <a href="#" class="sidebar-link" data-tab="announcements">
            <i class="fa-solid fa-bullhorn"></i><span>Announcements</span>
        </a>

        <div class="sidebar-footer">
            <a href="logout.php" class="sidebar-link sidebar-logout">
                <i class="fa-solid fa-right-from-bracket"></i><span>Sign Out</span>
            </a>
        </div>
    </nav>
</div>

<!-- ── Main Content ──────────────────────────────────────────────────────────── -->
<div class="main-wrapper" id="mainWrapper">

    <!-- Top Bar -->
    <div class="topbar">
        <button class="topbar-toggle" onclick="toggleSidebar()">
            <i class="fa-solid fa-bars"></i>
        </button>
        <div class="topbar-breadcrumb">
            <span id="breadcrumb-text">Dashboard</span>
        </div>
        <div class="topbar-actions">
            <div class="topbar-date">
                <i class="fa-regular fa-calendar me-1"></i>
                <?= date('l, F j, Y') ?>
            </div>
            <?php if ($openPeriod): ?>
            <span class="period-chip">
                <i class="fa-solid fa-circle-dot pulse-dot me-1"></i>
                <?= htmlspecialchars($openPeriod['period_name']) ?> Open
            </span>
            <?php endif; ?>
        </div>
    </div>

    <div class="main-content">

        <!-- ════════════════════════════════════════════
             TAB: DASHBOARD
        ════════════════════════════════════════════ -->
        <div class="tab-content-panel active" id="tab-dashboard">
            <!-- Announcements Banner -->
            <?php foreach (array_slice($announcements, 0, 1) as $ann): ?>
            <div class="announcement-banner announcement-<?= $ann['type'] ?> mb-4">
                <i class="fa-solid fa-<?= $ann['type']==='warning'?'triangle-exclamation':($ann['type']==='success'?'circle-check':'circle-info') ?> me-2"></i>
                <strong><?= htmlspecialchars($ann['title']) ?></strong>
                — <?= htmlspecialchars($ann['content']) ?>
                <button class="announcement-close" onclick="this.parentElement.remove()">×</button>
            </div>
            <?php endforeach; ?>

            <!-- KPI Cards -->
            <div class="row g-4 mb-4">
                <div class="col-xl-3 col-md-6">
                    <div class="kpi-card kpi-blue">
                        <div class="kpi-icon"><i class="fa-solid fa-users"></i></div>
                        <div class="kpi-value"><?= number_format($totalEmployees) ?></div>
                        <div class="kpi-label">Active Employees</div>
                        <div class="kpi-sub"><i class="fa-solid fa-building me-1"></i><?= $totalDepts ?> Departments</div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="kpi-card kpi-emerald">
                        <div class="kpi-icon"><i class="fa-solid fa-sack-dollar"></i></div>
                        <div class="kpi-value"><?= money($monthlyPayroll) ?></div>
                        <div class="kpi-label">Last Gross Payroll</div>
                        <div class="kpi-sub"><i class="fa-solid fa-calendar-check me-1"></i>Most Recent Period</div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="kpi-card kpi-amber">
                        <div class="kpi-icon"><i class="fa-solid fa-hourglass-half"></i></div>
                        <div class="kpi-value"><?= $pendingLeaves ?></div>
                        <div class="kpi-label">Pending Leave Requests</div>
                        <div class="kpi-sub">
                            <a href="#" onclick="showTab('leaves')" class="kpi-action">Review now →</a>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="kpi-card kpi-violet">
                        <div class="kpi-icon"><i class="fa-solid fa-file-invoice-dollar"></i></div>
                        <div class="kpi-value"><?= $openPeriod ? htmlspecialchars($openPeriod['period_name']) : 'None' ?></div>
                        <div class="kpi-label">Current Pay Period</div>
                        <div class="kpi-sub">
                            <?php if ($openPeriod): ?>
                            <span class="badge-status badge-open">Open</span>
                            Pay date: <?= date('M j', strtotime($openPeriod['pay_date'])) ?>
                            <?php else: ?>
                            <span class="badge-status badge-closed">No Open Period</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Charts Row -->
            <div class="row g-4 mb-4">
                <div class="col-xl-8">
                    <div class="dash-card">
                        <div class="dash-card-header">
                            <h3 class="dash-card-title">
                                <i class="fa-solid fa-chart-area me-2"></i>Payroll Trend
                            </h3>
                            <span class="dash-card-meta">Last 6 Pay Periods</span>
                        </div>
                        <div class="chart-wrap" style="height:300px">
                            <canvas id="trendChart"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4">
                    <div class="dash-card">
                        <div class="dash-card-header">
                            <h3 class="dash-card-title">
                                <i class="fa-solid fa-chart-pie me-2"></i>Dept. Cost
                            </h3>
                            <span class="dash-card-meta">Monthly</span>
                        </div>
                        <div class="chart-wrap" style="height:300px">
                            <canvas id="deptChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Department Table -->
            <div class="dash-card mb-4">
                <div class="dash-card-header">
                    <h3 class="dash-card-title">
                        <i class="fa-solid fa-building me-2"></i>Department Overview
                    </h3>
                    <button class="btn-dash-sm" onclick="showTab('employees')">
                        <i class="fa-solid fa-plus me-1"></i>Add Employee
                    </button>
                </div>
                <div class="table-responsive">
                    <table class="dash-table">
                        <thead>
                            <tr>
                                <th>Department</th>
                                <th>Employees</th>
                                <th>Monthly Cost</th>
                                <th>Annual Budget</th>
                                <th>Budget Usage</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($deptStats as $dept): 
                                $usage = $dept['budget'] > 0 ? (($dept['monthly_cost'] * 12) / $dept['budget'] * 100) : 0;
                            ?>
                            <tr>
                                <td class="fw-600"><?= htmlspecialchars($dept['name']) ?></td>
                                <td><?= $dept['emp_count'] ?></td>
                                <td><?= money((float)$dept['monthly_cost']) ?></td>
                                <td><?= money((float)$dept['budget']) ?></td>
                                <td>
                                    <div class="progress-mini">
                                        <div class="progress-mini-fill <?= $usage > 90 ? 'danger' : ($usage > 70 ? 'warning' : '') ?>"
                                             style="width:<?= min($usage, 100) ?>%"></div>
                                    </div>
                                    <small><?= number_format($usage, 1) ?>%</small>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ════════════════════════════════════════════
             TAB: ANALYTICS
        ════════════════════════════════════════════ -->
        <div class="tab-content-panel" id="tab-analytics">
            <div class="row g-4 mb-4">
                <div class="col-md-4">
                    <div class="kpi-card kpi-blue">
                        <div class="kpi-icon"><i class="fa-solid fa-coins"></i></div>
                        <div class="kpi-value"><?= money(array_sum(array_column($trendData, 'total_gross'))) ?></div>
                        <div class="kpi-label">6-Month Total Gross</div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="kpi-card kpi-emerald">
                        <div class="kpi-icon"><i class="fa-solid fa-hand-holding-dollar"></i></div>
                        <div class="kpi-value"><?= money(array_sum(array_column($trendData, 'total_net'))) ?></div>
                        <div class="kpi-label">6-Month Total Net Pay</div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="kpi-card kpi-amber">
                        <div class="kpi-icon"><i class="fa-solid fa-percent"></i></div>
                        <?php
                        $gross6 = array_sum(array_column($trendData, 'total_gross'));
                        $net6   = array_sum(array_column($trendData, 'total_net'));
                        $deducPct = $gross6 > 0 ? round((($gross6 - $net6) / $gross6) * 100, 1) : 0;
                        ?>
                        <div class="kpi-value"><?= $deducPct ?>%</div>
                        <div class="kpi-label">Avg. Deductions Rate</div>
                    </div>
                </div>
            </div>

            <div class="row g-4 mb-4">
                <div class="col-xl-6">
                    <div class="dash-card">
                        <div class="dash-card-header">
                            <h3 class="dash-card-title"><i class="fa-solid fa-chart-bar me-2"></i>Department Headcount</h3>
                        </div>
                        <div class="chart-wrap" style="height:280px">
                            <canvas id="headcountChart"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6">
                    <div class="dash-card">
                        <div class="dash-card-header">
                            <h3 class="dash-card-title"><i class="fa-solid fa-chart-line me-2"></i>Net vs Gross Pay</h3>
                        </div>
                        <div class="chart-wrap" style="height:280px">
                            <canvas id="netGrossChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Payroll Records Summary Table -->
            <div class="dash-card">
                <div class="dash-card-header">
                    <h3 class="dash-card-title"><i class="fa-solid fa-table me-2"></i>Period-by-Period Summary</h3>
                </div>
                <div class="table-responsive">
                    <table class="dash-table">
                        <thead>
                            <tr><th>Period</th><th>Employees Paid</th><th>Total Gross</th><th>Total Deductions</th><th>Total Net</th><th>Status</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach (array_reverse($payPeriods) as $pp): ?>
                            <tr>
                                <td class="fw-600"><?= htmlspecialchars($pp['period_name']) ?></td>
                                <td><?= (int)$pp['records_count'] ?></td>
                                <td><?= money((float)$pp['total_gross']) ?></td>
                                <td><?= money(max(0, (float)$pp['total_gross'] - (float)$pp['total_net'])) ?></td>
                                <td><?= money((float)$pp['total_net']) ?></td>
                                <td><span class="badge-status badge-<?= $pp['status'] ?>"><?= ucfirst($pp['status']) ?></span></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ════════════════════════════════════════════
             TAB: PAYROLL PROCESSING
        ════════════════════════════════════════════ -->
        <div class="tab-content-panel" id="tab-payroll">
            <div class="dash-card mb-4">
                <div class="dash-card-header">
                    <h3 class="dash-card-title"><i class="fa-solid fa-gears me-2"></i>Process Payroll</h3>
                </div>

                <?php if ($openPeriod): ?>
                <div class="payroll-process-card">
                    <div class="payroll-period-info">
                        <div class="pp-label">Current Open Period</div>
                        <div class="pp-name"><?= htmlspecialchars($openPeriod['period_name']) ?></div>
                        <div class="pp-dates">
                            <?= date('M j', strtotime($openPeriod['start_date'])) ?> —
                            <?= date('M j, Y', strtotime($openPeriod['end_date'])) ?>
                        </div>
                        <div class="pp-pay-date">
                            <i class="fa-solid fa-calendar-check me-1"></i>
                            Pay Date: <?= date('F j, Y', strtotime($openPeriod['pay_date'])) ?>
                        </div>
                    </div>
                    <div class="payroll-actions">
                        <button class="btn-process" onclick="processPayroll(<?= $openPeriod['id'] ?>)">
                            <i class="fa-solid fa-play-circle me-2"></i>Run Payroll for All Employees
                        </button>
                        <button class="btn-close-period" onclick="closePeriod(<?= $openPeriod['id'] ?>)">
                            <i class="fa-solid fa-lock me-2"></i>Close Period & Mark Paid
                        </button>
                    </div>
                </div>
                <?php else: ?>
                <div class="empty-state">
                    <i class="fa-solid fa-calendar-xmark"></i>
                    <p>No open pay period. All periods are closed.</p>
                </div>
                <?php endif; ?>
            </div>

            <!-- Recent Payroll Records Table -->
            <div class="dash-card">
                <div class="dash-card-header">
                    <h3 class="dash-card-title"><i class="fa-solid fa-receipt me-2"></i>Recent Payroll Records</h3>
                    <input type="text" class="search-input" id="payrollSearch" placeholder="Search employee..." oninput="filterTable('payrollTable', this.value)">
                </div>
                <div class="table-responsive">
                    <table class="dash-table" id="payrollTable">
                        <thead>
                            <tr>
                                <th>Employee</th>
                                <th>Department</th>
                                <th>Period</th>
                                <th>Gross Pay</th>
                                <th>Deductions</th>
                                <th>Net Pay</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $allRecords = $pdo->query("SELECT pr.*, 
                                CONCAT(u.first_name,' ',u.last_name) as emp_name,
                                u.employee_id, d.name as dept_name, pp.period_name
                                FROM payroll_records pr
                                JOIN users u ON pr.user_id = u.id
                                LEFT JOIN departments d ON u.department_id = d.id
                                JOIN pay_periods pp ON pr.pay_period_id = pp.id
                                ORDER BY pr.created_at DESC LIMIT 50")->fetchAll();
                            foreach ($allRecords as $rec):
                            ?>
                            <tr>
                                <td>
                                    <div class="emp-cell">
                                        <div class="emp-avatar-sm"><?= strtoupper(substr($rec['emp_name'],0,2)) ?></div>
                                        <div>
                                            <div class="fw-600"><?= htmlspecialchars($rec['emp_name']) ?></div>
                                            <small class="text-muted"><?= $rec['employee_id'] ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td><?= htmlspecialchars($rec['dept_name'] ?? '—') ?></td>
                                <td><?= htmlspecialchars($rec['period_name']) ?></td>
                                <td class="fw-600"><?= money((float)$rec['gross_pay']) ?></td>
                                <td class="text-danger">-<?= money((float)$rec['total_deductions']) ?></td>
                                <td class="text-success fw-600"><?= money((float)$rec['net_pay']) ?></td>
                                <td><span class="badge-status badge-<?= $rec['status'] ?>"><?= ucfirst($rec['status']) ?></span></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ════════════════════════════════════════════
             TAB: PAY PERIODS
        ════════════════════════════════════════════ -->
        <div class="tab-content-panel" id="tab-periods">
            <div class="dash-card">
                <div class="dash-card-header">
                    <h3 class="dash-card-title"><i class="fa-solid fa-calendar-days me-2"></i>Pay Periods</h3>
                    <button class="btn-dash-sm" onclick="document.getElementById('addPeriodModal').classList.add('modal-show')">
                        <i class="fa-solid fa-plus me-1"></i>New Pay Period
                    </button>
                </div>
                <div class="table-responsive">
                    <table class="dash-table">
                        <thead>
                            <tr>
                                <th>Period</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>Pay Date</th>
                                <th>Employees</th>
                                <th>Total Gross</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($payPeriods as $pp): ?>
                            <tr>
                                <td class="fw-600"><?= htmlspecialchars($pp['period_name']) ?></td>
                                <td><?= date('M j, Y', strtotime($pp['start_date'])) ?></td>
                                <td><?= date('M j, Y', strtotime($pp['end_date'])) ?></td>
                                <td><?= date('M j, Y', strtotime($pp['pay_date'])) ?></td>
                                <td><?= (int)$pp['records_count'] ?></td>
                                <td><?= money((float)$pp['total_gross']) ?></td>
                                <td><span class="badge-status badge-<?= $pp['status'] ?>"><?= ucfirst($pp['status']) ?></span></td>
                                <td>
                                    <?php if ($pp['status'] === 'open'): ?>
                                    <button class="btn-action-sm btn-process-sm" onclick="processPayroll(<?= $pp['id'] ?>)">
                                        <i class="fa-solid fa-play"></i> Run
                                    </button>
                                    <?php elseif ($pp['status'] === 'processing'): ?>
                                    <button class="btn-action-sm btn-close-sm" onclick="closePeriod(<?= $pp['id'] ?>)">
                                        <i class="fa-solid fa-lock"></i> Close
                                    </button>
                                    <?php else: ?>
                                    <span class="text-muted">—</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ════════════════════════════════════════════
             TAB: EMPLOYEES
        ════════════════════════════════════════════ -->
        <div class="tab-content-panel" id="tab-employees">
            <div class="dash-card mb-4">
                <div class="dash-card-header">
                    <h3 class="dash-card-title"><i class="fa-solid fa-users me-2"></i>Employee Management</h3>
                    <button class="btn-dash-sm" onclick="document.getElementById('addEmpModal').classList.add('modal-show')">
                        <i class="fa-solid fa-plus me-1"></i>Add Employee
                    </button>
                </div>
                <input type="text" class="search-input mb-3" id="empSearch" placeholder="Search by name, ID, department..." oninput="filterTable('empTable', this.value)">
                <div class="table-responsive">
                    <table class="dash-table" id="empTable">
                        <thead>
                            <tr>
                                <th>Employee</th>
                                <th>ID</th>
                                <th>Department</th>
                                <th>Title</th>
                                <th>Type</th>
                                <th>Base Salary</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($allEmpList as $emp): ?>
                            <tr>
                                <td>
                                    <div class="emp-cell">
                                        <div class="emp-avatar-sm"><?= strtoupper(substr($emp['first_name'],0,1).substr($emp['last_name'],0,1)) ?></div>
                                        <div>
                                            <div class="fw-600"><?= htmlspecialchars($emp['first_name'].' '.$emp['last_name']) ?></div>
                                            <small class="text-muted"><?= htmlspecialchars($emp['email']) ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td><code class="emp-id"><?= $emp['employee_id'] ?></code></td>
                                <td><?= htmlspecialchars($emp['dept_name'] ?? '—') ?></td>
                                <td><?= htmlspecialchars($emp['job_title'] ?? '—') ?></td>
                                <td><?= ucfirst(str_replace('_',' ',$emp['employment_type'])) ?></td>
                                <td class="fw-600"><?= $emp['base_salary'] ? money((float)$emp['base_salary']) : '—' ?></td>
                                <td><span class="badge-status badge-<?= $emp['status'] ?>"><?= ucfirst($emp['status']) ?></span></td>
                                <td>
                                    <?php if ($emp['status'] === 'active'): ?>
                                    <button class="btn-action-sm btn-danger-sm"
                                        onclick="if(confirm('Terminate <?= htmlspecialchars(addslashes($emp['first_name'])) ?>?')) terminateEmployee(<?= $emp['id'] ?>)">
                                        <i class="fa-solid fa-user-slash"></i>
                                    </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ════════════════════════════════════════════
             TAB: LEAVE REQUESTS
        ════════════════════════════════════════════ -->
        <div class="tab-content-panel" id="tab-leaves">
            <div class="dash-card">
                <div class="dash-card-header">
                    <h3 class="dash-card-title"><i class="fa-solid fa-umbrella-beach me-2"></i>Leave Requests</h3>
                    <?php if ($pendingLeaves > 0): ?>
                    <span class="badge-pending-count"><?= $pendingLeaves ?> Pending</span>
                    <?php endif; ?>
                </div>
                <div class="table-responsive">
                    <table class="dash-table">
                        <thead>
                            <tr>
                                <th>Employee</th>
                                <th>Type</th>
                                <th>Dates</th>
                                <th>Days</th>
                                <th>Reason</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($leaveRequests as $lr): ?>
                            <tr>
                                <td>
                                    <div class="emp-cell">
                                        <div class="emp-avatar-sm"><?= strtoupper(substr($lr['employee_name'],0,2)) ?></div>
                                        <div>
                                            <div class="fw-600"><?= htmlspecialchars($lr['employee_name']) ?></div>
                                            <small class="text-muted"><?= $lr['dept_name'] ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td><span class="badge-leave badge-<?= $lr['leave_type'] ?>"><?= ucfirst($lr['leave_type']) ?></span></td>
                                <td><?= date('M j', strtotime($lr['start_date'])) ?> — <?= date('M j, Y', strtotime($lr['end_date'])) ?></td>
                                <td><?= $lr['days_requested'] ?></td>
                                <td><?= htmlspecialchars(substr($lr['reason'] ?? '—', 0, 40)) ?></td>
                                <td><span class="badge-status badge-<?= $lr['status'] ?>"><?= ucfirst($lr['status']) ?></span></td>
                                <td>
                                    <?php if ($lr['status'] === 'pending'): ?>
                                    <button class="btn-action-sm btn-approve-sm" onclick="reviewLeave(<?= $lr['id'] ?>, 'approved')">
                                        <i class="fa-solid fa-check"></i>
                                    </button>
                                    <button class="btn-action-sm btn-danger-sm" onclick="reviewLeave(<?= $lr['id'] ?>, 'rejected')">
                                        <i class="fa-solid fa-xmark"></i>
                                    </button>
                                    <?php else: ?>
                                    <span class="text-muted">—</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ════════════════════════════════════════════
             TAB: AUDIT LOG
        ════════════════════════════════════════════ -->
        <div class="tab-content-panel" id="tab-audit">
            <div class="dash-card">
                <div class="dash-card-header">
                    <h3 class="dash-card-title"><i class="fa-solid fa-shield-halved me-2"></i>Audit Trail</h3>
                </div>
                <div class="table-responsive">
                    <table class="dash-table">
                        <thead>
                            <tr><th>Time</th><th>User</th><th>Action</th><th>Table</th><th>Record ID</th><th>IP Address</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach ($auditLog as $log): ?>
                            <tr>
                                <td><?= timeAgo($log['created_at']) ?></td>
                                <td><?= htmlspecialchars($log['user_name'] ?? 'System') ?></td>
                                <td><code class="action-code"><?= htmlspecialchars($log['action']) ?></code></td>
                                <td><?= htmlspecialchars($log['table_name'] ?? '—') ?></td>
                                <td><?= $log['record_id'] ?: '—' ?></td>
                                <td><code><?= htmlspecialchars($log['ip_address'] ?? '—') ?></code></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ════════════════════════════════════════════
             TAB: ANNOUNCEMENTS
        ════════════════════════════════════════════ -->
        <div class="tab-content-panel" id="tab-announcements">
            <!-- Create Announcement Form -->
            <div class="dash-card mb-4">
                <div class="dash-card-header">
                    <h3 class="dash-card-title"><i class="fa-solid fa-plus me-2"></i>Post Announcement</h3>
                </div>
                <form id="annForm" onsubmit="submitAnnouncement(event)">
                    <div class="row g-3">
                        <div class="col-md-8">
                            <label class="form-label-glass">Title *</label>
                            <input type="text" name="ann_title" class="form-control-glass" required placeholder="Announcement title...">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label-glass">Type</label>
                            <select name="ann_type" class="form-control-glass">
                                <option value="info">Info</option>
                                <option value="success">Success</option>
                                <option value="warning">Warning</option>
                                <option value="danger">Alert</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label-glass">Content *</label>
                            <textarea name="ann_content" class="form-control-glass" rows="3" required placeholder="Announcement content..."></textarea>
                        </div>
                    </div>
                    <div class="mt-3">
                        <button type="submit" class="btn-glass-primary">
                            <i class="fa-solid fa-bullhorn me-2"></i>Post Announcement
                        </button>
                    </div>
                </form>
            </div>
            <!-- Existing Announcements -->
            <div class="row g-4">
                <?php foreach ($announcements as $ann): ?>
                <div class="col-md-6">
                    <div class="announcement-card announcement-card-<?= $ann['type'] ?>">
                        <div class="ann-icon">
                            <i class="fa-solid fa-<?= $ann['type']==='warning'?'triangle-exclamation':($ann['type']==='success'?'circle-check':'circle-info') ?>"></i>
                        </div>
                        <div class="ann-body">
                            <h4 class="ann-title"><?= htmlspecialchars($ann['title']) ?></h4>
                            <p class="ann-content"><?= htmlspecialchars($ann['content']) ?></p>
                            <small class="ann-date"><?= timeAgo($ann['created_at']) ?></small>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

    </div><!-- /main-content -->
</div><!-- /main-wrapper -->

<!-- ── Create Pay Period Modal ──────────────────────────────────────────────── -->
<div class="modal-overlay" id="addPeriodModal">
    <div class="modal-glass">
        <div class="modal-glass-header">
            <h3><i class="fa-solid fa-calendar-plus me-2"></i>New Pay Period</h3>
            <button class="modal-close-btn" onclick="document.getElementById('addPeriodModal').classList.remove('modal-show')">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
        <form id="addPeriodForm" onsubmit="submitCreatePeriod(event)">
            <div class="row g-3">
                <div class="col-12">
                    <label class="form-label-glass">Period Name *</label>
                    <input type="text" name="period_name" class="form-control-glass" required placeholder="e.g. May 2026">
                </div>
                <div class="col-md-6">
                    <label class="form-label-glass">Start Date *</label>
                    <input type="date" name="start_date" id="periodStart" class="form-control-glass" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label-glass">End Date *</label>
                    <input type="date" name="end_date" id="periodEnd" class="form-control-glass" required>
                </div>
                <div class="col-12">
                    <label class="form-label-glass">Pay Date *</label>
                    <input type="date" name="pay_date" id="periodPay" class="form-control-glass" required>
                </div>
            </div>
            <div class="modal-footer-btns mt-4">
                <button type="button" class="btn-glass-secondary" onclick="document.getElementById('addPeriodModal').classList.remove('modal-show')">Cancel</button>
                <button type="submit" class="btn-glass-primary">
                    <i class="fa-solid fa-calendar-plus me-2"></i>Create Period
                </button>
            </div>
        </form>
    </div>
</div>

<!-- ── Add Employee Modal ─────────────────────────────────────────────────── -->
<div class="modal-overlay" id="addEmpModal">
    <div class="modal-glass">
        <div class="modal-glass-header">
            <h3><i class="fa-solid fa-user-plus me-2"></i>Add New Employee</h3>
            <button class="modal-close-btn" onclick="document.getElementById('addEmpModal').classList.remove('modal-show')">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
        <form id="addEmpForm" onsubmit="submitAddEmployee(event)">
            <div class="row g-3">
                <div class="col-6">
                    <label class="form-label-glass">First Name *</label>
                    <input type="text" name="first_name" class="form-control-glass" required placeholder="John">
                </div>
                <div class="col-6">
                    <label class="form-label-glass">Last Name *</label>
                    <input type="text" name="last_name" class="form-control-glass" required placeholder="Doe">
                </div>
                <div class="col-12">
                    <label class="form-label-glass">Work Email *</label>
                    <input type="email" name="email" class="form-control-glass" required placeholder="john.doe@company.com">
                </div>
                <div class="col-md-6">
                    <label class="form-label-glass">Department</label>
                    <select name="department_id" class="form-control-glass">
                        <option value="">— Unassigned —</option>
                        <?php foreach ($departments as $d): ?>
                        <option value="<?= $d['id'] ?>"><?= htmlspecialchars($d['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label-glass">Job Title</label>
                    <input type="text" name="job_title" class="form-control-glass" placeholder="Software Engineer">
                </div>
                <div class="col-md-6">
                    <label class="form-label-glass">Employment Type</label>
                    <select name="employment_type" class="form-control-glass">
                        <option value="full_time">Full Time</option>
                        <option value="part_time">Part Time</option>
                        <option value="contract">Contract</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label-glass">Hire Date</label>
                    <input type="date" name="hire_date" class="form-control-glass" value="<?= date('Y-m-d') ?>">
                </div>
                <div class="col-12">
                    <label class="form-label-glass">Annual Base Salary (USD) *</label>
                    <input type="number" name="base_salary" class="form-control-glass" required min="1" placeholder="85000">
                </div>
            </div>
            <div class="modal-footer-btns mt-4">
                <button type="button" class="btn-glass-secondary" onclick="document.getElementById('addEmpModal').classList.remove('modal-show')">Cancel</button>
                <button type="submit" class="btn-glass-primary">
                    <i class="fa-solid fa-user-plus me-2"></i>Add Employee
                </button>
            </div>
        </form>
    </div>
</div>

<!-- ── Toast Notification ─────────────────────────────────────────────────── -->
<div class="toast-container" id="toastContainer"></div>

<!-- ── Overlay Loader ─────────────────────────────────────────────────────── -->
<div class="loader-overlay" id="loaderOverlay">
    <div class="loader-spinner">
        <div class="spinner-ring"></div>
        <p id="loaderMsg">Processing...</p>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script>
// ─── Data from PHP ────────────────────────────────────────────────────────────
const CSRF = '<?= $csrf ?>';
const chartLabels   = <?= json_encode($chartLabels) ?>;
const chartData     = <?= json_encode($chartData) ?>;
const trendLabels   = <?= json_encode($trendLabels) ?>;
const trendGross    = <?= json_encode($trendGross) ?>;
const trendNet      = <?= json_encode($trendNet) ?>;
const hcLabels      = <?= json_encode(array_column($deptStats,'name')) ?>;
const hcData        = <?= json_encode(array_column($deptStats,'emp_count')) ?>;

// ─── Tab Navigation ───────────────────────────────────────────────────────────
const tabBreadcrumbs = {
    dashboard:'Dashboard', analytics:'Analytics & Reports', payroll:'Payroll Processing',
    periods:'Pay Periods', employees:'Employee Management', leaves:'Leave Requests',
    audit:'Audit Log', announcements:'Announcements'
};

function showTab(tabId) {
    document.querySelectorAll('.tab-content-panel').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.sidebar-link').forEach(l => l.classList.remove('active'));
    const panel = document.getElementById('tab-' + tabId);
    if (panel) panel.classList.add('active');
    const link = document.querySelector(`[data-tab="${tabId}"]`);
    if (link) link.classList.add('active');
    document.getElementById('breadcrumb-text').textContent = tabBreadcrumbs[tabId] || tabId;
    // Close sidebar on mobile
    if (window.innerWidth < 1200) document.getElementById('sidebar').classList.remove('sidebar-open');
}

document.querySelectorAll('.sidebar-link[data-tab]').forEach(link => {
    link.addEventListener('click', e => { e.preventDefault(); showTab(link.dataset.tab); });
});

function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('sidebar-open');
}

// ─── Charts ───────────────────────────────────────────────────────────────────
const chartDefaults = {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { labels: { color:'#94a3b8', font:{size:11} } } },
};

// Trend Chart
new Chart(document.getElementById('trendChart'), {
    type: 'line',
    data: {
        labels: trendLabels,
        datasets: [
            {
                label:'Gross Pay', data: trendGross,
                borderColor:'#3b82f6', backgroundColor:'rgba(59,130,246,.15)',
                fill:true, tension:.4, pointBackgroundColor:'#3b82f6', pointRadius:5
            },
            {
                label:'Net Pay', data: trendNet,
                borderColor:'#00d4a8', backgroundColor:'rgba(0,212,168,.1)',
                fill:true, tension:.4, pointBackgroundColor:'#00d4a8', pointRadius:5
            }
        ]
    },
    options: {
        ...chartDefaults,
        scales: {
            x: { ticks:{color:'#64748b'}, grid:{color:'rgba(255,255,255,.04)'} },
            y: { ticks:{color:'#64748b', callback:v=>'$'+v.toLocaleString()}, grid:{color:'rgba(255,255,255,.04)'} }
        }
    }
});

// Dept Doughnut
new Chart(document.getElementById('deptChart'), {
    type: 'doughnut',
    data: {
        labels: chartLabels,
        datasets: [{
            data: chartData,
            backgroundColor:['#3b82f6','#00d4a8','#f59e0b','#ef4444','#8b5cf6','#ec4899','#14b8a6','#64748b'],
            borderWidth: 0, hoverOffset: 8
        }]
    },
    options: { ...chartDefaults, cutout:'68%' }
});

// Headcount bar
new Chart(document.getElementById('headcountChart'), {
    type: 'bar',
    data: {
        labels: hcLabels,
        datasets: [{
            label:'Employees', data: hcData,
            backgroundColor:'rgba(59,130,246,.7)',
            borderColor:'#3b82f6', borderWidth:1, borderRadius:6
        }]
    },
    options: {
        ...chartDefaults,
        scales: {
            x:{ticks:{color:'#64748b',maxRotation:45},grid:{color:'rgba(255,255,255,.04)'}},
            y:{ticks:{color:'#64748b'},grid:{color:'rgba(255,255,255,.04)'}}
        }
    }
});

// Net vs Gross
new Chart(document.getElementById('netGrossChart'), {
    type: 'bar',
    data: {
        labels: trendLabels,
        datasets: [
            {label:'Gross', data:trendGross, backgroundColor:'rgba(59,130,246,.7)', borderRadius:4},
            {label:'Net',   data:trendNet,   backgroundColor:'rgba(0,212,168,.7)',   borderRadius:4}
        ]
    },
    options: {
        ...chartDefaults,
        scales: {
            x:{ticks:{color:'#64748b'},grid:{color:'rgba(255,255,255,.04)'}},
            y:{ticks:{color:'#64748b',callback:v=>'$'+v.toLocaleString()},grid:{color:'rgba(255,255,255,.04)'}}
        }
    }
});

// ─── API Calls ────────────────────────────────────────────────────────────────
function post(data) {
    data.csrf_token = CSRF;
    return fetch('admin_dashboard.php', {
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body: new URLSearchParams(data)
    }).then(r => r.json());
}

function showLoader(msg='Processing...') {
    document.getElementById('loaderMsg').textContent = msg;
    document.getElementById('loaderOverlay').classList.add('active');
}
function hideLoader() { document.getElementById('loaderOverlay').classList.remove('active'); }

function toast(msg, type='success') {
    const container = document.getElementById('toastContainer');
    const t = document.createElement('div');
    t.className = `toast-item toast-${type}`;
    const icon = type==='success'?'circle-check':type==='error'?'circle-xmark':'circle-info';
    t.innerHTML = `<i class="fa-solid fa-${icon} me-2"></i>${msg}`;
    container.appendChild(t);
    setTimeout(()=>t.classList.add('toast-show'),10);
    setTimeout(()=>{t.classList.remove('toast-show');setTimeout(()=>t.remove(),400);},4000);
}

function processPayroll(periodId) {
    if(!confirm('Run payroll for ALL active employees in this period?')) return;
    showLoader('Processing payroll for all employees...');
    post({action:'process_payroll', period_id:periodId})
        .then(r=>{hideLoader();toast(r.message,r.success?'success':'error');if(r.success)setTimeout(()=>location.reload(),2000);})
        .catch(()=>{hideLoader();toast('Network error','error');});
}

function closePeriod(periodId) {
    if(!confirm('Close this pay period? All approved records will be marked as PAID. This cannot be undone.')) return;
    showLoader('Closing pay period...');
    post({action:'close_period', period_id:periodId})
        .then(r=>{hideLoader();toast(r.message,r.success?'success':'error');if(r.success)setTimeout(()=>location.reload(),2000);})
        .catch(()=>{hideLoader();toast('Network error','error');});
}

function reviewLeave(leaveId, status) {
    const comment = status==='rejected' ? prompt('Reason for rejection (optional):') || '' : '';
    showLoader('Updating leave request...');
    post({action:'review_leave', leave_id:leaveId, status:status, comment:comment})
        .then(r=>{hideLoader();toast(r.message,r.success?'success':'error');if(r.success)setTimeout(()=>location.reload(),1500);})
        .catch(()=>{hideLoader();toast('Network error','error');});
}

function terminateEmployee(empId) {
    showLoader('Terminating employee...');
    post({action:'terminate_employee', emp_id:empId})
        .then(r=>{hideLoader();toast(r.message,r.success?'success':'error');if(r.success)setTimeout(()=>location.reload(),1500);})
        .catch(()=>{hideLoader();toast('Network error','error');});
}

function submitAddEmployee(e) {
    e.preventDefault();
    const form = document.getElementById('addEmpForm');
    const data = Object.fromEntries(new FormData(form).entries());
    data.action = 'add_employee';
    showLoader('Adding employee...');
    post(data).then(r=>{
        hideLoader();
        toast(r.message, r.success?'success':'error');
        if(r.success){
            document.getElementById('addEmpModal').classList.remove('modal-show');
            form.reset();
            setTimeout(()=>location.reload(),2000);
        }
    }).catch(()=>{hideLoader();toast('Network error','error');});
}

// Table filter
function filterTable(tableId, query) {
    const q = query.toLowerCase();
    document.querySelectorAll(`#${tableId} tbody tr`).forEach(row => {
        row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
}

// Close modals on overlay click
document.getElementById('addEmpModal').addEventListener('click', function(e) {
    if(e.target === this) this.classList.remove('modal-show');
});
document.getElementById('addPeriodModal').addEventListener('click', function(e) {
    if(e.target === this) this.classList.remove('modal-show');
});

// Auto-fill period name from start date
document.getElementById('periodStart')?.addEventListener('change', function() {
    const d = new Date(this.value + 'T00:00:00');
    if (!d) return;
    const monthName = d.toLocaleString('default', { month: 'long' });
    const year = d.getFullYear();
    const nameInput = document.querySelector('[name="period_name"]');
    if (nameInput && !nameInput.value) nameInput.value = `${monthName} ${year}`;
    // Auto-set end date to last day of same month
    const endInput = document.getElementById('periodEnd');
    if (endInput && !endInput.value) {
        const lastDay = new Date(year, d.getMonth() + 1, 0);
        endInput.value = lastDay.toISOString().split('T')[0];
    }
    // Auto-set pay date to 5th of next month
    const payInput = document.getElementById('periodPay');
    if (payInput && !payInput.value) {
        const payDay = new Date(year, d.getMonth() + 1, 5);
        payInput.value = payDay.toISOString().split('T')[0];
    }
});

function submitCreatePeriod(e) {
    e.preventDefault();
    const form = document.getElementById('addPeriodForm');
    const data = Object.fromEntries(new FormData(form).entries());
    data.action = 'create_period';
    showLoader('Creating pay period...');
    post(data).then(r => {
        hideLoader();
        toast(r.message, r.success ? 'success' : 'error');
        if (r.success) {
            document.getElementById('addPeriodModal').classList.remove('modal-show');
            form.reset();
            setTimeout(() => location.reload(), 1800);
        }
    }).catch(() => { hideLoader(); toast('Network error', 'error'); });
}

function submitAnnouncement(e) {
    e.preventDefault();
    const form = document.getElementById('annForm');
    const data = Object.fromEntries(new FormData(form).entries());
    data.action = 'create_announcement';
    showLoader('Posting announcement...');
    post(data).then(r => {
        hideLoader();
        toast(r.message, r.success ? 'success' : 'error');
        if (r.success) {
            form.reset();
            setTimeout(() => location.reload(), 1800);
        }
    }).catch(() => { hideLoader(); toast('Network error', 'error'); });
}
</script>
</body>
</html>
