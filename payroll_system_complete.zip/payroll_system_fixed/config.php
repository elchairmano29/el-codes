<?php
/**
 * config.php - Secure Database Configuration
 * Payroll Management System
 */

// ─── Environment & Error Reporting ───────────────────────────────────────────
define('APP_ENV', 'development'); // Change to 'production' on live server

if (APP_ENV === 'development') {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', 0);
    error_reporting(0);
}

// ─── Application Constants ────────────────────────────────────────────────────
define('APP_NAME', 'PayrollPro Enterprise');
define('APP_VERSION', '2.6.0');
define('APP_URL', 'http://localhost/payroll_system');
define('CURRENCY_SYMBOL', '$');
define('CURRENCY_CODE', 'USD');
define('TAX_YEAR', 2026);

// ─── Session Configuration ────────────────────────────────────────────────────
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Lax');
    session_name('PAYROLL_SESSION');
    session_start();
}

// ─── Database Credentials ────────────────────────────────────────────────────
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'payroll_db');
define('DB_USER', 'root');
define('DB_PASS', ''); // Default XAMPP has no password
define('DB_CHARSET', 'utf8mb4');

// ─── PDO Connection (Singleton Pattern) ──────────────────────────────────────
class Database {
    private static ?PDO $instance = null;

    public static function getInstance(): PDO {
        if (self::$instance === null) {
            $dsn = sprintf(
                'mysql:host=%s;port=%s;dbname=%s;charset=%s',
                DB_HOST, DB_PORT, DB_NAME, DB_CHARSET
            );
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci",
            ];
            try {
                self::$instance = new PDO($dsn, DB_USER, DB_PASS, $options);
            } catch (PDOException $e) {
                self::handleConnectionError($e);
            }
        }
        return self::$instance;
    }

    private static function handleConnectionError(PDOException $e): void {
        if (APP_ENV === 'development') {
            $msg = htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
        } else {
            $msg = 'A database connection error occurred. Please contact support.';
        }
        http_response_code(503);
        echo '<!DOCTYPE html><html><head><meta charset="UTF-8">
        <title>Database Error - ' . APP_NAME . '</title>
        <style>
            body{font-family:system-ui;background:#0a0f1e;color:#fff;display:flex;
            align-items:center;justify-content:center;min-height:100vh;margin:0}
            .box{background:#111827;border:1px solid #ef4444;border-radius:12px;
            padding:40px;max-width:500px;text-align:center}
            h1{color:#ef4444;font-size:1.4rem;margin-bottom:12px}
            p{color:#9ca3af;font-size:.9rem;line-height:1.6}
            code{background:#1f2937;padding:8px 12px;border-radius:6px;
            display:block;margin-top:16px;text-align:left;font-size:.8rem;color:#fbbf24}
        </style></head><body>
        <div class="box">
            <h1>⚠ Database Connection Failed</h1>
            <p>The system could not connect to the MySQL database.</p>
            <code>' . $msg . '</code>
            <p style="margin-top:16px">Ensure XAMPP MySQL is running and <strong>payroll_db</strong> exists.</p>
        </div></body></html>';
        exit();
    }

    private function __construct() {}
    private function __clone() {}
}

// ─── Helper: Get PDO instance shorthand ──────────────────────────────────────
function getPDO(): PDO {
    return Database::getInstance();
}

// ─── Security Helper Functions ────────────────────────────────────────────────
function sanitize(string $input): string {
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}

function validateCSRF(): void {
    if (!isset($_POST['csrf_token']) || !isset($_SESSION['csrf_token'])
        || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        http_response_code(403);
        die(json_encode(['success' => false, 'message' => 'Invalid security token.']));
    }
}

function generateCSRF(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// ─── Authentication Helpers ───────────────────────────────────────────────────
function isLoggedIn(): bool {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function requireLogin(string $redirect = 'login.php'): void {
    if (!isLoggedIn()) {
        header('Location: ' . $redirect);
        exit();
    }
}

function requireAdmin(): void {
    requireLogin();
    if ($_SESSION['role'] !== 'admin') {
        header('Location: employee_dashboard.php');
        exit();
    }
}

function currentUser(): array {
    return $_SESSION['user'] ?? [];
}

// ─── Audit Logger ────────────────────────────────────────────────────────────
function auditLog(string $action, string $table = '', int $recordId = 0,
                  array $oldVals = [], array $newVals = []): void {
    try {
        $pdo = getPDO();
        $stmt = $pdo->prepare("INSERT INTO audit_log 
            (user_id, action, table_name, record_id, old_values, new_values, ip_address, user_agent)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $_SESSION['user_id'] ?? null,
            $action,
            $table ?: null,
            $recordId ?: null,
            $oldVals ? json_encode($oldVals) : null,
            $newVals ? json_encode($newVals) : null,
            $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0',
            substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255)
        ]);
    } catch (PDOException) {
        // Audit logging should never break the app
    }
}

// ─── Tax Calculation (US Federal Brackets 2026) ───────────────────────────────
function calculateTaxes(float $annualGross): array {
    // Federal brackets (single filer approximation)
    $federalRate = match(true) {
        $annualGross <= 11600  => 0.10,
        $annualGross <= 47150  => 0.12,
        $annualGross <= 100525 => 0.22,
        $annualGross <= 191950 => 0.24,
        $annualGross <= 243725 => 0.32,
        $annualGross <= 609350 => 0.35,
        default                => 0.37,
    };

    // Monthly gross
    $monthlyGross = $annualGross / 12;

    $federal       = round($monthlyGross * $federalRate, 2);
    $state         = round($monthlyGross * 0.05, 2);      // 5% flat state
    $socialSec     = round(min($monthlyGross, 13333.33) * 0.062, 2); // 6.2% up to $160k/yr
    $medicare      = round($monthlyGross * 0.0145, 2);   // 1.45%

    return compact('federal', 'state', 'socialSec', 'medicare');
}

// ─── Format Helpers ───────────────────────────────────────────────────────────
function money(float $amount): string {
    return CURRENCY_SYMBOL . number_format($amount, 2);
}

function pct(float $part, float $total): string {
    if ($total == 0) return '0%';
    return round(($part / $total) * 100, 1) . '%';
}

function timeAgo(string $datetime): string {
    $diff = time() - strtotime($datetime);
    return match(true) {
        $diff < 60     => 'just now',
        $diff < 3600   => floor($diff/60) . 'm ago',
        $diff < 86400  => floor($diff/3600) . 'h ago',
        $diff < 604800 => floor($diff/86400) . 'd ago',
        default        => date('M j, Y', strtotime($datetime))
    };
}

// ─── JSON Response Helper ─────────────────────────────────────────────────────
function jsonResponse(bool $success, string $message, array $data = []): void {
    header('Content-Type: application/json');
    echo json_encode(array_merge(['success' => $success, 'message' => $message], $data));
    exit();
}

// Initialize DB connection check on load
getPDO();
