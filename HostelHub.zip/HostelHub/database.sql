-- ============================================================
-- HostelHub - University Hostels Management System
-- Database: hostelhub_db (MySQL / XAMPP)
-- ============================================================

CREATE DATABASE IF NOT EXISTS hostelhub_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE hostelhub_db;

-- --------------------------------------------------------
-- Users table – students and admin accounts
-- --------------------------------------------------------
CREATE TABLE users (
    id           INT          PRIMARY KEY AUTO_INCREMENT,
    first_name   VARCHAR(50)  NOT NULL,
    last_name    VARCHAR(50)  NOT NULL,
    email        VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    student_id   VARCHAR(30)  UNIQUE,
    phone        VARCHAR(20),
    role         ENUM('student','admin') NOT NULL DEFAULT 'student',
    gender       ENUM('male','female','other'),
    is_active    TINYINT(1)   NOT NULL DEFAULT 1,
    created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
);

-- --------------------------------------------------------
-- Hostels table – the actual hostel buildings
-- --------------------------------------------------------
CREATE TABLE hostels (
    id          INT          PRIMARY KEY AUTO_INCREMENT,
    name        VARCHAR(100) NOT NULL,
    description TEXT,
    gender_type ENUM('male','female','mixed') NOT NULL DEFAULT 'mixed',
    total_rooms INT          NOT NULL DEFAULT 0,
    image_url   VARCHAR(2048),
    is_active   TINYINT(1)   NOT NULL DEFAULT 1,
    created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
);

-- --------------------------------------------------------
-- Rooms table – individual rooms within a hostel
-- --------------------------------------------------------
CREATE TABLE rooms (
    id          INT           PRIMARY KEY AUTO_INCREMENT,
    hostel_id   INT           NOT NULL,
    room_number VARCHAR(20)   NOT NULL,
    floor       INT           DEFAULT 1,
    capacity    INT           NOT NULL DEFAULT 2,
    room_type   ENUM('single','double','triple','quad') NOT NULL DEFAULT 'double',
    price_per_semester DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    status      ENUM('available','occupied','maintenance') NOT NULL DEFAULT 'available',
    amenities   TEXT          COMMENT 'JSON array of amenities',
    created_at  TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (hostel_id) REFERENCES hostels(id) ON DELETE CASCADE,
    UNIQUE KEY unique_room (hostel_id, room_number)
);

-- --------------------------------------------------------
-- Bookings table – room allocation records
-- --------------------------------------------------------
CREATE TABLE bookings (
    id            INT           PRIMARY KEY AUTO_INCREMENT,
    user_id       INT           NOT NULL,
    room_id       INT           NOT NULL,
    hostel_id     INT           NOT NULL,
    academic_year VARCHAR(20)   NOT NULL,
    semester      ENUM('1','2') NOT NULL DEFAULT '1',
    check_in_date DATE,
    check_out_date DATE,
    amount_due    DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    amount_paid   DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    status        ENUM('pending','confirmed','checked_in','checked_out','cancelled') NOT NULL DEFAULT 'pending',
    notes         TEXT,
    created_at    TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id)    REFERENCES users(id)   ON DELETE CASCADE,
    FOREIGN KEY (room_id)    REFERENCES rooms(id)   ON DELETE CASCADE,
    FOREIGN KEY (hostel_id)  REFERENCES hostels(id) ON DELETE CASCADE
);

-- --------------------------------------------------------
-- Maintenance requests
-- --------------------------------------------------------
CREATE TABLE maintenance_requests (
    id          INT           PRIMARY KEY AUTO_INCREMENT,
    user_id     INT           NOT NULL,
    room_id     INT           NOT NULL,
    title       VARCHAR(255)  NOT NULL,
    description TEXT          NOT NULL,
    priority    ENUM('low','medium','high','urgent') NOT NULL DEFAULT 'medium',
    status      ENUM('open','in_progress','resolved','closed') NOT NULL DEFAULT 'open',
    created_at  TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP     NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE
);

-- --------------------------------------------------------
-- Login audit log
-- --------------------------------------------------------
CREATE TABLE login_attempts (
    id         INT          PRIMARY KEY AUTO_INCREMENT,
    email      VARCHAR(100) NOT NULL,
    success    TINYINT(1)   NOT NULL DEFAULT 0,
    ip_address VARCHAR(45),
    attempted_at TIMESTAMP  DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- Seed Data
-- ============================================================

-- Admin user  (password: Admin@1234)
INSERT INTO users (first_name, last_name, email, password_hash, student_id, role, gender) VALUES
('System', 'Admin', 'admin@hostelhub.edu', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'ADMIN001', 'admin', 'male');

-- Sample students  (password: Student@1)
INSERT INTO users (first_name, last_name, email, password_hash, student_id, phone, role, gender) VALUES
('Kwame',  'Mensah',   'kwame.m@student.edu',  '$2y$10$TKh8H1.v7VwEqRfSaIy8ceyHMEzB2W0a/9o7/2b6kpI7kfQ7mYZOm', 'STU2024001', '0244000001', 'student', 'male'),
('Akosua', 'Asante',   'akosua.a@student.edu', '$2y$10$TKh8H1.v7VwEqRfSaIy8ceyHMEzB2W0a/9o7/2b6kpI7kfQ7mYZOm', 'STU2024002', '0244000002', 'student', 'female'),
('Kofi',   'Boateng',  'kofi.b@student.edu',   '$2y$10$TKh8H1.v7VwEqRfSaIy8ceyHMEzB2W0a/9o7/2b6kpI7kfQ7mYZOm', 'STU2024003', '0244000003', 'student', 'male'),
('Abena',  'Owusu',    'abena.o@student.edu',  '$2y$10$TKh8H1.v7VwEqRfSaIy8ceyHMEzB2W0a/9o7/2b6kpI7kfQ7mYZOm', 'STU2024004', '0244000004', 'student', 'female');

-- Hostels
INSERT INTO hostels (name, description, gender_type, total_rooms, image_url) VALUES
('Akosombo Hall',  'A well-equipped male hostel with modern facilities and 24/7 security.',  'male',   60, 'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=800'),
('Volta Hall',     'Premium female hostel offering comfortable and safe living environment.', 'female', 50, 'https://images.unsplash.com/photo-1568495248636-6432b97bd949?w=800'),
('Unity House',    'Mixed hostel promoting diversity and inclusion for all students.',        'mixed',  40, 'https://images.unsplash.com/photo-1513694203232-719a280e022f?w=800');

-- Rooms – Akosombo Hall (hostel_id=1)
INSERT INTO rooms (hostel_id, room_number, floor, capacity, room_type, price_per_semester, status, amenities) VALUES
(1, 'A101', 1, 1, 'single', 1200.00, 'available',  '["WiFi","AC","Private Bathroom","Study Desk"]'),
(1, 'A102', 1, 2, 'double', 800.00,  'occupied',   '["WiFi","Fan","Shared Bathroom","Study Desk"]'),
(1, 'A103', 1, 2, 'double', 800.00,  'available',  '["WiFi","Fan","Shared Bathroom","Study Desk"]'),
(1, 'A201', 2, 1, 'single', 1200.00, 'available',  '["WiFi","AC","Private Bathroom","Study Desk","Balcony"]'),
(1, 'A202', 2, 3, 'triple', 600.00,  'available',  '["WiFi","Fan","Shared Bathroom"]'),
(1, 'A203', 2, 4, 'quad',   500.00,  'maintenance','["WiFi","Fan","Shared Bathroom"]');

-- Rooms – Volta Hall (hostel_id=2)
INSERT INTO rooms (hostel_id, room_number, floor, capacity, room_type, price_per_semester, status, amenities) VALUES
(2, 'V101', 1, 1, 'single', 1300.00, 'available',  '["WiFi","AC","Private Bathroom","Wardrobe","Study Desk"]'),
(2, 'V102', 1, 2, 'double', 850.00,  'available',  '["WiFi","AC","Shared Bathroom","Study Desk"]'),
(2, 'V103', 1, 2, 'double', 850.00,  'occupied',   '["WiFi","Fan","Shared Bathroom","Study Desk"]'),
(2, 'V201', 2, 1, 'single', 1300.00, 'available',  '["WiFi","AC","Private Bathroom","Balcony","Study Desk"]');

-- Rooms – Unity House (hostel_id=3)
INSERT INTO rooms (hostel_id, room_number, floor, capacity, room_type, price_per_semester, status, amenities) VALUES
(3, 'U101', 1, 2, 'double', 750.00,  'available',  '["WiFi","Fan","Shared Bathroom","Study Desk"]'),
(3, 'U102', 1, 2, 'double', 750.00,  'available',  '["WiFi","Fan","Shared Bathroom","Study Desk"]'),
(3, 'U201', 2, 1, 'single', 1100.00, 'available',  '["WiFi","AC","Private Bathroom","Study Desk"]');

-- Sample booking (Kwame in A102)
INSERT INTO bookings (user_id, room_id, hostel_id, academic_year, semester, check_in_date, check_out_date, amount_due, amount_paid, status) VALUES
(2, 2, 1, '2024/2025', '1', '2024-09-01', '2025-01-31', 800.00, 800.00, 'checked_in');

-- Sample booking (Akosua in V103)
INSERT INTO bookings (user_id, room_id, hostel_id, academic_year, semester, check_in_date, check_out_date, amount_due, amount_paid, status) VALUES
(3, 9, 2, '2024/2025', '1', '2024-09-01', '2025-01-31', 850.00, 500.00, 'checked_in');

-- Sample maintenance request
INSERT INTO maintenance_requests (user_id, room_id, title, description, priority, status) VALUES
(2, 2, 'Broken Window Latch', 'The window latch on the south side is broken and wont lock properly.', 'high', 'open'),
(3, 9, 'Leaking Tap',         'The bathroom tap has been dripping continuously for 3 days.',         'medium','in_progress');
