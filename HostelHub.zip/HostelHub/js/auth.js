/**
 * HostelHub – Auth Module
 * Handles login, register, logout, session, password strength
 */

const Auth = (() => {

  const BASE = 'api/auth.php';

  // ── Session ──────────────────────────────────────────────────
  async function checkSession() {
    try {
      const res  = await fetch(`${BASE}?action=session`);
      const data = await res.json();
      return data.success ? data.data : null;
    } catch { return null; }
  }

  // ── Register ─────────────────────────────────────────────────
  async function register(payload) {
    const res  = await fetch(`${BASE}?action=register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    return res.json();
  }

  // ── Login ─────────────────────────────────────────────────────
  async function login(email, password) {
    const res  = await fetch(`${BASE}?action=login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    return res.json();
  }

  // ── Logout ────────────────────────────────────────────────────
  async function logout() {
    await fetch(`${BASE}?action=logout`, { method: 'POST' });
    window.location.href = 'index.html';
  }

  // ── Guard: redirect if not logged in ─────────────────────────
  async function requireAuth(redirectTo = 'login.html') {
    const user = await checkSession();
    if (!user) { window.location.href = redirectTo; return null; }
    return user;
  }

  // ── Guard: redirect if already logged in ─────────────────────
  async function redirectIfLoggedIn(to = 'dashboard.html') {
    const user = await checkSession();
    if (user) window.location.href = to;
  }

  return { checkSession, register, login, logout, requireAuth, redirectIfLoggedIn };
})();


// ── Shared Nav helper (inject user info into navbar) ─────────────
async function initNav() {
  const user = await Auth.checkSession();

  const guestEl  = document.getElementById('nav-guest');
  const userEl   = document.getElementById('nav-user');
  const nameEl   = document.getElementById('nav-user-name');
  const avatarEl = document.getElementById('nav-avatar');

  if (user) {
    if (guestEl)  guestEl.style.display  = 'none';
    if (userEl)   userEl.style.display   = 'flex';
    if (nameEl)   nameEl.textContent     = user.name || user.first_name || 'User';
    if (avatarEl) avatarEl.textContent   = (user.name || 'U')[0].toUpperCase();
  } else {
    if (guestEl) guestEl.style.display  = 'flex';
    if (userEl)  userEl.style.display   = 'none';
  }

  // Toggle dropdown
  const toggle = document.getElementById('user-menu-toggle');
  const drop   = document.getElementById('user-dropdown');
  if (toggle && drop) {
    toggle.addEventListener('click', (e) => {
      e.stopPropagation();
      drop.classList.toggle('show');
    });
    document.addEventListener('click', () => drop.classList.remove('show'));
  }

  // Logout buttons
  document.querySelectorAll('[data-action=logout]').forEach(el => {
    el.addEventListener('click', () => Auth.logout());
  });
}


// ── Password strength checker ─────────────────────────────────────
function checkPasswordStrength(password) {
  let score = 0;
  const checks = {
    length:    password.length >= 8,
    uppercase: /[A-Z]/.test(password),
    lowercase: /[a-z]/.test(password),
    digit:     /\d/.test(password),
    special:   /[^A-Za-z0-9]/.test(password),
  };
  score = Object.values(checks).filter(Boolean).length;
  return { score, checks };
}

function renderStrengthBar(score, barEl, labelEl) {
  const pct    = (score / 5) * 100;
  const colors = ['#ef4444', '#f59e0b', '#f59e0b', '#10b981', '#10b981'];
  const labels = ['Very weak', 'Weak', 'Fair', 'Strong', 'Very strong'];
  if (barEl) { barEl.style.width = pct + '%'; barEl.style.background = colors[score - 1] || '#d1d5db'; }
  if (labelEl) labelEl.textContent = score ? labels[score - 1] : '';
}


// ── Form helpers ──────────────────────────────────────────────────

function showFieldError(fieldId, msg) {
  const el  = document.getElementById(fieldId);
  const err = document.getElementById(fieldId + '-error');
  if (el)  el.classList.add('error');
  if (err) err.textContent = msg;
}
function clearFieldErrors() {
  document.querySelectorAll('.form-control.error').forEach(el => el.classList.remove('error'));
  document.querySelectorAll('.form-error').forEach(el => el.textContent = '');
}
function showAlert(elId, msg, type = 'danger') {
  const el = document.getElementById(elId);
  if (!el) return;
  el.className = `alert alert-${type}`;
  el.textContent = msg;
  el.style.display = 'flex';
  setTimeout(() => { el.style.display = 'none'; }, 5000);
}
function setLoading(btnId, loading, text = 'Submit') {
  const btn = document.getElementById(btnId);
  if (!btn) return;
  btn.disabled   = loading;
  btn.innerHTML  = loading
    ? '<span class="spinner" style="width:16px;height:16px;border-width:2px;margin:0"></span>'
    : text;
}

// ── Toggle password visibility ────────────────────────────────────
document.addEventListener('click', (e) => {
  if (e.target.closest('[data-toggle-pwd]')) {
    const targetId = e.target.closest('[data-toggle-pwd]').dataset.togglePwd;
    const input    = document.getElementById(targetId);
    if (!input) return;
    const isText   = input.type === 'text';
    input.type     = isText ? 'password' : 'text';
    e.target.closest('[data-toggle-pwd]').innerHTML = isText ? '👁' : '🙈';
  }
});
