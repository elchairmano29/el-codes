<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../classes/Room.php';

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];
$room   = new Room();
$hostel = new Hostel();
$id     = isset($_GET['id']) ? (int)$_GET['id'] : null;

try {
    switch ($method) {
        case 'GET':
            if ($id) {
                $data = $room->getById($id);
                if (!$data) errorResponse('Room not found', 404);
                successResponse($data);
            } elseif (($_GET['action'] ?? '') === 'hostels') {
                successResponse($hostel->all());
            } elseif (($_GET['action'] ?? '') === 'stats') {
                requireAdmin();
                successResponse($room->stats());
            } else {
                $filters = array_intersect_key($_GET,
                    array_flip(['hostel_id','status','room_type','min_price','max_price']));
                successResponse($room->all($filters));
            }
            break;

        case 'POST':
            requireAdmin();
            $in = json_decode(file_get_contents('php://input'), true) ?? [];
            $action = $_GET['action'] ?? '';

            if ($action === 'hostel') {
                foreach (['name','gender_type'] as $f) {
                    if (empty($in[$f])) errorResponse("$f is required");
                }
                $newId = $hostel->create($in);
                successResponse(['id' => $newId], 'Hostel created');
            } else {
                foreach (['hostel_id','room_number','price_per_semester'] as $f) {
                    if (empty($in[$f])) errorResponse("$f is required");
                }
                $newId = $room->create($in);
                successResponse(['id' => $newId], 'Room created');
            }
            break;

        case 'PUT':
            requireAdmin();
            if (!$id) errorResponse('ID required');
            $in     = json_decode(file_get_contents('php://input'), true) ?? [];
            $action = $_GET['action'] ?? '';
            if ($action === 'hostel') {
                $hostel->update($id, $in);
                successResponse([], 'Hostel updated');
            } else {
                $room->update($id, $in);
                successResponse([], 'Room updated');
            }
            break;

        case 'DELETE':
            requireAdmin();
            if (!$id) errorResponse('ID required');
            $action = $_GET['action'] ?? '';
            if ($action === 'hostel') {
                $hostel->delete($id);
                successResponse([], 'Hostel deactivated');
            } else {
                $room->delete($id);
                successResponse([], 'Room deleted');
            }
            break;

        default:
            errorResponse('Method not allowed', 405);
    }
} catch (RuntimeException $e) {
    errorResponse($e->getMessage());
} catch (Throwable $e) {
    error_log('Rooms API: ' . $e->getMessage());
    errorResponse('Server error', 500);
}
?>
