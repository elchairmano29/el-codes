<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../classes/Maintenance.php';

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];
$maint  = new Maintenance();
$id     = isset($_GET['id']) ? (int)$_GET['id'] : null;

try {
    switch ($method) {
        case 'GET':
            requireLogin();
            if (isAdmin()) {
                successResponse($maint->all($_GET['status'] ?? ''));
            } else {
                successResponse($maint->byUser(currentUserId()));
            }
            break;

        case 'POST':
            requireLogin();
            $in = json_decode(file_get_contents('php://input'), true) ?? [];
            foreach (['room_id','title','description'] as $f) {
                if (empty($in[$f])) errorResponse("$f is required");
            }
            $newId = $maint->create([
                'user_id'     => currentUserId(),
                'room_id'     => (int)$in['room_id'],
                'title'       => $in['title'],
                'description' => $in['description'],
                'priority'    => $in['priority'] ?? 'medium',
            ]);
            successResponse(['id' => $newId], 'Request submitted');
            break;

        case 'PUT':
            requireAdmin();
            if (!$id) errorResponse('ID required');
            $in = json_decode(file_get_contents('php://input'), true) ?? [];
            if (empty($in['status'])) errorResponse('Status required');
            $maint->updateStatus($id, $in['status']);
            successResponse([], 'Status updated');
            break;

        default:
            errorResponse('Method not allowed', 405);
    }
} catch (RuntimeException $e) {
    errorResponse($e->getMessage());
} catch (Throwable $e) {
    error_log('Maintenance API: ' . $e->getMessage());
    errorResponse('Server error', 500);
}
?>
