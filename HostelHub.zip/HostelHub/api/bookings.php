<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../classes/Booking.php';

header('Content-Type: application/json');

$method  = $_SERVER['REQUEST_METHOD'];
$booking = new Booking();
$id      = isset($_GET['id']) ? (int)$_GET['id'] : null;

try {
    switch ($method) {
        case 'GET':
            requireLogin();
            if ($id) {
                $uid  = isAdmin() ? null : currentUserId();
                $data = $booking->getById($id, $uid);
                if (!$data) errorResponse('Booking not found', 404);
                successResponse($data);
            } elseif (($_GET['action'] ?? '') === 'stats') {
                requireAdmin();
                successResponse($booking->stats());
            } elseif (isAdmin() && ($_GET['action'] ?? '') === 'all') {
                successResponse($booking->all($_GET['status'] ?? '', $_GET['search'] ?? ''));
            } else {
                successResponse($booking->byUser(currentUserId()));
            }
            break;

        case 'POST':
            requireLogin();
            $in = json_decode(file_get_contents('php://input'), true) ?? [];
            foreach (['room_id','hostel_id','academic_year','semester'] as $f) {
                if (empty($in[$f])) errorResponse("$f is required");
            }
            // Get room price
            require_once __DIR__ . '/../classes/Room.php';
            $roomObj = new Room();
            $roomRow = $roomObj->getById((int)$in['room_id']);
            if (!$roomRow) errorResponse('Room not found', 404);

            $newId = $booking->create([
                'user_id'        => currentUserId(),
                'room_id'        => (int)$in['room_id'],
                'hostel_id'      => (int)$in['hostel_id'],
                'academic_year'  => sanitize($in['academic_year']),
                'semester'       => $in['semester'],
                'check_in_date'  => $in['check_in_date']  ?? null,
                'check_out_date' => $in['check_out_date'] ?? null,
                'amount_due'     => $roomRow['price_per_semester'],
                'notes'          => sanitize($in['notes'] ?? ''),
            ]);
            successResponse(['booking_id' => $newId], 'Booking submitted! Awaiting confirmation.');
            break;

        case 'PUT':
            requireLogin();
            if (!$id) errorResponse('ID required');
            $in     = json_decode(file_get_contents('php://input'), true) ?? [];
            $action = $_GET['action'] ?? '';

            if ($action === 'status') {
                requireAdmin();
                if (empty($in['status'])) errorResponse('Status required');
                $booking->updateStatus($id, $in['status']);
                successResponse([], 'Booking status updated');
            } elseif ($action === 'payment') {
                requireAdmin();
                if (empty($in['amount'])) errorResponse('Amount required');
                $booking->recordPayment($id, (float)$in['amount']);
                successResponse([], 'Payment recorded');
            } elseif ($action === 'cancel') {
                $booking->cancelByUser($id, currentUserId());
                successResponse([], 'Booking cancelled');
            } else {
                errorResponse('Unknown action', 404);
            }
            break;

        default:
            errorResponse('Method not allowed', 405);
    }
} catch (RuntimeException $e) {
    errorResponse($e->getMessage());
} catch (Throwable $e) {
    error_log('Bookings API: ' . $e->getMessage());
    errorResponse('Server error', 500);
}
?>
