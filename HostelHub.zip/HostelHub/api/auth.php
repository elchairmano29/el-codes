<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../classes/User.php';

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';
$user   = new User();

try {
    switch ($method) {
        // ── POST ────────────────────────────────────────────────────────────
        case 'POST':
            $in = json_decode(file_get_contents('php://input'), true) ?? [];

            if ($action === 'register') {
                foreach (['first_name','last_name','email','password','confirm_password'] as $f) {
                    if (empty($in[$f])) errorResponse("$f is required");
                }
                if (!validateEmail($in['email']))      errorResponse('Invalid email format');
                if (!validatePassword($in['password'])) errorResponse('Password must be ≥8 chars with uppercase, lowercase and digit');
                if ($in['password'] !== $in['confirm_password']) errorResponse('Passwords do not match');

                $id = $user->register([
                    'first_name' => sanitize($in['first_name']),
                    'last_name'  => sanitize($in['last_name']),
                    'email'      => strtolower(trim($in['email'])),
                    'password'   => $in['password'],
                    'student_id' => sanitize($in['student_id'] ?? ''),
                    'phone'      => sanitize($in['phone']      ?? ''),
                    'gender'     => $in['gender'] ?? null,
                ]);
                successResponse(['user_id' => $id], 'Registration successful! Please log in.');

            } elseif ($action === 'login') {
                if (empty($in['email']) || empty($in['password'])) {
                    errorResponse('Email and password are required');
                }
                $data = $user->login(strtolower(trim($in['email'])), $in['password']);
                successResponse($data, 'Login successful');

            } elseif ($action === 'logout') {
                $user->logout();
                successResponse([], 'Logged out successfully');

            } else {
                errorResponse('Unknown action', 404);
            }
            break;

        // ── GET ─────────────────────────────────────────────────────────────
        case 'GET':
            if ($action === 'session') {
                if (isLoggedIn()) {
                    successResponse([
                        'id'    => currentUserId(),
                        'name'  => $_SESSION['user_name'],
                        'email' => $_SESSION['user_email'],
                        'role'  => currentUserRole(),
                    ], 'Authenticated');
                } else {
                    errorResponse('Not authenticated', 401);
                }
            } elseif ($action === 'profile') {
                requireLogin();
                $data = $user->getById(currentUserId());
                if (!$data) errorResponse('User not found', 404);
                successResponse($data);
            } elseif ($action === 'users') {
                requireAdmin();
                $list = $user->all($_GET['search'] ?? '', $_GET['role'] ?? '');
                successResponse($list);
            } else {
                errorResponse('Unknown action', 404);
            }
            break;

        // ── PUT ─────────────────────────────────────────────────────────────
        case 'PUT':
            requireLogin();
            $in = json_decode(file_get_contents('php://input'), true) ?? [];
            if ($action === 'profile') {
                $user->updateProfile(currentUserId(), $in);
                successResponse([], 'Profile updated');
            } elseif ($action === 'password') {
                if (empty($in['current_password']) || empty($in['new_password'])) {
                    errorResponse('Both passwords are required');
                }
                if (!validatePassword($in['new_password'])) {
                    errorResponse('New password must be ≥8 chars with uppercase, lowercase and digit');
                }
                $user->changePassword(currentUserId(), $in['current_password'], $in['new_password']);
                successResponse([], 'Password changed successfully');
            } elseif ($action === 'toggle_user' && isAdmin()) {
                $user->toggleActive((int)($in['user_id'] ?? 0));
                successResponse([], 'User status toggled');
            } else {
                errorResponse('Unknown action', 404);
            }
            break;

        default:
            errorResponse('Method not allowed', 405);
    }
} catch (RuntimeException $e) {
    errorResponse($e->getMessage());
} catch (Throwable $e) {
    error_log('Auth API: ' . $e->getMessage());
    errorResponse('Server error', 500);
}
?>
