<?php
require_once __DIR__ . '/../includes/config.php';

class Maintenance {
    private PDO $pdo;

    public function __construct() {
        $this->pdo = getPDO();
    }

    public function create(array $data): int {
        $stmt = $this->pdo->prepare("
            INSERT INTO maintenance_requests (user_id, room_id, title, description, priority)
            VALUES (?,?,?,?,?)
        ");
        $stmt->execute([
            $data['user_id'],
            $data['room_id'],
            sanitize($data['title']),
            sanitize($data['description']),
            $data['priority'] ?? 'medium',
        ]);
        return (int) $this->pdo->lastInsertId();
    }

    public function byUser(int $userId): array {
        $stmt = $this->pdo->prepare("
            SELECT m.*, r.room_number, h.name AS hostel_name
            FROM maintenance_requests m
            JOIN rooms r   ON m.room_id   = r.id
            JOIN hostels h ON r.hostel_id = h.id
            WHERE m.user_id=?
            ORDER BY m.created_at DESC
        ");
        $stmt->execute([$userId]);
        return $stmt->fetchAll();
    }

    public function all(string $status = ''): array {
        $sql    = "
            SELECT m.*, r.room_number, h.name AS hostel_name,
                   u.first_name, u.last_name, u.student_id
            FROM maintenance_requests m
            JOIN rooms r   ON m.room_id   = r.id
            JOIN hostels h ON r.hostel_id = h.id
            JOIN users u   ON m.user_id   = u.id
            WHERE 1=1
        ";
        $params = [];
        if ($status) { $sql .= ' AND m.status=?'; $params[] = $status; }
        $sql .= ' ORDER BY FIELD(m.priority,"urgent","high","medium","low"), m.created_at DESC';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function updateStatus(int $id, string $status): bool {
        $resolved = in_array($status, ['resolved','closed']) ? date('Y-m-d H:i:s') : null;
        $stmt = $this->pdo->prepare("
            UPDATE maintenance_requests SET status=?, resolved_at=? WHERE id=?
        ");
        return $stmt->execute([$status, $resolved, $id]);
    }
}
?>
