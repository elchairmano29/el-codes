<?php
require_once __DIR__ . '/../includes/config.php';

class User {
    private PDO $pdo;

    public function __construct() {
        $this->pdo = getPDO();
    }

    // ── Register ──────────────────────────────────────────────────────────────
    public function register(array $data): int {
        // Duplicate email check
        $stmt = $this->pdo->prepare('SELECT id FROM users WHERE email = ?');
        $stmt->execute([$data['email']]);
        if ($stmt->fetch()) throw new RuntimeException('Email already registered');

        // Duplicate student_id check
        if (!empty($data['student_id'])) {
            $stmt = $this->pdo->prepare('SELECT id FROM users WHERE student_id = ?');
            $stmt->execute([$data['student_id']]);
            if ($stmt->fetch()) throw new RuntimeException('Student ID already registered');
        }

        $stmt = $this->pdo->prepare('
            INSERT INTO users (first_name, last_name, email, password_hash, student_id, phone, gender)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ');
        $stmt->execute([
            $data['first_name'],
            $data['last_name'],
            $data['email'],
            hashPassword($data['password']),
            $data['student_id'] ?? null,
            $data['phone']      ?? null,
            $data['gender']     ?? null,
        ]);
        return (int) $this->pdo->lastInsertId();
    }

    // ── Login ─────────────────────────────────────────────────────────────────
    public function login(string $email, string $password): array {
        if ($this->isLocked($email)) {
            throw new RuntimeException('Account locked. Try again in 5 minutes.');
        }

        $stmt = $this->pdo->prepare('
            SELECT id, first_name, last_name, email, password_hash, role, is_active
            FROM users WHERE email = ?
        ');
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user || !$user['is_active'] || !verifyPassword($password, $user['password_hash'])) {
            $this->recordAttempt($email, false);
            throw new RuntimeException('Invalid email or password');
        }

        $this->recordAttempt($email, true);
        $this->clearAttempts($email);

        // Set session
        session_regenerate_id(true);
        $_SESSION['user_id']    = $user['id'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_name']  = $user['first_name'] . ' ' . $user['last_name'];
        $_SESSION['user_role']  = $user['role'];

        return [
            'id'         => $user['id'],
            'first_name' => $user['first_name'],
            'last_name'  => $user['last_name'],
            'email'      => $user['email'],
            'role'       => $user['role'],
        ];
    }

    // ── Logout ────────────────────────────────────────────────────────────────
    public function logout(): void {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $p['path'], $p['domain'], $p['secure'], $p['httponly']);
        }
        session_destroy();
    }

    // ── Get by ID ─────────────────────────────────────────────────────────────
    public function getById(int $id): ?array {
        $stmt = $this->pdo->prepare('
            SELECT id, first_name, last_name, email, student_id, phone, gender, role, created_at
            FROM users WHERE id = ?
        ');
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    // ── Update profile ────────────────────────────────────────────────────────
    public function updateProfile(int $id, array $data): bool {
        $stmt = $this->pdo->prepare('
            UPDATE users SET first_name=?, last_name=?, phone=?, gender=?
            WHERE id=?
        ');
        return $stmt->execute([
            sanitize($data['first_name']),
            sanitize($data['last_name']),
            sanitize($data['phone']  ?? ''),
            $data['gender'] ?? null,
            $id,
        ]);
    }

    // ── Change password ───────────────────────────────────────────────────────
    public function changePassword(int $id, string $current, string $newPwd): bool {
        $stmt = $this->pdo->prepare('SELECT password_hash FROM users WHERE id=?');
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        if (!$row || !verifyPassword($current, $row['password_hash'])) {
            throw new RuntimeException('Current password is incorrect');
        }
        $stmt = $this->pdo->prepare('UPDATE users SET password_hash=? WHERE id=?');
        return $stmt->execute([hashPassword($newPwd), $id]);
    }

    // ── List all (admin) ──────────────────────────────────────────────────────
    public function all(string $search = '', string $role = ''): array {
        $sql    = 'SELECT id,first_name,last_name,email,student_id,phone,gender,role,is_active,created_at FROM users WHERE 1=1';
        $params = [];
        if ($search) {
            $sql .= ' AND (first_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR student_id LIKE ?)';
            $like = "%$search%";
            array_push($params, $like, $like, $like, $like);
        }
        if ($role) {
            $sql .= ' AND role=?';
            $params[] = $role;
        }
        $sql .= ' ORDER BY created_at DESC';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    // ── Toggle active (admin) ─────────────────────────────────────────────────
    public function toggleActive(int $id): bool {
        $stmt = $this->pdo->prepare('UPDATE users SET is_active = NOT is_active WHERE id=?');
        return $stmt->execute([$id]);
    }

    // ── Lockout helpers ───────────────────────────────────────────────────────
    private function isLocked(string $email): bool {
        $since = date('Y-m-d H:i:s', time() - LOCKOUT_SECONDS);
        $stmt  = $this->pdo->prepare('
            SELECT COUNT(*) FROM login_attempts
            WHERE email=? AND success=0 AND attempted_at > ?
        ');
        $stmt->execute([$email, $since]);
        return (int) $stmt->fetchColumn() >= MAX_LOGIN_ATTEMPTS;
    }

    private function recordAttempt(string $email, bool $ok): void {
        $stmt = $this->pdo->prepare('
            INSERT INTO login_attempts (email, success, ip_address) VALUES (?,?,?)
        ');
        $stmt->execute([$email, (int)$ok, getClientIP()]);
    }

    private function clearAttempts(string $email): void {
        $stmt = $this->pdo->prepare('DELETE FROM login_attempts WHERE email=?');
        $stmt->execute([$email]);
    }
}
?>
