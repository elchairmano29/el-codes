<?php
require_once __DIR__ . '/../includes/config.php';

class Booking {
    private PDO $pdo;

    public function __construct() {
        $this->pdo = getPDO();
    }

    // ── Create booking ────────────────────────────────────────────────────────
    public function create(array $data): int {
        // Is room available?
        $stmt = $this->pdo->prepare("SELECT status FROM rooms WHERE id=?");
        $stmt->execute([$data['room_id']]);
        $room = $stmt->fetch();
        if (!$room || $room['status'] !== 'available') {
            throw new RuntimeException('Room is not available for booking');
        }

        // Active booking check for this user this semester
        $stmt = $this->pdo->prepare("
            SELECT id FROM bookings
            WHERE user_id=? AND academic_year=? AND semester=?
              AND status NOT IN ('cancelled','checked_out')
        ");
        $stmt->execute([$data['user_id'], $data['academic_year'], $data['semester']]);
        if ($stmt->fetch()) {
            throw new RuntimeException('You already have an active booking for this semester');
        }

        $this->pdo->beginTransaction();
        try {
            $stmt = $this->pdo->prepare("
                INSERT INTO bookings
                  (user_id, room_id, hostel_id, academic_year, semester,
                   check_in_date, check_out_date, amount_due, status, notes)
                VALUES (?,?,?,?,?,?,?,?,'pending',?)
            ");
            $stmt->execute([
                $data['user_id'],
                $data['room_id'],
                $data['hostel_id'],
                $data['academic_year'],
                $data['semester'],
                $data['check_in_date']  ?? null,
                $data['check_out_date'] ?? null,
                $data['amount_due']     ?? 0,
                $data['notes']          ?? '',
            ]);
            $bookingId = (int) $this->pdo->lastInsertId();

            // Mark room as occupied
            $this->pdo->prepare("UPDATE rooms SET status='occupied' WHERE id=?")
                      ->execute([$data['room_id']]);

            $this->pdo->commit();
            return $bookingId;
        } catch (\Throwable $e) {
            $this->pdo->rollBack();
            throw $e;
        }
    }

    // ── Get single booking ────────────────────────────────────────────────────
    public function getById(int $id, ?int $userId = null): ?array {
        $sql = "
            SELECT b.*, r.room_number, r.room_type, r.price_per_semester,
                   r.floor, r.amenities,
                   h.name AS hostel_name,
                   u.first_name, u.last_name, u.email, u.student_id
            FROM bookings b
            JOIN rooms r   ON b.room_id   = r.id
            JOIN hostels h ON b.hostel_id = h.id
            JOIN users u   ON b.user_id   = u.id
            WHERE b.id=?
        ";
        $params = [$id];
        if ($userId !== null) {
            $sql     .= ' AND b.user_id=?';
            $params[] = $userId;
        }
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetch() ?: null;
    }

    // ── My bookings ───────────────────────────────────────────────────────────
    public function byUser(int $userId): array {
        $stmt = $this->pdo->prepare("
            SELECT b.*, r.room_number, r.room_type, h.name AS hostel_name
            FROM bookings b
            JOIN rooms r   ON b.room_id   = r.id
            JOIN hostels h ON b.hostel_id = h.id
            WHERE b.user_id=?
            ORDER BY b.created_at DESC
        ");
        $stmt->execute([$userId]);
        return $stmt->fetchAll();
    }

    // ── All bookings (admin) ──────────────────────────────────────────────────
    public function all(string $status = '', string $search = ''): array {
        $sql  = "
            SELECT b.*, r.room_number, h.name AS hostel_name,
                   u.first_name, u.last_name, u.student_id
            FROM bookings b
            JOIN rooms r   ON b.room_id   = r.id
            JOIN hostels h ON b.hostel_id = h.id
            JOIN users u   ON b.user_id   = u.id
            WHERE 1=1
        ";
        $params = [];
        if ($status) { $sql .= ' AND b.status=?'; $params[] = $status; }
        if ($search) {
            $sql .= ' AND (u.first_name LIKE ? OR u.last_name LIKE ? OR u.student_id LIKE ? OR r.room_number LIKE ?)';
            $like = "%$search%";
            array_push($params, $like, $like, $like, $like);
        }
        $sql .= ' ORDER BY b.created_at DESC';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    // ── Update status (admin) ─────────────────────────────────────────────────
    public function updateStatus(int $id, string $newStatus, ?int $userId = null): bool {
        $sql    = 'UPDATE bookings SET status=? WHERE id=?';
        $params = [$newStatus, $id];
        if ($userId !== null) { $sql .= ' AND user_id=?'; $params[] = $userId; }

        $stmt = $this->pdo->prepare($sql);
        $ok   = $stmt->execute($params);

        if ($ok && in_array($newStatus, ['cancelled', 'checked_out'])) {
            // Free the room
            $row = $this->getById($id);
            if ($row) {
                $this->pdo->prepare("UPDATE rooms SET status='available' WHERE id=?")
                          ->execute([$row['room_id']]);
            }
        }
        return $ok;
    }

    // ── Record payment ────────────────────────────────────────────────────────
    public function recordPayment(int $id, float $amount): bool {
        $stmt = $this->pdo->prepare("
            UPDATE bookings SET amount_paid = amount_paid + ? WHERE id=?
        ");
        return $stmt->execute([$amount, $id]);
    }

    // ── Cancel by student ─────────────────────────────────────────────────────
    public function cancelByUser(int $id, int $userId): bool {
        return $this->updateStatus($id, 'cancelled', $userId);
    }

    // ── Statistics (admin) ────────────────────────────────────────────────────
    public function stats(): array {
        $row = $this->pdo->query("
            SELECT
              COUNT(*) AS total,
              SUM(status='pending')     AS pending,
              SUM(status='confirmed')   AS confirmed,
              SUM(status='checked_in')  AS checked_in,
              SUM(status='checked_out') AS checked_out,
              SUM(status='cancelled')   AS cancelled,
              SUM(amount_due)           AS total_revenue_due,
              SUM(amount_paid)          AS total_revenue_paid
            FROM bookings
        ")->fetch();
        return $row;
    }
}
?>
