<?php
require_once __DIR__ . '/../includes/config.php';

class Room {
    private PDO $pdo;

    public function __construct() {
        $this->pdo = getPDO();
    }

    public function all(array $filters = []): array {
        $sql    = "
            SELECT r.*, h.name AS hostel_name, h.gender_type,
                   (r.capacity - COALESCE(occ.cnt,0)) AS beds_free
            FROM rooms r
            JOIN hostels h ON r.hostel_id = h.id
            LEFT JOIN (
                SELECT room_id, COUNT(*) AS cnt FROM bookings
                WHERE status IN ('confirmed','checked_in')
                GROUP BY room_id
            ) occ ON occ.room_id = r.id
            WHERE 1=1
        ";
        $params = [];

        if (!empty($filters['hostel_id'])) {
            $sql .= ' AND r.hostel_id=?'; $params[] = $filters['hostel_id'];
        }
        if (!empty($filters['status'])) {
            $sql .= ' AND r.status=?'; $params[] = $filters['status'];
        }
        if (!empty($filters['room_type'])) {
            $sql .= ' AND r.room_type=?'; $params[] = $filters['room_type'];
        }
        if (!empty($filters['min_price'])) {
            $sql .= ' AND r.price_per_semester>=?'; $params[] = $filters['min_price'];
        }
        if (!empty($filters['max_price'])) {
            $sql .= ' AND r.price_per_semester<=?'; $params[] = $filters['max_price'];
        }

        $sql .= ' ORDER BY h.name, r.floor, r.room_number';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function getById(int $id): ?array {
        $stmt = $this->pdo->prepare("
            SELECT r.*, h.name AS hostel_name FROM rooms r
            JOIN hostels h ON r.hostel_id = h.id WHERE r.id=?
        ");
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        if ($row) {
            $row['amenities'] = json_decode($row['amenities'] ?? '[]', true);
        }
        return $row ?: null;
    }

    public function create(array $data): int {
        $stmt = $this->pdo->prepare("
            INSERT INTO rooms (hostel_id, room_number, floor, capacity, room_type, price_per_semester, status, amenities)
            VALUES (?,?,?,?,?,?,?,?)
        ");
        $stmt->execute([
            $data['hostel_id'],
            $data['room_number'],
            $data['floor']      ?? 1,
            $data['capacity']   ?? 2,
            $data['room_type']  ?? 'double',
            $data['price_per_semester'],
            $data['status']     ?? 'available',
            json_encode($data['amenities'] ?? []),
        ]);
        return (int) $this->pdo->lastInsertId();
    }

    public function update(int $id, array $data): bool {
        $stmt = $this->pdo->prepare("
            UPDATE rooms SET room_number=?, floor=?, capacity=?, room_type=?,
                             price_per_semester=?, status=?, amenities=?
            WHERE id=?
        ");
        return $stmt->execute([
            $data['room_number'],
            $data['floor']      ?? 1,
            $data['capacity']   ?? 2,
            $data['room_type']  ?? 'double',
            $data['price_per_semester'],
            $data['status']     ?? 'available',
            json_encode($data['amenities'] ?? []),
            $id,
        ]);
    }

    public function delete(int $id): bool {
        return $this->pdo->prepare("DELETE FROM rooms WHERE id=?")->execute([$id]);
    }

    public function stats(): array {
        return $this->pdo->query("
            SELECT
              COUNT(*) AS total,
              SUM(status='available')   AS available,
              SUM(status='occupied')    AS occupied,
              SUM(status='maintenance') AS maintenance
            FROM rooms
        ")->fetch();
    }
}

class Hostel {
    private PDO $pdo;

    public function __construct() {
        $this->pdo = getPDO();
    }

    public function all(): array {
        return $this->pdo->query("
            SELECT h.*,
                   COUNT(r.id) AS room_count,
                   SUM(r.status='available') AS available_rooms
            FROM hostels h
            LEFT JOIN rooms r ON r.hostel_id = h.id
            WHERE h.is_active=1
            GROUP BY h.id
            ORDER BY h.name
        ")->fetchAll();
    }

    public function getById(int $id): ?array {
        $stmt = $this->pdo->prepare("SELECT * FROM hostels WHERE id=?");
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    public function create(array $data): int {
        $stmt = $this->pdo->prepare("
            INSERT INTO hostels (name, description, gender_type, total_rooms, image_url)
            VALUES (?,?,?,?,?)
        ");
        $stmt->execute([
            sanitize($data['name']),
            sanitize($data['description'] ?? ''),
            $data['gender_type'] ?? 'mixed',
            (int) ($data['total_rooms'] ?? 0),
            $data['image_url'] ?? null,
        ]);
        return (int) $this->pdo->lastInsertId();
    }

    public function update(int $id, array $data): bool {
        $stmt = $this->pdo->prepare("
            UPDATE hostels SET name=?, description=?, gender_type=?, total_rooms=?, image_url=?
            WHERE id=?
        ");
        return $stmt->execute([
            sanitize($data['name']),
            sanitize($data['description'] ?? ''),
            $data['gender_type'] ?? 'mixed',
            (int) ($data['total_rooms'] ?? 0),
            $data['image_url'] ?? null,
            $id,
        ]);
    }

    public function delete(int $id): bool {
        return $this->pdo->prepare("UPDATE hostels SET is_active=0 WHERE id=?")->execute([$id]);
    }
}
?>
