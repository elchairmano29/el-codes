# 🏠 HostelHub – University Hostels Management System

A full-stack web application for managing university student accommodation.
Built with **PHP + MySQL + Vanilla JS** — runs entirely on **XAMPP**.

---

## ✨ Features

| Feature | Details |
|---|---|
| 🔐 **Authentication** | Register/Login with email validation, password masking, brute-force lockout |
| 🛏 **Room Booking** | Browse by hostel, type & price; one-click booking with conflict detection |
| 📋 **Booking Management** | Full lifecycle: Pending → Confirmed → Checked In → Checked Out |
| 💳 **Payment Tracking** | Per-booking payment recording with progress bar |
| 🔧 **Maintenance Requests** | Students submit; admins triage and resolve |
| 🛡 **Admin Panel** | Full CRUD for Hostels, Rooms, Bookings, Maintenance, Students |
| 📊 **Dashboard Analytics** | Revenue overview, occupancy stats, pending queues |
| 🔒 **Role-Based Access** | `student` and `admin` roles with server-enforced guards |

---

## 🚀 Installation (XAMPP)

### 1. Start XAMPP
Open **XAMPP Control Panel** and start:
- ✅ **Apache**
- ✅ **MySQL**

### 2. Copy project files
Copy the **HostelHub** folder to your XAMPP `htdocs` directory:

```
C:\xampp\htdocs\HostelHub\          (Windows)
/Applications/XAMPP/htdocs/HostelHub/  (macOS)
/opt/lampp/htdocs/HostelHub/           (Linux)
```

### 3. Create the database
1. Open your browser and go to: **http://localhost/phpmyadmin**
2. Click **"New"** in the left sidebar
3. Name the database: `hostelhub_db` — click **Create**
4. Select `hostelhub_db` → click the **"Import"** tab
5. Click **"Choose File"** → select `HostelHub/database.sql`
6. Click **"Go"** at the bottom

### 4. Configure database (if needed)
Open `config/database.php`. XAMPP defaults are already set:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'hostelhub_db');
define('DB_USER', 'root');
define('DB_PASS', '');   // blank by default on XAMPP
```

If you have set a MySQL root password in XAMPP, update `DB_PASS` here.

### 5. Open in browser
Visit: **http://localhost/HostelHub**

---

## 🔑 Demo Login Credentials

| Role | Email | Password |
|---|---|---|
| 🛡 Admin | `admin@hostelhub.edu` | `password` |
| 🎓 Student | `kwame.m@student.edu` | `Student@1` |
| 🎓 Student | `akosua.a@student.edu` | `Student@1` |

> **Password rules:** min 8 chars, 1 uppercase, 1 lowercase, 1 digit.

---

## 📁 Project Structure

```
HostelHub/
├── index.html           ← Landing page (public)
├── login.html           ← Login page
├── register.html        ← Registration page
├── dashboard.html       ← Student dashboard (protected)
├── admin.html           ← Admin panel (admin-only)
│
├── api/
│   ├── auth.php         ← Register, login, logout, profile API
│   ├── bookings.php     ← Booking CRUD API
│   ├── rooms.php        ← Rooms & Hostels CRUD API
│   └── maintenance.php  ← Maintenance requests API
│
├── classes/
│   ├── User.php         ← User model (auth, profile, lockout)
│   ├── Booking.php      ← Booking model (lifecycle, payments)
│   ├── Room.php         ← Room & Hostel models
│   └── Maintenance.php  ← Maintenance model
│
├── config/
│   └── database.php     ← MySQL PDO connection
│
├── includes/
│   └── config.php       ← Bootstrap (session, helpers, constants)
│
├── css/
│   └── styles.css       ← Full design system
│
├── js/
│   └── auth.js          ← Auth module + form helpers
│
└── database.sql         ← Schema + seed data (import to phpMyAdmin)
```

---

## 🗄 Database Schema

```
users              → students and admin accounts
hostels            → hostel buildings
rooms              → individual rooms (linked to hostel)
bookings           → room allocations (linked to user + room)
maintenance_requests → student-reported issues
login_attempts     → brute-force audit log
```

---

## 🔒 Security Features

- **Password hashing** via `password_hash()` (bcrypt)
- **Brute-force protection** — 5 failed attempts triggers 5-minute lockout
- **Session-based auth** with `session_regenerate_id()` on login
- **Role enforcement** at API level (student vs admin)
- **Prepared statements** throughout (SQL injection prevention)
- **Input sanitisation** via `htmlspecialchars()`
- **Security headers** (X-Frame-Options, XSS-Protection, etc.)

---

## 📞 Support

For issues, check XAMPP's Apache error log:
`C:\xampp\apache\logs\error.log`

PHP errors are logged (not displayed) — set `display_errors = 1` in
`includes/config.php` temporarily while debugging.
