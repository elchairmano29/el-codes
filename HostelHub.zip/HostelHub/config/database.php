<?php
/**
 * HostelHub – Database Configuration
 * Uses MySQL via PDO (XAMPP compatible)
 */

define('DB_HOST',     'localhost');
define('DB_PORT',     3306);
define('DB_NAME',     'hostelhub_db');
define('DB_USER',     'root');
define('DB_PASS',     '');          // XAMPP default: empty password
define('DB_CHARSET',  'utf8mb4');

class Database {
    private static ?PDO $instance = null;

    public static function getConnection(): PDO {
        if (self::$instance === null) {
            $dsn = sprintf(
                'mysql:host=%s;port=%d;dbname=%s;charset=%s',
                DB_HOST, DB_PORT, DB_NAME, DB_CHARSET
            );
            try {
                self::$instance = new PDO($dsn, DB_USER, DB_PASS, [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]);
            } catch (PDOException $e) {
                error_log('DB Connection failed: ' . $e->getMessage());
                throw new RuntimeException('Database connection failed. Check config/database.php');
            }
        }
        return self::$instance;
    }
}

function getPDO(): PDO {
    return Database::getConnection();
}
?>
